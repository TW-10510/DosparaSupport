import ChatWidget from "../components/ChatWidget";

export default function Home() {
  return (
    <div className="hero">
      {/* LEFT: FULL HEIGHT IMAGE */}
      <div className="hero-image">
        <img src="/CS.png" alt="Dospara Customer Support" />
      </div>

      {/* RIGHT: TEXT CONTENT */}
      <div className="hero-content">
        <span className="hero-tag">
          Customer Support · Sales · Service
        </span>

        {/* MAIN HEADLINE */}
        <h1>Smart support for every PC need</h1>

        {/* GREEN HIGHLIGHT */}
        <h2 className="hero-highlight">
          Before and after you buy
        </h2>

        {/* SUBTEXT */}
        <p>
          AI-assisted support with real Dospara experts.
        </p>

        {/* ACTIONS */}
        <div className="hero-actions">
          {/* IMAGE BUTTON */}
          <a href="/signup" className="btn-image">
            <img src="/button.png" alt="Get Started" />
            <span>Get Started</span>
          </a>

          {/* LOGIN */}
          <a href="/login" className="btn-secondary">
            Login
          </a>
        </div>
      </div>

      {/* CHAT WIDGET */}
      <ChatWidget />
    </div>
  );
}
