export default function Signup() {
  return (
    <div className="auth-page">
      <div className="auth-card">
        <h2>Create Account</h2>
        <input placeholder="Name" />
        <input placeholder="Email" />
        <input type="password" placeholder="Password" />
        <button className="btn-primary full">Sign Up</button>
        <p>Already have an account? <a href="/login">Login</a></p>
      </div>
    </div>
  );
}
