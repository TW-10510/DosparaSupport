import { useState } from "react";
import ChatHeader from "./ChatHeader";
import ChatMessages from "./ChatMessages";

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      sender: "bot",
      text: "Nice! 👋",
    },
    {
      sender: "bot",
      text: "What are you looking for today?",
      type: "suggestions",
      options: [
        "Help me choose a product",
        "Support for my product",
        "Order / warranty / service"
      ]
    }
  ]);

  const handleOptionClick = (option) => {
    // Add user message on RIGHT
    setMessages((prev) => [
    ...prev.filter(m => m.type !== "suggestions"),
    { sender: "user", text: option }
    ]);


    // Bot follow-up (simple example)
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          sender: "bot",
          text:
            option === "Help me choose a product"
              ? "Great! What will you use the PC for?"
              : "Got it 👍 Please log in so I can help you further."
        }
      ]);
    }, 600);
  };

  return (
    <>
      {!open && (
        <button className="chat-fab" onClick={() => setOpen(true)}>
          <img src="/bot_logo.png" alt="Chat Bot" />
        </button>
      )}

      {open && (
        <div className="chat-widget">
          <ChatHeader onClose={() => setOpen(false)} />
          <ChatMessages
            messages={messages}
            onOptionClick={handleOptionClick}
          />
        </div>
      )}
    </>
  );
}
