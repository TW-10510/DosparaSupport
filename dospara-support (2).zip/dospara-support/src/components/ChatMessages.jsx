import { useEffect, useRef } from "react";

export default function ChatMessages({ messages, onOptionClick }) {
  const bottomRef = useRef(null);

  // 🔥 AUTO SCROLL WHENEVER MESSAGES CHANGE
  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  }, [messages]);

  return (
    <div className="chat-messages">
      {messages.map((msg, index) => (
        <div
          key={index}
          className={`chat-row ${msg.sender === "user" ? "right" : "left"}`}
        >
          {msg.sender === "bot" && (
            <img
              src="/bot_logo.png"
              alt="Bot"
              className="chat-avatar"
            />
          )}

          <div className="chat-bubble-group">
            <div className={`chat-bubble ${msg.sender}`}>
              {msg.text}
            </div>

            {msg.type === "suggestions" && (
              <div className="chat-suggestions">
                {msg.options.map((opt) => (
                  <button
                    key={opt}
                    className="suggestion-pill"
                    onClick={() => onOptionClick(opt)}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      ))}

      {/* 👇 SCROLL TARGET */}
      <div ref={bottomRef} />
    </div>
  );
}
