export default function ChatHeader({ onClose }) {
  return (
    <div className="chat-header">
      <div className="chat-header-left">
        <img src="/bot_logo.png" alt="Bot" className="chat-bot-avatar" />
        <div>
          <div className="chat-title">Dospara Support</div>
          <div className="chat-status">● Online</div>
        </div>
      </div>

      <button className="chat-close" onClick={onClose}>✕</button>
    </div>
  );
}
