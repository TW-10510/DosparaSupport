import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="navbar">
      {/* LEFT: LOGO */}
      <div className="navbar-left">
        <Link to="/" className="logo-link">
          <img src="/logo.png" alt="Dospara Logo" className="logo-img" />
        </Link>
      </div>

      {/* RIGHT: ACTIONS */}
      <div className="nav-links">
        <Link to="/login">Login</Link>
        <Link to="/signup" className="btn-primary">Sign Up</Link>
      </div>
    </nav>
  );
}
