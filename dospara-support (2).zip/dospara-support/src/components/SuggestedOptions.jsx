export default function SuggestedOptions({ onSelect }) {
  const options = [
    "Help me choose a product",
    "Support for my product",
    "Order / warranty / service"
  ];

  return (
    <div className="chat-suggestions">
      {options.map((opt, i) => (
        <button
          key={i}
          className="suggestion-pill"
          onClick={() => onSelect(opt)}
        >
          {opt}
        </button>
      ))}
    </div>
  );
}
