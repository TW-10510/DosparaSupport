import { useState } from "react";

export default function ChatInput({ disabled, onSend }) {
  const [text, setText] = useState("");

  function send() {
    if (!text) return;
    onSend(text);
    setText("");
  }

  return (
    <div className="chat-input">
      <input
        disabled={disabled}
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder={disabled ? "Waiting for agent..." : "Type a message"}
      />
      <button onClick={send}>Send</button>
    </div>
  );
}
