export const purchasedProducts = [
  { id: 1, name: "Dospara X15 Laptop" },
  { id: 2, name: "Dospara G7 Desktop" },
  { id: 3, name: "Dospara M24 Monitor" }
];
