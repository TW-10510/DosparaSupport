import time
import json
import random
import requests
from bs4 import BeautifulSoup
from tqdm import tqdm
from urllib.parse import urlparse

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; ProductIndexer/1.0; +contact@example.com)"
}

SITEMAP_INDEX = "https://www.dospara.co.jp/sitemap_index.xml"

DELAY_RANGE = (2, 5)  # seconds (polite crawling)


def fetch(url):
    response = requests.get(url, headers=HEADERS, timeout=20)
    response.raise_for_status()
    return response.text


def get_sitemap_urls():
    xml = fetch(SITEMAP_INDEX)
    soup = BeautifulSoup(xml, "xml")
    return [loc.text for loc in soup.find_all("loc")]


def get_product_urls(sitemap_url):
    xml = fetch(sitemap_url)
    soup = BeautifulSoup(xml, "xml")
    urls = []
    for loc in soup.find_all("loc"):
        url = loc.text
        # heuristic: product pages usually contain "/products/" or similar
        if "/TC973/" in url or "/general-note/" in url or "/general_desk/" :
            urls.append(url)
    return urls


def scrape_product(url):
    html = fetch(url)
    soup = BeautifulSoup(html, "lxml")

    def safe_text(selector):
        el = soup.select_one(selector)
        return el.get_text(strip=True) if el else None

    product = {
        "url": url,
        "name": safe_text("h1"),
        "price": safe_text(".price, .product-price, .price-value"),
        "description": safe_text(".product-description, .description"),
        "specs": {}
    }

    # Spec table extraction (common on JP e-commerce)
    for row in soup.select("table tr"):
        cols = row.find_all(["th", "td"])
        if len(cols) == 2:
            key = cols[0].get_text(strip=True)
            value = cols[1].get_text(strip=True)
            product["specs"][key] = value

    return product


def polite_sleep():
    time.sleep(random.uniform(*DELAY_RANGE))


def main():
    print("🔍 Fetching sitemap index...")
    sitemap_urls = get_sitemap_urls()

    print(f"📦 Found {len(sitemap_urls)} sitemaps")

    product_urls = set()
    for sm in sitemap_urls:
        urls = get_product_urls(sm)
        product_urls.update(urls)
        polite_sleep()

    print(f"🛒 Found {len(product_urls)} product URLs")

    products = []
    for url in tqdm(product_urls):
        try:
            product = scrape_product(url)
            products.append(product)
            polite_sleep()
        except Exception as e:
            print(f"❌ Failed: {url} ({e})")

    with open("dospara_products2.json", "w", encoding="utf-8") as f:
        json.dump(products, f, ensure_ascii=False, indent=2)

    print("✅ Scraping completed. Saved to dospara_products.json")


if __name__ == "__main__":
    main()
