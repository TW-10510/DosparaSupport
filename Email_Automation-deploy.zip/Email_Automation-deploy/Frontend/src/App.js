// App.js
import React from "react";
import "./App.css";
import { Routes, Route, Navigate } from "react-router-dom";
import { useTranslation } from "./context/TranslationContext";
import { useAuth } from "./context/AuthContext";

// Layouts
import MainLayout from "./Layouts/MainLayout";
import AdminLayout from "./Layouts/AdminLayout";

// Normal pages
import Login from "./pages/login";
import Register from "./pages/register";
import ForgotPassword from "./pages/forgotpassword";

// MainLayout pages
import Home from "./pages/home";
import Inbox from "./pages/inbox";
import Senditems from "./pages/senditems";
import DraftsPage from "./pages/draft";
import Analytics from "./pages/analytics";
import CustomerRedirect from "./pages/CustomerRedirect";
import Account from "./pages/Account";
import Setting from "./pages/setting";
import Chart from "./pages/chat";

// Admin pages
import AdminPage from "./pages/Admin/admindashboard";
import User_Management from "./pages/Admin/user_management";
import Tickets from "./pages/Admin/tickets";
import Roles_Permissions from "./pages/Admin/roles_permissions";
import Templates from "./pages/Admin/templates";
import Reports_Logs from "./pages/Admin/reports_logs";
import Automation_Rules from "./pages/Admin/automation_rules";
import Settings from "./pages/Admin/settings";
import Sent_email from "./pages/Admin/sent_email";
import Mail_Layout from "./pages/Admin/api_usage"; 

// ✅ PROTECTED ROUTE COMPONENT (Dynamic Permission Check)
function ProtectedRoute({ requiredPermission, children }) {
  const { isAuthenticated, normalizedRole, userPermissions } = useAuth();

  // 1. Check Login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // 2. Super Admin Bypass (Master Key)
  // They can access EVERYTHING, regardless of the permission list.
  if (normalizedRole === "super admin") {
    return children;
  }

  // 3. Dynamic Permission Check
  // We check if the user's permission list (from DB) includes the required page name
  if (requiredPermission && !userPermissions.includes(requiredPermission)) {
    // If they don't have the specific permission, send to unauthorized
    return <Navigate to="/unauthorized" replace />;
  }

  // 4. Access Granted
  return children;
}

function Unauthorized() {
  return (
    <div className="min-h-screen flex items-center justify-center text-gray-700 bg-gray-50">
      <div className="text-center space-y-4 p-10 bg-white rounded-xl shadow-lg border">
        <h1 className="text-4xl font-bold text-red-500">403</h1>
        <h2 className="text-2xl font-semibold">Access Denied</h2>
        <p className="text-sm text-gray-500">
          You do not have permission to view this page.<br/>
          Please contact your administrator.
        </p>
        <a href="/" className="inline-block px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">
          Go Back
        </a>
      </div>
    </div>
  );
}

function App() {
  const { language, setLanguage } = useTranslation();

  const handleLanguageToggle = () => {
    setLanguage((prev) => (prev === "en" ? "ja" : "en"));
  };

  return (
    <Routes>
      {/* Public Pages */}
      <Route path="/" element={<Login />} />
      <Route path="/login" element={<Login />} />
      <Route path="/unauthorized" element={<Unauthorized />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />

      {/* ======================================================= */}
      {/* ADMIN ROUTES (Requiring specific DB Permissions)        */}
      {/* ======================================================= */}
      
      {/* Note: 'requiredPermission' must match the 'name' in your 'permissions' table */}
      
      <Route path="/admin/*" element={<AdminLayout><Routes>
          
          <Route path="/*" element={
            <ProtectedRoute requiredPermission="admin_dashboard">
              <AdminPage />
            </ProtectedRoute>
          } />

          <Route path="/user_management" element={
            <ProtectedRoute requiredPermission="user_management">
              <User_Management />
            </ProtectedRoute>
          } />

          <Route path="/tickets" element={
            <ProtectedRoute requiredPermission="tickets">
              <Tickets />
            </ProtectedRoute>
          } />

          <Route path="/roles_permissions" element={
            <ProtectedRoute requiredPermission="roles_permissions">
              <Roles_Permissions />
            </ProtectedRoute>
          } />

          <Route path="/templates" element={
            <ProtectedRoute requiredPermission="templates">
              <Templates />
            </ProtectedRoute>
          } />

          <Route path="/reports_logs" element={
            <ProtectedRoute requiredPermission="reports">
              <Reports_Logs />
            </ProtectedRoute>
          } />

          <Route path="/automation_rules" element={
            <ProtectedRoute requiredPermission="automation">
              <Automation_Rules />
            </ProtectedRoute>
          } />

          <Route path="/settings" element={
            <ProtectedRoute requiredPermission="settings">
              <Settings />
            </ProtectedRoute>
          } />

          <Route path="/sent_email" element={
            <ProtectedRoute requiredPermission="email_history"> {/* Changed to match SQL insert */}
              <Sent_email />
            </ProtectedRoute>
          } />

          <Route path="/api_usage" element={
            <ProtectedRoute requiredPermission="api_usage">
              <Mail_Layout />
            </ProtectedRoute>
          } />

      </Routes></AdminLayout>} />


      {/* ======================================================= */}
      {/* USER ROUTES (Wrapped in MainLayout)                     */}
      {/* ======================================================= */}
      
      {/* Note: User routes might not need strict DB permissions if all logged-in users can access them. 
          If you want to restrict them, add requiredPermission props here too. */}

      <Route path="/*" element={
        <ProtectedRoute> {/* Basic Login Check */}
          <MainLayout language={language} onLanguageToggle={handleLanguageToggle}>
            <Routes>
              <Route path="/home" element={<Home />} />
              <Route path="/account" element={<Account />} />
              <Route path="/inbox" element={<Inbox />} />
              <Route path="/senditems" element={<Senditems />} />
              <Route path="/email/draft" element={<DraftsPage />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/customer-form" element={<CustomerRedirect />} />
              <Route path="/setting" element={<Setting />} />
              <Route path="/chat" element={<Chart />} />
            </Routes>
          </MainLayout>
        </ProtectedRoute>
      } />

    </Routes>
  );
}

export default App;