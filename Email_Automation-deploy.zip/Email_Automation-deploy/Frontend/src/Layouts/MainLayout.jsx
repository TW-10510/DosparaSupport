import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../Components/Sidebar";
import TopNavbar from "../Components/TopNavbar";
import { useAuth } from "../context/AuthContext"; // ✅ Import Auth

function MainLayout({ children, language, onLanguageToggle }) {
  const [search, setSearch] = useState("");
  const navigate = useNavigate();
  const { user } = useAuth(); // ✅ Get current user

  // 1. Auth Check (Redirect if not logged in)
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) navigate("/login");
  }, [navigate]);

  // 2. ✅ HEARTBEAT LOGIC (Keeps user "Online")
  useEffect(() => {
    if (!user) return;

    const sendHeartbeat = async () => {
      try {
        await fetch(`${process.env.REACT_APP_API_URL}/users/heartbeat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_id: user.id }),
        });
      } catch (error) {
        // 🤫 Silent Fail: If backend is down, don't crash the app!
        console.warn("Heartbeat failed (Backend might be offline)");
      }
    };

    // Run immediately, then every 30 seconds
    sendHeartbeat();
    const interval = setInterval(sendHeartbeat, 30000);

    return () => clearInterval(interval);
  }, [user]);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar language={language} />
      <div className="flex-1 flex flex-col min-w-0">
        <TopNavbar
          search={search}
          setSearch={setSearch}
          language={language}
          onLanguageToggle={onLanguageToggle}
        />
        <div className="flex-1 overflow-auto min-w-0">{children}</div>
      </div>
    </div>
  );
}

export default MainLayout;