import React from "react";
// ✅ Ensure this path matches where you saved the new AdminNavbar
import AdminNavbar from "../Components/AdminNavbar";

function AdminLayout({ children }) {
  return (
    <div className="flex h-screen overflow-hidden bg-gray-100">
      {/* Sidebar (Dynamic AdminNavbar) */}
      <AdminNavbar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-auto">
        {/* The pages (Dashboard, Tickets, etc.) are rendered here */}
        <main className="flex-1 relative z-0 overflow-y-auto focus:outline-none">
          {children}
        </main>
      </div>
    </div>
  );
}

export default AdminLayout;