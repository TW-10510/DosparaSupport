export const adminTranslations = {
  /* ================= ENGLISH ================= */
  en: {
    // --- NAVIGATION BAR ---
    adminPanel: "Admin Panel",
    emailSystem: "Email Automation System",
    dashboard: "Dashboard",
    tickets: "Tickets",
    sentEmails: "Email History",
    userManagement: "User Management",
    rolesPermissions: "Roles & Permissions",
    templates: "Templates",
    automationRules: "Automation Rules",
    reportsLogs: "Reports & Logs",
    settings: "Settings",
    logout: "Logout",

    // --- ADMIN DASHBOARD ---
    adminDashboard: "Admin Dashboard",
    totalTraffic: "Total Traffic",
    last10Days: "Last 10 Days",
    last12Months: "Last 12 Months",
    allTime: "All Time",
    employees: "Employees",
    emailsSent: "Emails Sent",
    drafts: "Drafts",
    failed: "Failed",
    usersOverview: "Users Overview",
    name: "Name",
    role: "Role",
    mails: "Mails",
    status: "Status",
    online: "Online",
    offline: "Offline",
    notifications: "Notifications",
    approvalNeeded: "Approval Needed",
    view: "View",
    noNotifications: "No new notifications",
    approveRequest: "Approve User Request",
    email: "Email",
    requested: "Requested",
    approveActivate: "Approve & Activate",
    newUserRegistered: "New employee registered",
    cancel: "Cancel",

    // --- ADMIN SETTINGS ---
    adminSettings: "Admin Settings",
    generalSettings: "General Settings",
    appName: "Application Name",
    defaultLanguage: "Default Language",
    timeZone: "Time Zone",
    emailSettings: "Email Settings",
    fromEmail: "From Email",
    replyTo: "Reply-To Email",
    enableEmail: "Enable Email Sending",
    securitySettings: "Security Settings",
    enable2FA: "Enable Two-Factor Authentication",
    sessionTimeout: "Session Timeout (minutes)",
    saveSettings: "Save Settings",
    savedAlert: "Settings saved successfully!",

    // --- SENT EMAILS PAGE (UPDATED) ---
    emailRecords: "Email Records",
    totalEmails: "Total Emails",
    sentReplied: "Sent / Replied",
    pendingDrafts: "Pending / Drafts",

    // Filters & Search
    searchPlaceholder: "Search Employee Name, ID or Recipient...",
    allStatus: "All Status",
    pending: "Pending",
    sent: "Sent",
    allTime: "All Time",
    less24h: "< 24 Hours",
    days1to3: "1-3 Days",
    more1week: "> 1 Week",
    more1month: "> 1 Month",

    // Table Headers
    id: "ID",
    customerMail: "Customer Mail",
    subject: "Subject",
    assignTo: "Assign To",
    status: "Status",
    received: "Received",

    // Time Ago Utils
    justNow: "Just now",
    hoursAgo: "hours ago",
    daysAgo: "days ago",
    weeksAgo: "weeks ago",
    monthsAgo: "months ago",

    // Status Values
    statusPendingApproval: "Pending Approval",
    statusPending: "Pending",
    statusSent: "Sent",

    // Empty State
    noEmailsFound: "No emails found matching your search.",
    loadingRecords: "Loading records...",
    loadError: "Could not load email records.",

    // Modal
    emailDetails: "Email Details",
    sentAt: "Sent At",
    replyBy: "Reply by",
    notSentYet: "Not sent yet",
    messageBody: "Message Body",
    close: "Close",

    // --- USER MANAGEMENT ---
    usersTitle: "Employees",
    searchUserPlaceholder: "Search by ID, name, role...",
    allRoles: "All Roles",
    allStatus: "All Status",
    admin: "Admin",
    employee: "Employee",
    active: "Active",
    inactive: "Inactive",
    deleteSelected: "Delete Selected",
    thId: "ID",
    thEmployee: "Employee",
    thRole: "Role",
    thDepartment: "Department",
    thMailsSent: "Mails Sent",
    thStatus: "Status",
    thAction: "Action",
    noEmployeesFound: "No employees found matching your search.",
    employeeDetails: "Employee Details",
    editUser: "Edit User",
    saveChanges: "Save Changes",
    departmentSelect: "Select Department",
    deptIT: "IT",
    deptSupport: "Support",
    deptMarketing: "Marketing",
    deptSales: "Sales",
    fixedAdmin: "Super Admin cannot be deleted",
    deleteError: "Failed to delete users. Check console.",
    updateError: "Failed to update user in backend",

    // --- TEMPLATES PAGE (NEW) ---
    templatesTitle: "Email Templates",
    createTemplate: "Create Template",
    editTemplate: "Edit Template",
    preview: "Preview",
    closePreview: "Close Preview",
    loadingTemplates: "Loading templates...",
    noTemplatesFound: "No templates found. Create one to get started.",

    // Template Form & Table
    templateName: "Template Name",
    category: "Category",
    tplStatus: "Status",
    lastUpdated: "Last Updated",
    actions: "Actions",
    fromName: "From Name",
    emailBody: "Email Body",
    subjectLine: "Subject Line",
    variablesHint: "Use {{name}}, {{order_id}} variables",

    // Alerts
    confirmDeleteTemplate: "Delete this template?",
    fillRequired:
      "Please fill in required fields (Name, Category, Subject, Body)",
    saveFailed: "Failed to save template",
    deleteFailed: "Error deleting template",
  },

  /* ================= JAPANESE ================= */
  ja: {
    // --- ナビゲーションバー ---
    adminPanel: "管理者パネル",
    emailSystem: "メール自動化システム",
    dashboard: "ダッシュボード",
    tickets: "チケット",
    sentEmails: "送信履歴",
    userManagement: "ユーザー管理",
    rolesPermissions: "役割と権限",
    templates: "テンプレート",
    automationRules: "自動化ルール",
    reportsLogs: "レポートとログ",
    settings: "設定",
    logout: "ログアウト",

    // --- 管理者ダッシュボード ---
    adminDashboard: "管理者ダッシュボード",
    totalTraffic: "総トラフィック",
    last10Days: "過去10日間",
    last12Months: "過去12ヶ月",
    allTime: "全期間",
    employees: "従業員",
    emailsSent: "送信メール",
    drafts: "下書き",
    failed: "失敗",
    usersOverview: "ユーザー概要",
    name: "名前",
    role: "役職",
    mails: "メール",
    status: "ステータス",
    online: "オンライン",
    offline: "オフライン",
    notifications: "通知",
    approvalNeeded: "承認が必要",
    view: "表示",
    noNotifications: "新しい通知はありません",
    approveRequest: "ユーザーリクエストを承認",
    email: "メールアドレス",
    requested: "リクエスト日時",
    approveActivate: "承認して有効化",
    newUserRegistered: "新しい従業員が登録されました",
    cancel: "キャンセル",

    // --- 送信済みメールページ (UPDATED) ---
    emailRecords: "メール記録",
    totalEmails: "総メール数",
    sentReplied: "送信済み / 返信済み",
    pendingDrafts: "保留中 / 下書き",

    // フィルター & 検索
    searchPlaceholder: "従業員名、ID、または受信者で検索...",
    allStatus: "すべてのステータス",
    pending: "保留中",
    sent: "送信済み",
    allTime: "全期間",
    less24h: "24時間以内",
    days1to3: "1〜3日",
    more1week: "1週間以上",
    more1month: "1ヶ月以上",

    // テーブルヘッダー
    id: "ID",
    customerMail: "顧客メール",
    subject: "件名",
    assignTo: "担当者",
    status: "ステータス",
    received: "受信日時",

    // 時間経過
    justNow: "たった今",
    hoursAgo: "時間前",
    daysAgo: "日前",
    weeksAgo: "週間前",
    monthsAgo: "ヶ月前",

    // ステータス値
    statusPendingApproval: "承認待ち",
    statusPending: "保留中",
    statusSent: "送信済み",

    // 空の状態
    noEmailsFound: "検索条件に一致するメールが見つかりませんでした。",
    loadingRecords: "記録を読み込み中...",
    loadError: "メール記録を読み込めませんでした。",

    // モーダル
    emailDetails: "メール詳細",
    sentAt: "送信日時",
    replyBy: "返信者",
    notSentYet: "未送信",
    messageBody: "メッセージ本文",
    close: "閉じる",

    // --- 管理者設定 ---
    adminSettings: "管理者設定",
    generalSettings: "一般設定",
    appName: "アプリケーション名",
    defaultLanguage: "デフォルト言語",
    timeZone: "タイムゾーン",
    emailSettings: "メール設定",
    fromEmail: "送信元メールアドレス",
    replyTo: "返信先メールアドレス",
    enableEmail: "メール送信を有効にする",
    securitySettings: "セキュリティ設定",
    enable2FA: "二要素認証を有効にする",
    sessionTimeout: "セッションタイムアウト (分)",
    saveSettings: "設定を保存",
    savedAlert: "設定が正常に保存されました！",

    // --- ユーザー管理 ---
    usersTitle: "従業員",
    searchUserPlaceholder: "ID、名前、役割で検索...",
    allRoles: "すべての役割",
    allStatus: "すべてのステータス",
    admin: "管理者",
    employee: "従業員",
    active: "有効",
    inactive: "無効",
    deleteSelected: "選択項目を削除",
    thId: "ID",
    thEmployee: "従業員",
    thRole: "役割",
    thDepartment: "部署",
    thMailsSent: "送信メール数",
    thStatus: "ステータス",
    thAction: "操作",
    noEmployeesFound: "検索条件に一致する従業員が見つかりませんでした。",
    employeeDetails: "従業員詳細",
    editUser: "ユーザー編集",
    saveChanges: "変更を保存",
    departmentSelect: "部署を選択",
    deptIT: "IT",
    deptSupport: "サポート",
    deptMarketing: "マーケティング",
    deptSales: "営業",
    fixedAdmin: "スーパー管理者は削除できません",
    deleteError: "ユーザーの削除に失敗しました。",
    updateError: "ユーザー更新に失敗しました",
    loadError: "従業員の読み込みに失敗しました。",

    // --- テンプレートページ (NEW) ---
    templatesTitle: "メールテンプレート",
    createTemplate: "テンプレート作成",
    editTemplate: "テンプレート編集",
    preview: "プレビュー",
    closePreview: "プレビューを閉じる",
    loadingTemplates: "テンプレートを読み込み中...",
    noTemplatesFound: "テンプレートが見つかりません。作成してください。",

    // フォームとテーブル
    templateName: "テンプレート名",
    category: "カテゴリ",
    tplStatus: "ステータス",
    lastUpdated: "最終更新日",
    actions: "操作",
    fromName: "送信者名",
    emailBody: "メール本文",
    subjectLine: "件名",
    variablesHint: "変数 {{name}}, {{order_id}} を使用可能",

    // アラート
    confirmDeleteTemplate: "このテンプレートを削除しますか？",
    fillRequired: "必須項目を入力してください (名前, カテゴリ, 件名, 本文)",
    saveFailed: "テンプレートの保存に失敗しました",
    deleteFailed: "テンプレートの削除に失敗しました",
  },
};

// ✅ Helper Function
export const getAdminTranslation = (key, language = "en") => {
  const langData = adminTranslations[language] || adminTranslations.en;
  return langData[key] || adminTranslations.en[key] || key;
};
