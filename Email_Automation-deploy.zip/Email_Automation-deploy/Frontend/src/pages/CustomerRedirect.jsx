import React, { useEffect } from "react";

export default function CustomerRedirect() {
  useEffect(() => {
    const url = process.env.REACT_APP_WEBFORM_URL || "http://localhost:3001";
    // Replace current location so back button won't return to this intermediate page
    window.location.replace(url);
  }, []);

  return (
    <div className="flex items-center justify-center h-full">
      <div className="text-center">
        <h2 className="text-xl font-semibold">Redirecting to Customer Portal...</h2>
        <p className="text-sm text-gray-500 mt-2">If you are not redirected, <a href={process.env.REACT_APP_WEBFORM_URL || "http://localhost:3001"} className="text-blue-600">click here</a>.</p>
      </div>
    </div>
  );
}
