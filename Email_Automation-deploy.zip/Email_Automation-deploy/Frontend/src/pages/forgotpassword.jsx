import React, { useState } from "react";
import { Link } from "react-router-dom";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [generatedCode, setGeneratedCode] = useState("");
  const [userCode, setUserCode] = useState("");
  const [otpVerified, setOtpVerified] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [message, setMessage] = useState("");
  const [codeSent, setCodeSent] = useState(false);

  const generateCode = () => Math.floor(100000 + Math.random() * 900000);

  const handleSendCode = () => {
    if (!email) {
      setMessage("Please enter your email.");
      return;
    }

    const code = generateCode();
    setGeneratedCode(code);
    setCodeSent(true);

    setMessage(`Verification code sent! (Simulation: ${code})`);
  };

  const verifyOtp = () => {
    if (userCode === generatedCode.toString()) {
      setOtpVerified(true);
      setMessage("OTP Verified! You can now reset your password.");
    } else {
      setMessage("Invalid OTP. Try again.");
    }
  };

  const handleSubmit = () => {
    if (!newPassword || !confirmPassword) {
      setMessage("Please fill all fields.");
      return;
    }

    if (newPassword !== confirmPassword) {
      setMessage("Passwords do not match.");
      return;
    }

    setMessage("Password reset successfully!");

    // API call here
  };

  return (
    <div className="max-w-md mx-auto mt-20 bg-white shadow-lg rounded-xl p-8">
      <h2 className="text-2xl font-bold text-center mb-6">Forgot Password</h2>

      {/* Email Field */}
      <input
        type="email"
        placeholder="Enter your Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="w-full px-4 py-2 border rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400"
      />

      <button
        onClick={handleSendCode}
        className="w-full bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg mb-4"
      >
        Send Verification Code
      </button>

      {/* OTP Section */}
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          placeholder="Enter OTP"
          value={userCode}
          onChange={(e) => setUserCode(e.target.value)}
          disabled={!codeSent}
          className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 disabled:bg-gray-100"
        />

        <button
          onClick={verifyOtp}
          disabled={!codeSent}
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg disabled:bg-gray-400"
        >
          Verify
        </button>
      </div>

      {/* Password Fields — only after OTP verified */}
      {otpVerified && (
        <>
          <input
            type="password"
            placeholder="New Password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />

          <input
            type="password"
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />

          <button
            onClick={handleSubmit}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-lg"
          >
            Reset Password
          </button>
        </>
      )}

      {/* MESSAGE */}
      {message && (
        <p className="text-center text-sm text-gray-700 mt-4">{message}</p>
      )}

      {/* BACK TO LOGIN */}
      <p className="text-center text-sm mt-6">
        Remember your password?{" "}
        <Link to="/login" className="text-blue-600 hover:underline">
          Go to Login
        </Link>
      </p>
    </div>
  );
};

export default ForgotPassword;
