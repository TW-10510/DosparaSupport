import React, { useEffect, useState, useMemo } from "react";
import TranslatedText from "../Components/TranslatedText";
import { useTranslation } from "../context/TranslationContext";
import { getTranslation } from "../utils/translations";
import {  UserCircleIcon } from "@heroicons/react/24/outline";
import ReactMarkdown from "react-markdown";
import EmailLoader from "../Components/EmailLoader";
 
const API = process.env.REACT_APP_API_URL;
 
/* --- HELPERS --- */
 
function formatDateTime(tsSeconds) {
  if (!tsSeconds) return "";
  return new Date(tsSeconds * 1000).toLocaleString([], {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
 
function isToday(tsSeconds) {
  if (!tsSeconds) return false;
  const d = new Date(tsSeconds * 1000);
  const n = new Date();
  return (
    d.getFullYear() === n.getFullYear() &&
    d.getMonth() === n.getMonth() &&
    d.getDate() === n.getDate()
  );
}
 
function isWithinDays(tsSeconds, days) {
  if (!tsSeconds) return false;
  return Date.now() - tsSeconds * 1000 <= days * 86400000;
}
 
function getInitials(value) {
  if (!value) return "?";
  const clean = value.split("@")[0];
  const parts = clean.split(/[\s._-]+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}
 
/* --- COMPONENTS --- */
 
function TranslatedHeader({ text }) {
  const { language } = useTranslation();
  return (
    <>
      {getTranslation(text.toLowerCase().replace(/\s+/g, ""), language)}{" "}
    </>
  );
}
 
function TranslatedSelect({ value, onChange }) {
  const options = [
    { value: "all", label: "All" },
    { value: "today", label: "Today" },
    { value: "last7", label: "Last 7 days" },
  ];
 
  return (
    <select
      value={value}
      onChange={onChange}
      className="px-3 py-1 rounded-md text-sm border focus:ring-2 focus:ring-indigo-300"
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          <TranslatedText text={o.label} />
        </option>
      ))}
    </select>
  );
}
function ProfileHeader({ name, email, time, isSent }) {
  return (
 <div className={`w-full flex items-center gap-3 mb-2 ${isSent ? "justify-end" : "justify-start"}`}>
 
      {!isSent && (
        <div className="w-10 h-10 rounded-full bg-gray-300 text-gray-700 flex items-center justify-center font-bold shadow">
          {getInitials(email)}
        </div>
      )}
 
      <div className={`${isSent ? "text-right" : ""}`}>
        <div className="font-semibold text-gray-900 text-sm">
          {name} {email ? `(${email})` : ""}
        </div>
        <div className="text-xs text-gray-500">{time}</div>
      </div>
 
      {isSent && (
        <div className="w-10 h-10 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold shadow">
          {getInitials(email)}
        </div>
      )}
    </div>
  );
}
 
 
/* --- MESSAGE BUBBLE --- */
function MessageBubble({
  type,
  sender,
  senderEmail,
  time,
  subject,
  replyBody,
  quotedBody,
}) {
  const isSent = type === "sent";
 
  return (
    <div className="w-full flex flex-col mb-8">
 
      <ProfileHeader
        name={sender}
        email={senderEmail}
        time={time}
        isSent={isSent}
      />
 
      <div
        className={`relative p-5 rounded-2xl max-w-[85%] shadow-sm border ${
          isSent
            ? "bg-indigo-50 border-indigo-100 rounded-tr-none"
            : "bg-white border-gray-200 rounded-tl-none"
        }`}
      >
        <div className="border-b pb-2 mb-3 font-bold text-sm">{subject}</div>
 
        {/* Main mail body */}
      <div className="prose prose-sm max-w-none text-gray-800">
      <ReactMarkdown>{replyBody}</ReactMarkdown>
      </div>
 
      {/* Quoted mail */}
      {quotedBody && (
        <div className="mt-4 p-3 bg-gray-50 border-l-4 border-gray-300 rounded text-sm text-gray-600">
          <ReactMarkdown>{quotedBody}</ReactMarkdown>
        </div>
      )}
      </div>
    </div>
  );
}
 
/* --- MAIN COMPONENT --- */
 
export default function Inbox({ search }) {
  const [emails, setEmails] = useState([]);
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [conversation, setConversation] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState("all");
 
  useEffect(() => {
    fetchInbox();
  }, []);
 
  async function fetchInbox() {
    setLoading(true);
    try {
      const userId = localStorage.getItem("user_id");
      if (!userId) return;
 
      const res = await fetch(`${API}/inbox/`, {
        headers: { "X-User-Id": userId },
      });
 
      const data = await res.json();
      setEmails(data.emails || []);
    } finally {
      setLoading(false);
    }
  }
 
  async function loadThread(email) {
    setSelectedEmail(email);
    setConversation([]);
 
    const userId = localStorage.getItem("user_id");
 
    const res = await fetch(`${API}/inbox/thread/${email.id}`, {
      headers: { "X-User-Id": userId },
    });
 
    const data = await res.json();
    setConversation(data.messages || []);
  }
 
  const filteredEmails = useMemo(() => {
    let list = [...emails];
 
    if (filter === "today") list = list.filter((e) => isToday(e.received_at));
    if (filter === "last7")
      list = list.filter((e) => isWithinDays(e.received_at, 7));
 
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(
        (e) =>
          e.subject?.toLowerCase().includes(q) ||
          e.preview?.toLowerCase().includes(q)
      );
    }
 
    return list;
  }, [emails, search, filter]);
 
  if (loading && emails.length === 0) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-50">
        <EmailLoader text="Loading Inbox..." />
      </div>
    );
  }

  return (
    <div className="flex h-full p-4 gap-4">
      {/* LEFT PANEL */}
      <div className="w-1/4 bg-white rounded-xl border flex flex-col">
        <div className="p-3 border-b flex justify-between">
          <TranslatedHeader text="Inbox" />
          <TranslatedSelect
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        </div>
<div className="flex-1 overflow-auto">
 {filteredEmails.map((e) => {
  const isSelected = selectedEmail?.id === e.id;
 
  return (
    <div
      key={e.id}
      onClick={() => loadThread(e)}
      className={`p-3 border-b flex gap-3 cursor-pointer transition
        ${
          isSelected
            ? "bg-indigo-400 text-white"
            : "hover:bg-indigo-50"
        }`}
    >
      {/* Avatar */}
      <div
        className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-semibold
          ${
            isSelected
              ? "bg-white text-indigo-500"
              : "bg-indigo-500 text-white"
          }`}
      >
        {getInitials(e.sender_email)}
      </div>
 
      {/* Text */}
      <div className="flex-1 min-w-0">
        <div
          className={`font-semibold truncate ${
            isSelected ? "text-white" : "text-gray-900"
          }`}
        >
          {e.subject}
        </div>
 
        <div
          className={`text-xs truncate ${
            isSelected ? "text-indigo-100" : "text-gray-500"
          }`}
        >
          {e.preview}
        </div>
 
        <div
          className={`text-xs truncate ${
            isSelected ? "text-indigo-100" : "text-gray-400"
          }`}
        >
          {e.sender_email}
        </div>
      </div>
    </div>
  );
})}
</div>
</div>
 
 
      {/* RIGHT PANEL */}
      <div className="flex-1 bg-gray-50 rounded-xl p-6 overflow-auto">
        {!selectedEmail ? (
          <div className="flex h-full items-center justify-center text-gray-400">
            <UserCircleIcon className="w-12 h-12 mr-3" />
            <TranslatedText text="Select a message to view details" />
          </div>
        ) : (
          conversation.map((msg) => (
            <MessageBubble
              key={msg.id}
              type={msg.type}
              sender={msg.sender_name}    
              senderEmail={msg.sender_email}
              subject={msg.subject}
              replyBody={msg.reply_body}
              quotedBody={msg.quoted_body}
              time={formatDateTime(msg.timestamp)}
            />
          ))
        )}
      </div>
    </div>
  );
}
 
 
