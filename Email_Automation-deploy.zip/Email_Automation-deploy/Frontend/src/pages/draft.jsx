
import React, { useEffect, useState, useRef } from "react";
import TranslatedText from "../Components/TranslatedText";
import { useTranslation } from "../context/TranslationContext";
import { getTranslation } from "../utils/translations";
import ReactMarkdown from "react-markdown";
const API = process.env.REACT_APP_API_URL;
const getUserId = () => {
  const uid = localStorage.getItem("user_id");
  if (!uid || uid === "null") {
    throw new Error("Invalid user session");
  }
  return uid;
}; 
function DraftsPage() {
  const [drafts, setDrafts] = useState([]);
 
  const [selected, setSelected] = useState(null);
 
  const [loading, setLoading] = useState(false);
 
  const [sendLoading, setSendLoading] = useState(false);
 
  const [aiEditMode, setAiEditMode] = useState(false);
 
  const [humanFeedbackMode, setHumanFeedbackMode] = useState(false);
 
  const [humanFeedback, setHumanFeedback] = useState("");
 
  const [aiLanguage, setAiLanguage] = useState("en");
  const [translateLoading, setTranslateLoading] = useState(false);
  const [activeTranslateBtn, setActiveTranslateBtn] = useState(null);
// "ja" | "en" | null

 
  const { language } = useTranslation();
 
  const textRef = useRef(null);
 
  /* helper → get initials like Inbox/Senditems */
  function getInitials(value) {
    if (!value) return "?";
 
    const clean = (value || "").split("@")[0];
    const parts = clean.split(/[\s._-]+/);
 
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
 
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
 
  useEffect(() => {
    fetchDrafts();
  }, []);
 
  /* ---------------- LOAD DRAFTS ---------------- */
 
  const fetchDrafts = async () => {
    setLoading(true);
 
    try {
      // ✅ STEP 1: read user_id safely
      const rawUserId = localStorage.getItem("user_id");
 
      // ✅ STEP 2: validate
      if (!rawUserId || rawUserId === "null") {
        console.error("Invalid user_id in localStorage:", rawUserId);
        setDrafts([]);
        setSelected(null);
        setLoading(false);
        return;
      }
 
      const userId = rawUserId;
 
      // ✅ STEP 3: attach header
      const res = await fetch(`${API}/drafts/`, {
        headers: {
          "X-User-Id": userId,
        },
      });
 
      if (!res.ok) throw new Error(await res.text());
 
      const j = await res.json();
      const newDrafts = j.drafts || [];
 
      setDrafts(newDrafts);
 
    // (keep the rest of your logic unchanged)
 
    if (selected) {
      const same = newDrafts.find((d) => d.id === selected.id);
 
      if (same) setSelected(same);
      else if (newDrafts.length > 0) setSelected(newDrafts[0]);
      else setSelected(null);
    } else if (newDrafts.length > 0) {
      setSelected(newDrafts[0]);
    }
  } catch (e) {
    console.error(e);
    setDrafts([]);
    setSelected(null);
  } finally {
    setLoading(false);
  }
};
 
  /* ---------------- EDIT AI REPLY ---------------- */
 
  const onEdit = (val) => {
    if (!selected) return;
 
    const updated = { ...selected, draft_reply: val };
 
    setSelected(updated);
 
    setDrafts((prev) => prev.map((d) => (d.id === selected.id ? updated : d)));
  };
 
  /* ---------------- SEND EMAIL ---------------- */
 
  const send = async () => {
  if (!selected) {
    alert("Select a draft first");
    return;
  }
 
  setSendLoading(true);
 
  try {
    const res = await fetch(`${API}/drafts/send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-User-Id":getUserId(), // ✅ REQUIRED
      },
      body: JSON.stringify({
        original_email_id: selected.id, // ✅ DB ID
        final_reply: displayDraftReply, // ✅ SEND WHAT USER EDITED
      }),
    });
 
    if (!res.ok) {
      const err = await res.text();
      throw new Error(err);
    }
 
    alert("Sent successfully");
 
    setAiEditMode(false);
    fetchDrafts(); // refresh drafts
  } catch (e) {
    alert("Send failed: " + e.message);
  } finally {
    setSendLoading(false);
  }
};
 
  /* ---------------- SEND WITH FEEDBACK ---------------- */
 
  const sendWithFeedback = async () => {
    if (!selected) {
      alert("Select a draft first");
      return;
    }
 
    if (!humanFeedback) {
      alert("Write feedback first");
      return;
    }
 
    setSendLoading(true);
 
    try {
      // 1️⃣ Store feedback
      const res = await fetch(`${API}/drafts/feedback`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-User-Id":  getUserId(), // ✅ REQUIRED
        },
        body: JSON.stringify({
          original_email_id: selected.id,
          human_feedback: humanFeedback,
        }),
      });
 
      if (!res.ok) {
        const err = await res.text();
        throw new Error(err);
      }
 
      alert("Feedback sent successfully");
 
      setHumanFeedback("");
      setHumanFeedbackMode(false);
      setAiEditMode(false);
 
      fetchDrafts();
    } catch (e) {
      alert("Send failed: " + e.message);
    } finally {
      setSendLoading(false);
    }
  };
 
 
  /* ---------------- FEEDBACK FLOW ---------------- */
 
  const onSendFeedbackClick = async () => {
    if (!humanFeedback) {
      alert("Write feedback first");
      return;
    }
 
    try {
      // store feedback
      await fetch(`${API}/drafts/feedback`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-User-Id":  getUserId(),
        },
        body: JSON.stringify({
          original_email_id: selected.id,
          human_feedback: humanFeedback,
        }),
      });
 
      // generate improved reply
      const res = await fetch(`${API}/drafts/feedback/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-User-Id": getUserId(),
        },
        body: JSON.stringify({
          original_email_id: selected.id,
          human_feedback: humanFeedback,
        }),
      });
 
      if (!res.ok) {
        const err = await res.text();
        throw new Error(err);
      }
 
      const data = await res.json();
      onEdit(data.improved_reply);
 
      setHumanFeedback("");
      setHumanFeedbackMode(false);
    } catch (e) {
      alert("AI generation failed: " + e.message);
    }
  };
 
 
  /* ---------------- TRANSLATE ---------------- */
 
  const { translate } = useTranslation();
  const originalsRef = useRef({}); // store original content/draft_reply per message id
  const [displayContent, setDisplayContent] = useState("");
  const [displayDraftReply, setDisplayDraftReply] = useState("");
 
  const translateAll = async () => {
    if (!selected) return;
 
    setTranslateLoading(true);
 
    const targetLang = aiLanguage === "en" ? "ja" : "en";
 
    // save originals before overwriting (so we can restore on language toggle)
    originalsRef.current[selected.id] = {
      content: selected.content,
      draft_reply: selected.draft_reply,
    };
 
    try {
      const res = await fetch(`${API}/drafts/translate`, {
        method: "POST",
 
        headers: { "Content-Type": "application/json" },
 
        body: JSON.stringify({ text: selected.content, targetLang }),
      });
 
      const orig = await res.json();
 
      const resAI = await fetch(`${API}/drafts/translate`, {
        method: "POST",
 
        headers: { "Content-Type": "application/json" },
 
        body: JSON.stringify({
          text: selected.draft_reply || selected.content,
 
          targetLang,
        }),
      });
 
      const ai = await resAI.json();
 
      setSelected((p) => ({
        ...p,
 
        content: orig.translated,
 
        draft_reply: ai.translated,
      }));
 
      setAiLanguage(targetLang);
    } catch (e) {
    console.error("Translate failed:", e);
    
    // ✅ Check for specific Quota error text
    if (e.message.includes("Quota Exceeded") || e.message.includes("402")) {
        alert("🚫 LIMIT REACHED: You have used all your AI credits for this month. Please contact admin.");
    } else {
        alert("Translation failed: " + e.message);
    }
} finally {
      setTranslateLoading(false);
    }
  };
  const translateTo = async (targetLang) => {
  if (!selected) return;

  setActiveTranslateBtn(targetLang);
  setTranslateLoading(true);

  try {
    const res1 = await fetch(`${API}/drafts/translate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text:
          originalsRef.current[selected.id]?.content ||
          selected.content,
        targetLang,
      }),
    });

    const data1 = await res1.json();

    const res2 = await fetch(`${API}/drafts/translate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text:
          originalsRef.current[selected.id]?.draft_reply ||
          selected.draft_reply,
        targetLang,
      }),
    });

    const data2 = await res2.json();

    setDisplayContent(data1.translated || "");
    setDisplayDraftReply(data2.translated || "");
  } catch (e) {
    alert("Translation failed");
  } finally {
    setTranslateLoading(false);
    setActiveTranslateBtn(null);
  }
};

 
  /* ---------------- AUTO-TRANSLATE (on language toggle) ---------------- */
 
  // when selected changes, initialize display values and store originals
  useEffect(() => {
    if (!selected) {
      setDisplayContent("");
      setDisplayDraftReply("");
      return;
    }
 
    // ensure originals stored
    originalsRef.current[selected.id] = originalsRef.current[selected.id] || {
      content: selected.content,
      draft_reply: selected.draft_reply,
    };
 
    setDisplayContent(selected.content || "");
    setDisplayDraftReply(selected.draft_reply || "");
  }, [selected]);
 
  // when language changes, translate or restore original content
  useEffect(() => {
    let mounted = true;
    if (!selected) return;
 
    const orig = originalsRef.current[selected.id] || {
      content: selected.content,
      draft_reply: selected.draft_reply,
    };
 
    if (language === "en") {
      setDisplayContent(orig.content || "");
      setDisplayDraftReply(orig.draft_reply || "");
      return;
    }
 
    // translate both content and draft_reply asynchronously
    (async () => {
      try {
        // show small loading while the on-the-fly translation is happening
        setTranslateLoading(true);
 
        const [tContent, tReply] = await Promise.all([
          translate(orig.content || ""),
          translate(orig.draft_reply || ""),
        ]);
 
        if (!mounted) return;
        if (tContent && tContent.length) setDisplayContent(tContent);
        if (tReply && tReply.length) setDisplayDraftReply(tReply);
      } catch (e) {
        // on error, keep originals displayed
        if (!mounted) return;
        setDisplayContent(orig.content || "");
        setDisplayDraftReply(orig.draft_reply || "");
      } finally {
        if (mounted) setTranslateLoading(false);
      }
    })();
 
    return () => {
      mounted = false;
    };
  }, [language, selected]);
 
  // listen for global translate requests (e.g. from TopNavbar)
  useEffect(() => {
    const handler = (e) => {
      // call same translate flow used by the translate button
      translateAll();
    };
 
    window.addEventListener("translateAllRequest", handler);
    return () => window.removeEventListener("translateAllRequest", handler);
  }, [selected, aiLanguage]);
 
  /* ---------------- UI ---------------- */
 
  return (
    <div className="flex h-full p-4 gap-4 text-sm font-sans bg-gray-50">
      {/* SIDEBAR */}
      <div className="w-1/4 bg-white rounded-xl shadow border border-gray-300 flex flex-col overflow-hidden">
        <div className="px-4 py-2 border-b font-semibold text-lg">
          {getTranslation("drafts", language)} {loading && "(loading...)"}
        </div>
 
        <div className="flex-1 overflow-y-auto">
          {drafts.map((d) => {
            const isSelected = selected?.id === d.id;
            const sender =
              d.sender_name || d.sender || d.sender_email || "Unknown";
 
            return (
              <div
                key={d.id}
                onClick={() => {
                  setSelected(d);
 
                  setHumanFeedbackMode(false);
 
                  setAiEditMode(false);
                }}
                className={`p-3 border-b flex gap-3 cursor-pointer transition
                      ${
                        isSelected
                          ? "bg-indigo-400 text-white"
                          : "hover:bg-indigo-50"
                      }`}
              >
                {/* Avatar */}
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-semibold
 
                        ${
                          isSelected
                            ? "bg-white text-indigo-500"
                            : "bg-indigo-500 text-white"
                        }`}
                >
                  {getInitials(sender)}
                </div>
 
                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between">
                    <div className="truncate font-medium">{sender}</div>
                    <div
                      className={`text-xs ${
                        isSelected ? "text-indigo-100" : "text-gray-400"
                      }`}
                    >
                      {d.status || "pending"}
                    </div>
                  </div>
 
                  <div className="truncate font-semibold">{d.subject}</div>
 
                  <div
                    className={`text-xs truncate ${
                      isSelected ? "text-indigo-100" : "text-gray-500"
                    }`}
                  >
                    {(d.preview || d.content || "").slice(0, 120)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
 
      {/* MAIN */}
      <div className="flex-1 bg-white rounded-xl shadow border border-gray-300 p-6 overflow-auto relative">
       {selected && (
        <div className="absolute top-4 right-6 flex gap-2">
          <button
            onClick={() => translateTo("ja")}
            disabled={translateLoading && activeTranslateBtn === "ja"}
            className={`text-white px-3 py-1 rounded text-xs ${
              activeTranslateBtn === "ja"
                ? "bg-gray-400"
                : "bg-green-500"
            }`}
      >
            Translate to Japanese
      </button>

      <button
        onClick={() => translateTo("en")}
        disabled={translateLoading && activeTranslateBtn === "en"}
        className={`text-white px-3 py-1 rounded text-xs ${
        activeTranslateBtn === "en"
          ? "bg-gray-400"
          : "bg-blue-500"
      }`}
    >
      Translate to English
    </button>
  </div>
)}

 
        {!selected ? (
          <div className="text-gray-500">
            {getTranslation("selectDraft", language)}
          </div>
        ) : (
          <>
            <div className="mb-4">
              <div className="text-xs text-gray-500">
                {getTranslation("to", language)}
              </div>
              <div className="font-semibold text-sm">
                {selected.sender_email}
              </div>
            </div>
 
            <div className="mb-4">
              <div className="text-xs font-semibold text-gray-600 mb-1">
                {getTranslation("originalMessage", language)}
              </div>
              <div className="bg-gray-50 border rounded p-3 text-sm">
                {selected?.language === "ja" ? (
                  <div className="whitespace-pre-line leading-relaxed">
                    {displayContent}
                  </div>
                ) : (
                  <>
                    {displayContent
                      .replace(/\r/g, "")
                      .split(/(?<=\.)\s+/)
                      .map((line, idx) => (
                        <p key={idx} className="mb-3 leading-7">
                          {line}
                        </p>
                      ))}
                  </>
                )}
              </div>
            </div>
 
            <div className="bg-gray-50 border rounded p-3">
              <div className="flex justify-between mb-2">
                <span className="text-xs font-semibold">
                  {getTranslation("aiGeneratedMessage", language)}
                </span>
                <div className="space-x-2">
                  <button
                    onClick={() => setAiEditMode(!aiEditMode)}
                    className="bg-blue-600 text-white px-2 py-1 rounded text-xs"
                  >
                    {getTranslation(aiEditMode ? "lock" : "edit", language)}
                  </button>
                  <button
                    onClick={() => setHumanFeedbackMode(true)}
                    className="bg-slate-500 text-white px-2 py-1 rounded text-xs"
                  >
                    {getTranslation("improveWithFeedback", language)}
                  </button>
                </div>
              </div>
 
              {aiEditMode ? (
                <textarea
                  ref={textRef}
                  value={displayDraftReply || ""}
                  onChange={(e) => {
                    const v = e.target.value;
                    onEdit(v);
                    setDisplayDraftReply(v);
 
                    if (selected) {
                      originalsRef.current[selected.id] = {
                        ...(originalsRef.current[selected.id] || {}),
                        draft_reply: v,
                      };
                    }
                  }}
                  rows={8}
                  className="w-full p-3 border rounded resize-none text-sm bg-white"
                />
              ) : (
                <div className="w-full p-3 border rounded bg-white text-sm leading-relaxed max-w-none">
                  <ReactMarkdown>
                    {displayDraftReply || ""}
                  </ReactMarkdown>
                </div>
              )}
            </div>
 
            {humanFeedbackMode && (
              <div className="mt-4">
                <textarea
                  value={humanFeedback}
                  onChange={(e) => setHumanFeedback(e.target.value)}
                  rows={4}
                  placeholder={
                    translate
                      ? undefined
                      : "Tell the AI how to improve the message..."
                  }
                  className="w-full p-3 border rounded resize-none text-sm"
                />
                <div className="mt-3 flex gap-3">
                  <button
                    onClick={onSendFeedbackClick}
                    className="px-4 py-2 bg-slate-600 text-white rounded text-xs"
                  >
                    {getTranslation("sendFeedback", language)}
                  </button>
                  <button
                    onClick={() => {
                      setHumanFeedback("");
 
                      setHumanFeedbackMode(false);
                    }}
                    className="bg-gray-200 px-4 py-2 rounded text-xs"
                  >
                    {getTranslation("cancel", language)}
                  </button>
                </div>
              </div>
            )}
 
            <div className="mt-6">
              <button
                onClick={send}
                disabled={sendLoading}
                className="bg-blue-600 text-white px-4 py-2 rounded text-xs"
              >
                {getTranslation(sendLoading ? "sending" : "sendAiMessage", language)}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
 
export default DraftsPage;