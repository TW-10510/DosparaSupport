import React from 'react'

function mail_layouts() {
  return (
    <div>mail_layouts</div>
  )
}

export default mail_layouts