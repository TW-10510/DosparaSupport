import React, { useState } from "react";
import { FaPlus, FaTrash, FaBolt } from "react-icons/fa";

function AutomationRules() {
  const [rules, setRules] = useState([
    {
      id: 1,
      name: "High Priority Ticket Auto Assign",
      trigger: "Ticket Created",
      condition: "Priority = High",
      action: "Assign to Admin",
      status: true,
    },
    {
      id: 2,
      name: "Email Failure Ticket",
      trigger: "Email Failed",
      condition: "Any",
      action: "Create Support Ticket",
      status: true,
    },
    {
      id: 3,
      name: "Auto Close Resolved Tickets",
      trigger: "Ticket Updated",
      condition: "Status = Resolved",
      action: "Close Ticket",
      status: false,
    },
  ]);

  const [modalOpen, setModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    trigger: "",
    condition: "",
    action: "",
  });

  /* ---------------- CREATE RULE ---------------- */
  const openCreateModal = () => {
    setFormData({
      name: "",
      trigger: "",
      condition: "",
      action: "",
    });
    setModalOpen(true);
  };

  const handleCreate = () => {
    if (!formData.name || !formData.trigger || !formData.action) {
      alert("Please fill required fields");
      return;
    }

    setRules((prev) => [
      ...prev,
      {
        ...formData,
        id: Date.now(),
        status: true,
      },
    ]);

    setModalOpen(false);
  };

  /* ---------------- TOGGLE ---------------- */
  const toggleRule = (id) => {
    setRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: !r.status } : r))
    );
  };

  /* ---------------- DELETE ---------------- */
  const deleteRule = (id) => {
    setRules((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen space-y-8">
      {/* HEADER */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800">Automation Rules</h1>
        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
        >
          <FaPlus /> Create Rule
        </button>
      </div>

      {/* RULES TABLE */}
      <div className="bg-white rounded-2xl shadow overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-indigo-100">
            <tr>
              <th className="p-4 text-left">Rule</th>
              <th className="p-4 text-left">Trigger</th>
              <th className="p-4 text-left">Condition</th>
              <th className="p-4 text-left">Action</th>
              <th className="p-4 text-center">Status</th>
              <th className="p-4 text-center">Actions</th>
            </tr>
          </thead>

          <tbody>
            {rules.map((rule) => (
              <tr key={rule.id} className="border-b hover:bg-indigo-50">
                <td className="p-4 font-medium text-indigo-700">
                  <div className="flex items-center gap-2">
                    <FaBolt className="text-indigo-500" />
                    {rule.name}
                  </div>
                </td>
                <td className="p-4">{rule.trigger}</td>
                <td className="p-4">{rule.condition}</td>
                <td className="p-4">{rule.action}</td>

                <td className="p-4 text-center">
                  <button
                    onClick={() => toggleRule(rule.id)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      rule.status
                        ? "bg-green-100 text-green-700"
                        : "bg-gray-200 text-gray-600"
                    }`}
                  >
                    {rule.status ? "Active" : "Disabled"}
                  </button>
                </td>

                <td className="p-4 text-center">
                  <button
                    onClick={() => deleteRule(rule.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <FaTrash />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ================= CREATE RULE MODAL ================= */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-xl w-[32rem] p-6 relative">
            <h2 className="text-2xl font-bold text-indigo-600 mb-4">
              Create Automation Rule
            </h2>

            <div className="space-y-4 text-sm">
              <input
                placeholder="Rule Name"
                value={formData.name}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    name: e.target.value,
                  })
                }
                className="w-full border rounded px-3 py-2"
              />

              <select
                value={formData.trigger}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    trigger: e.target.value,
                  })
                }
                className="w-full border rounded px-3 py-2"
              >
                <option value="">Select Trigger</option>
                <option>Ticket Created</option>
                <option>Ticket Updated</option>
                <option>Email Failed</option>
                <option>Email Sent</option>
              </select>

              <input
                placeholder="Condition (optional)"
                value={formData.condition}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    condition: e.target.value,
                  })
                }
                className="w-full border rounded px-3 py-2"
              />

              <input
                placeholder="Action"
                value={formData.action}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    action: e.target.value,
                  })
                }
                className="w-full border rounded px-3 py-2"
              />
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => setModalOpen(false)}
                className="px-4 py-2 bg-gray-200 rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleCreate}
                className="px-4 py-2 bg-indigo-600 text-white rounded"
              >
                Create Rule
              </button>
            </div>

            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-3 right-3 text-gray-500"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default AutomationRules;
