import React, { useState, useEffect } from "react";
import { FaPlus, FaEdit, FaTrash, FaEye, FaFileCode, FaFileAlt, FaLaptop } from "react-icons/fa";

// ✅ Import Translation Hooks
import { useTranslation } from "../../context/TranslationContext";
import { getAdminTranslation } from "../../utils/adminTranslations";
import EmailLoader from "../../Components/EmailLoader";

// ✅ Import Your Logo
import logo from "../../assets/image.png";

// ✅ Correct API Endpoint
const API = `${process.env.REACT_APP_API_URL}/templates`;

// ==========================================
// ✅ LETTERHEAD HTML (Now uses your imported Logo)
// ==========================================
// We use a function so we can inject the logo variable dynamically
const getThirdwaveLetterhead = (logoSrc) => `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f4; font-family: 'Segoe UI', Arial, sans-serif;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4; padding: 20px 0;">
    <tr>
      <td align="center">
        <table width="600" border="0" cellspacing="0" cellpadding="0" style="background-color: #ffffff; width: 600px; max-width: 100%; box-shadow: 0px 2px 5px rgba(0,0,0,0.1);">
          <tr>
            <td style="padding: 0; position: relative;">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="60%" style="padding: 40px 0 10px 40px;">
                     <img src="${logoSrc}" alt="THIRDWAVE GROUP" width="200" style="display: block;" />
                  </td>
                  <td width="40%" style="vertical-align: top; text-align: right;">
                    <div style="background-color: #1a237e; width: 100%; height: 120px; border-bottom-left-radius: 100px; margin-bottom: -40px; margin-left: 20px;"></div>
                  </td>
                </tr>
              </table>
              <div style="height: 2px; background-color: #e0e0e0; margin: 0 40px;"></div>
            </td>
          </tr>
          <tr>
            <td style="padding: 40px; min-height: 400px; color: #333333; line-height: 1.6; font-size: 16px;">
              
              <p>Dear Customer,</p>
              <br>
              <p>Write your content here...</p>
              <br>
              <p>Best regards,<br>Support Team</p>

            </td>
          </tr>
          <tr>
            <td style="padding: 0;">
               <div style="background-color: #1a237e; width: 30%; height: 60px; border-top-right-radius: 60px;"></div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

function Templates() {
  const { language } = useTranslation();
  const t = (key) => getAdminTranslation(key, language);

  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [previewTemplate, setPreviewTemplate] = useState(null);

  const [selectedLayout, setSelectedLayout] = useState("Blank"); 

  const [formData, setFormData] = useState({
    id: null,
    name: "",
    category: "",
    status: "Active",
    fromName: "",
    fromEmail: "",
    subject: "",
    body: "",
  });

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    setLoading(true);
    try {
      const res = await fetch(API);
      if (res.ok) {
        const data = await res.json();
        setTemplates(data);
      }
    } catch (err) {
      console.error("Failed to load templates", err);
    } finally {
      setLoading(false);
    }
  };

  /* ---------------- OPEN MODALS ---------------- */
  const openCreateModal = () => {
    setSelectedLayout("Blank");
    setFormData({
      id: null,
      name: "",
      category: "",
      status: "Active",
      fromName: "Support Team", 
      fromEmail: "",
      subject: "",
      body: "",
    });
    setModalOpen(true);
  };

  const openEditModal = (template) => {
    const isHtml = template.body.includes("<!DOCTYPE html>");
    setSelectedLayout(isHtml ? "Letterhead" : "Blank");
    setFormData(template);
    setModalOpen(true);
  };

  // ✅ Handle Switching between Letterhead and Blank
  const handleLayoutChange = (e) => {
    const layout = e.target.value;
    setSelectedLayout(layout);
    if (layout === "Letterhead") {
        // Inject the imported logo into the HTML string
        setFormData({ ...formData, body: getThirdwaveLetterhead(logo) });
    } else {
        setFormData({ ...formData, body: "" });
    }
  };

  /* ---------------- SAVE ---------------- */
  const handleSubmit = async () => {
    const { name, category, subject, body } = formData;
    if (!name || !category || !subject || !body) {
      alert(t("fillRequired"));
      return;
    }
    const payload = { ...formData };
    try {
      let res;
      if (formData.id) {
        res = await fetch(`${API}/${formData.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch(API, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      if (res.ok) {
        fetchTemplates();
        setModalOpen(false);
      } else {
        alert(t("saveFailed"));
      }
    } catch (error) {
      console.error("Error saving template:", error);
      alert(t("saveFailed"));
    }
  };

  /* ---------------- DELETE ---------------- */
  const handleDelete = async (id) => {
    if (window.confirm(t("confirmDeleteTemplate"))) {
      try {
        const res = await fetch(`${API}/${id}`, { method: "DELETE" });
        if (res.ok) {
          setTemplates((prev) => prev.filter((t) => t.id !== id));
        } else {
          alert(t("deleteFailed"));
        }
      } catch (err) {
        alert(t("deleteFailed"));
      }
    }
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen space-y-8 animate-fade-in font-sans">
      {/* HEADER */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800">{t("templatesTitle")}</h1>
        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 shadow-md transition"
        >
          <FaPlus /> {t("createTemplate")}
        </button>
      </div>

      {/* TABLE */}
      <div className="bg-white rounded-2xl shadow overflow-hidden">
        {loading ? (
          <div className="py-16 flex items-center justify-center">
            <EmailLoader text={t("loadingTemplates")} />
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-indigo-50 text-indigo-900 border-b border-indigo-100">
              <tr>
                <th className="p-4 text-left font-semibold">{t("templateName")}</th>
                <th className="p-4 text-left font-semibold">Format</th>
                <th className="p-4 text-left font-semibold">{t("category")}</th>
                <th className="p-4 text-left font-semibold">{t("tplStatus")}</th>
                <th className="p-4 text-left font-semibold">{t("lastUpdated")}</th>
                <th className="p-4 text-center font-semibold">{t("actions")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {templates.map((tpl) => (
                <tr key={tpl.id} className="hover:bg-gray-50 transition">
                  <td className="p-4 font-medium text-indigo-700 cursor-pointer hover:underline" onClick={() => openEditModal(tpl)}>
                    {tpl.name}
                  </td>
                  <td className="p-4">
                    {tpl.body.includes("<!DOCTYPE html>") ? (
                        <span className="flex items-center gap-1 text-purple-600 bg-purple-50 px-2 py-1 rounded text-xs font-semibold w-fit">
                            <FaFileCode /> Letterhead
                        </span>
                    ) : (
                        <span className="flex items-center gap-1 text-gray-600 bg-gray-100 px-2 py-1 rounded text-xs font-semibold w-fit">
                            <FaFileAlt /> Text Only
                        </span>
                    )}
                  </td>
                  <td className="p-4 text-gray-600">{tpl.category}</td>
                  <td className="p-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${tpl.status === "Active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>
                      {tpl.status}
                    </span>
                  </td>
                  <td className="p-4 text-gray-500">{tpl.lastUpdated}</td>
                  <td className="p-4 text-center">
                    <div className="flex justify-center gap-3">
                      <button onClick={() => setPreviewTemplate(tpl)} className="text-gray-400 hover:text-indigo-600 transition" title={t("preview")}>
                        <FaEye size={16} />
                      </button>
                      <button onClick={() => openEditModal(tpl)} className="text-gray-400 hover:text-blue-600 transition" title={t("editTemplate")}>
                        <FaEdit size={16} />
                      </button>
                      <button onClick={() => handleDelete(tpl.id)} className="text-gray-400 hover:text-red-600 transition" title={t("deleteSelected")}>
                        <FaTrash size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {templates.length === 0 && (
                <tr><td colSpan="6" className="p-8 text-center text-gray-400 italic">{t("noTemplatesFound")}</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* ======================================================== */}
      {/* ✅ SPLIT SCREEN MODAL (LEFT: INPUTS, RIGHT: LIVE PREVIEW) */}
      {/* ======================================================== */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-7xl h-[90vh] flex flex-col relative animate-fade-in">
            
            {/* Modal Header */}
            <div className="flex justify-between items-center p-6 border-b border-gray-200">
                <h2 className="text-2xl font-bold text-gray-800">
                    {formData.id ? t("editTemplate") : t("createTemplate")}
                </h2>
                <button onClick={() => setModalOpen(false)} className="text-gray-400 hover:text-red-600 text-2xl font-bold">✕</button>
            </div>

            {/* Split Content Area */}
            <div className="flex-1 overflow-hidden">
                <div className="grid grid-cols-1 lg:grid-cols-2 h-full">
                    
                    {/* LEFT SIDE: INPUTS (Scrollable) */}
                    <div className="p-6 overflow-y-auto space-y-6 border-r border-gray-200 bg-gray-50/50">
                        {/* Layout Selector */}
                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                            <label className="block text-blue-800 font-bold mb-2">Select Layout</label>
                            <select 
                                value={selectedLayout} 
                                onChange={handleLayoutChange}
                                className="w-full border border-blue-200 rounded-lg px-3 py-2 bg-white text-gray-700 focus:ring-2 focus:ring-blue-500 outline-none"
                            >
                                <option value="Blank">Plain Text</option>
                                <option value="Letterhead">Thirdwave Letterhead (With Logo)</option>
                            </select>
                        </div>

                        {/* Basic Inputs */}
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-gray-700 font-medium mb-1">{t("templateName")}</label>
                                <input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full border p-2 rounded focus:ring-2 focus:ring-indigo-500" />
                            </div>
                            <div>
                                <label className="block text-gray-700 font-medium mb-1">{t("category")}</label>
                                <input value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })} className="w-full border p-2 rounded focus:ring-2 focus:ring-indigo-500" placeholder="e.g. Support" />
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-gray-700 font-medium mb-1">{t("fromName")}</label>
                                <input value={formData.fromName} onChange={(e) => setFormData({...formData, fromName: e.target.value})} className="w-full border p-2 rounded focus:ring-2 focus:ring-indigo-500" />
                            </div>
                            <div>
                                <label className="block text-gray-700 font-medium mb-1">{t("fromEmail")}</label>
                                <input value={formData.fromEmail} onChange={(e) => setFormData({...formData, fromEmail: e.target.value})} className="w-full border p-2 rounded focus:ring-2 focus:ring-indigo-500" />
                            </div>
                        </div>

                        <div>
                            <label className="block text-gray-700 font-medium mb-1">{t("subjectLine")}</label>
                            <input value={formData.subject} onChange={(e) => setFormData({ ...formData, subject: e.target.value })} className="w-full border p-2 rounded focus:ring-2 focus:ring-indigo-500" />
                        </div>

                        <div>
                            <label className="block text-gray-700 font-medium mb-1">
                                {selectedLayout === "Letterhead" ? "Email Content (Edit HTML Source)" : t("emailBody")}
                            </label>
                            <textarea
                                rows={12}
                                value={formData.body}
                                onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                                className="w-full border border-gray-300 rounded-lg p-3 font-mono text-xs text-gray-700 bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                                placeholder="<html>...</html> or text"
                            />
                        </div>

                        <div>
                            <label className="block text-gray-700 font-medium mb-1">{t("tplStatus")}</label>
                            <select value={formData.status} onChange={(e) => setFormData({ ...formData, status: e.target.value })} className="w-full border p-2 rounded">
                                <option value="Active">Active</option>
                                <option value="Draft">Draft</option>
                            </select>
                        </div>
                    </div>

                    {/* RIGHT SIDE: LIVE PREVIEW (Sticky) */}
                    <div className="p-6 bg-gray-100 flex flex-col h-full overflow-hidden">
                        <div className="flex items-center gap-2 mb-3 text-gray-600 font-semibold">
                            <FaLaptop /> Live Preview
                        </div>
                        <div className="flex-1 bg-white border border-gray-300 rounded-xl shadow-inner overflow-y-auto">
                            {/* Uses dangerouslySetInnerHTML to render the actual HTML design */}
                            <div className="p-4" dangerouslySetInnerHTML={{ __html: formData.body || "<p class='text-gray-400 text-center mt-10'>Start typing to see preview...</p>" }} />
                        </div>
                    </div>

                </div>
            </div>

            {/* Footer Buttons */}
            <div className="p-4 border-t border-gray-200 bg-white rounded-b-2xl flex justify-end gap-3">
                <button onClick={() => setModalOpen(false)} className="px-5 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition font-medium">
                    {t("cancel")}
                </button>
                <button onClick={handleSubmit} className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-medium shadow-sm">
                    {t("saveChanges")}
                </button>
            </div>

          </div>
        </div>
      )}

      {/* ================= PREVIEW MODAL (Read Only) ================= */}
      {previewTemplate && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-xl w-[40rem] max-h-[90vh] overflow-y-auto p-6 relative animate-fade-in">
            <h2 className="text-xl font-bold text-gray-800 mb-4 border-b pb-2 sticky top-0 bg-white z-10">
              {t("preview")}: <span className="text-indigo-600">{previewTemplate.name}</span>
            </h2>

            <div className="space-y-4 text-sm text-gray-600">
               <div className="grid grid-cols-[80px_1fr] items-center gap-2">
                  <span className="font-bold text-gray-800 text-right">{t("from")}:</span>
                  <span>{previewTemplate.fromName} &lt;{previewTemplate.fromEmail}&gt;</span>
               </div>
               <div className="grid grid-cols-[80px_1fr] items-center gap-2">
                  <span className="font-bold text-gray-800 text-right">{t("subject")}:</span>
                  <span className="text-gray-900 font-medium">{previewTemplate.subject}</span>
               </div>

               <div className="mt-2 border border-gray-200 rounded-xl overflow-hidden shadow-inner bg-gray-50">
                  <div 
                    className="p-2 h-96 overflow-y-auto bg-white"
                    dangerouslySetInnerHTML={{ __html: previewTemplate.body }} 
                  />
               </div>
            </div>

            <div className="flex justify-end mt-6 sticky bottom-0 bg-white pt-2">
              <button onClick={() => setPreviewTemplate(null)} className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition">
                {t("closePreview")}
              </button>
            </div>
            <button onClick={() => setPreviewTemplate(null)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 z-20">✕</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Templates;
