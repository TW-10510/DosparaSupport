import React, { useState, useEffect } from "react";
import { FaEdit, FaTrash, FaSearch, FaLock, FaEye } from "react-icons/fa";

// ✅ Import Translation Hooks
import { useTranslation } from "../../context/TranslationContext";
import { getAdminTranslation } from "../../utils/adminTranslations";
import { useAuth } from "../../context/AuthContext";
import EmailLoader from "../../Components/EmailLoader";

// ✅ CONFIGURATION
const BASE_URL = process.env.REACT_APP_API_URL || "http://127.0.0.1:8013/api";
const USERS_API = `${BASE_URL}/auth`;
const ROLES_API = `${BASE_URL}`;

function UserManagement() {
  const { language } = useTranslation();
  const { normalizedRole, userId } = useAuth();

  const [users, setUsers] = useState([]);
  const [rolesList, setRolesList] = useState([]); 
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [editUser, setEditUser] = useState(null);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [roleFilter, setRoleFilter] = useState("all");

  // ✅ ROLE CHECKS
  const isViewer = normalizedRole === "viewer";
  const isSuperAdmin = normalizedRole === "super admin";
  const canDelete = isSuperAdmin;
  const canEdit = !isViewer;

  // ✅ HELPER: Check if a user is a Super Admin (Case Insensitive)
  const isRoleSuperAdmin = (role) =>
    String(role || "").toLowerCase() === "super admin";

  // ==========================
  // 1. FETCH USERS
  // ==========================
  const fetchUsers = async () => {
    try {
      const res = await fetch(`${USERS_API}/users`);
      const data = await res.json();

      setUsers(
        data.users.map((u) => ({
          id: u.id,
          name: `${u.first_name} ${u.last_name}`,
          email: u.email,
          role: u.role || "Basic",
          department: u.department || "-",
          mailsToday: u.mails_count || 0,
          status: u.is_active ? "active" : "inactive",
        }))
      );
    } catch (err) {
      console.error("Failed to load employees:", err);
    }
  };

  // ==========================
  // 2. FETCH ROLES
  // ==========================
  const fetchRoles = async () => {
    try {
      const res = await fetch(`${ROLES_API}/roles`);
      const data = await res.json();
      if (Array.isArray(data)) {
        setRolesList(data);
      }
    } catch (err) {
      console.error("Failed to load roles:", err);
    }
  };

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await Promise.all([fetchUsers(), fetchRoles()]);
      setLoading(false);
    };
    load();
  }, []);

  // Filtered users logic
  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.role.toLowerCase().includes(search.toLowerCase()) ||
      (u.department &&
        u.department.toLowerCase().includes(search.toLowerCase())) ||
      u.id.toString().includes(search);

    const matchesStatus = statusFilter === "all" || u.status === statusFilter;
    const matchesRole = roleFilter === "all" || u.role === roleFilter;
    return matchesSearch && matchesStatus && matchesRole;
  });

  // Handlers
  const handleSelectUser = (id) => {
    if (!canDelete) return; 
    setSelectedUsers((prev) =>
      prev.includes(id) ? prev.filter((u) => u !== id) : [...prev, id]
    );
  };

  const handleSelectAll = (isChecked) => {
    if (!canDelete) return;
    if (isChecked) {
      const allSelectableIds = filteredUsers
        .filter((u) => !isRoleSuperAdmin(u.role)) // ✅ Filter by Role Name, not ID 5
        .map((u) => u.id);
      setSelectedUsers(allSelectableIds);
    } else {
      setSelectedUsers([]);
    }
  };

  const handleDeleteSelected = async () => {
    if (!canDelete) return;
    if (!selectedUsers.length) return;
    if (!window.confirm("Are you sure you want to delete these users?")) return;

    try {
      await Promise.all(
        selectedUsers.map((id) =>
          fetch(`${USERS_API}/users/${id}`, {
            method: "DELETE",
            headers: {
              "X-User-Id": String(userId || ""),
            },
          }).then((res) => {
            if (!res.ok) throw new Error(`Failed to delete user ${id}`);
          })
        )
      );
      setUsers(users.filter((u) => !selectedUsers.includes(u.id)));
      setSelectedUsers([]);
    } catch (err) {
      console.error(err);
      alert(getAdminTranslation("deleteError", language));
    }
  };

  const handleEditSave = async () => {
    if (!canEdit) return;
    try {
      const res = await fetch(`${USERS_API}/users/${editUser.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-User-Id": String(userId || ""),
        },
        body: JSON.stringify({
          role: editUser.role,
          is_active: editUser.status === "active",
          department: editUser.department,
        }),
      });

      if (!res.ok) {
        throw new Error("Failed to update user");
      }

      setUsers((prev) =>
        prev.map((u) => (u.id === editUser.id ? editUser : u))
      );

      setEditUser(null);
    } catch (err) {
      console.error(err);
      alert(getAdminTranslation("updateError", language));
    }
  };

  const isAllSelected =
    filteredUsers.length > 0 &&
    filteredUsers
      .filter((u) => !isRoleSuperAdmin(u.role)) // ✅ Updated Check
      .every((u) => selectedUsers.includes(u.id));

  // UI
  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-100">
        <EmailLoader text="Loading Users..." />
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-100 min-h-screen space-y-6">
      <h1 className="text-3xl font-bold">
        {getAdminTranslation("usersTitle", language)}
      </h1>

      {/* FILTER BAR */}
      <div className="flex flex-wrap gap-4 items-center bg-white p-4 rounded-xl shadow">
        <div className="relative flex-1 min-w-[220px]">
          <FaSearch className="absolute left-3 top-3 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={getAdminTranslation("searchUserPlaceholder", language)}
            className="w-full pl-10 pr-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <select
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
          className="border rounded-lg px-3 py-2 capitalize"
        >
          <option value="all">
            {getAdminTranslation("allRoles", language)}
          </option>
          {rolesList.map((role) => (
            <option key={role.id} value={role.name}>
              {role.name}
            </option>
          ))}
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="border rounded-lg px-3 py-2"
        >
          <option value="all">
            {getAdminTranslation("allStatus", language)}
          </option>
          <option value="active">
            {getAdminTranslation("active", language)}
          </option>
          <option value="inactive">
            {getAdminTranslation("inactive", language)}
          </option>
        </select>

        {canDelete && (
          <button
            onClick={handleDeleteSelected}
            disabled={!selectedUsers.length}
            className="bg-red-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 disabled:opacity-40 hover:bg-red-700 transition"
          >
            <FaTrash />
          </button>
        )}
      </div>

      {/* TABLE */}
      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-y-auto max-h-[100vh]">
          <table className="w-full text-sm">
            <thead className="bg-indigo-100 sticky top-0 z-10">
              <tr className="text-left">
                <th className="p-4 w-12">
                  {canDelete && (
                    <input
                      type="checkbox"
                      checked={isAllSelected}
                      onChange={(e) => handleSelectAll(e.target.checked)}
                    />
                  )}
                </th>
                <th className="p-4">{getAdminTranslation("thId", language)}</th>
                <th className="p-4">
                  {getAdminTranslation("thEmployee", language)}
                </th>
                <th className="p-4">
                  {getAdminTranslation("thRole", language)}
                </th>
                <th className="p-4">
                  {getAdminTranslation("thDepartment", language)}
                </th>
                <th className="p-4 text-center">
                  {getAdminTranslation("thMailsSent", language)}
                </th>
                <th className="p-4 text-center">
                  {getAdminTranslation("thStatus", language)}
                </th>
                <th className="p-4 text-center">
                  {getAdminTranslation("thAction", language)}
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b hover:bg-indigo-50">
                    <td className="p-4 text-center">
                      {/* ✅ Lock ANY Super Admin, not just ID 5 */}
                      {isRoleSuperAdmin(user.role) ? (
                        <div
                          className="text-gray-400 flex justify-center"
                          title={getAdminTranslation("fixedAdmin", language)}
                        >
                          <FaLock size={14} />
                        </div>
                      ) : canDelete ? (
                        <input
                          type="checkbox"
                          checked={selectedUsers.includes(user.id)}
                          onChange={() => handleSelectUser(user.id)}
                        />
                      ) : null}
                    </td>

                    <td className="p-4 font-medium text-gray-500">
                      #{user.id}
                    </td>

                    <td
                      className="p-4 cursor-pointer"
                      onClick={() => setSelectedEmployee(user)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold shadow-sm">
                          {user.name[0]}
                        </div>
                        <div>
                          <p className="font-semibold text-indigo-700">
                            {user.name}
                          </p>
                          <p className="text-gray-500 text-xs">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 capitalize">
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          isRoleSuperAdmin(user.role)
                            ? "bg-purple-100 text-purple-700"
                            : "bg-blue-100 text-blue-700"
                        }`}
                      >
                        {user.role}
                      </span>
                    </td>
                    <td className="p-4 text-gray-600">{user.department}</td>
                    <td className="p-4 text-center font-bold text-gray-700">
                      {user.mailsToday}
                    </td>
                    <td className="p-4 text-center">
                      <span className="flex items-center justify-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            user.status === "active"
                              ? "bg-green-500"
                              : "bg-red-500"
                          }`}
                        />
                        <span className="capitalize text-gray-700">
                          {getAdminTranslation(user.status, language)}
                        </span>
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      {/* ✅ Lock Action Buttons for ANY Super Admin */}
                      {isRoleSuperAdmin(user.role) ? (
                        <span className="text-xs text-gray-400 font-medium border border-gray-200 px-2 py-1 rounded">
                          Fixed
                        </span>
                      ) : isViewer ? (
                        <button
                          onClick={() => setSelectedEmployee(user)}
                          className="text-gray-400 hover:text-gray-600 transition p-2"
                          title="View Details"
                        >
                          <FaEye size={16} />
                        </button>
                      ) : (
                        <button
                          onClick={() => setEditUser(user)}
                          className="text-indigo-600 hover:text-indigo-800 transition p-2 rounded hover:bg-indigo-100"
                          title={getAdminTranslation("edit", language)}
                        >
                          <FaEdit size={16} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="p-8 text-center text-gray-500">
                    {getAdminTranslation("noEmployeesFound", language)}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* VIEW DETAILS MODAL */}
      {selectedEmployee && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-[28rem] p-6 relative animate-fade-in">
            <h2 className="text-xl font-bold text-indigo-600 mb-4 border-b pb-2">
              {getAdminTranslation("employeeDetails", language)}
            </h2>
            <div className="space-y-3 text-sm text-gray-700">
              <p>
                <strong className="text-gray-900">
                  {getAdminTranslation("thId", language)}:
                </strong>{" "}
                <span className="text-gray-600">#{selectedEmployee.id}</span>
              </p>
              <p>
                <strong className="text-gray-900">
                  {getAdminTranslation("name", language)}:
                </strong>{" "}
                {selectedEmployee.name}
              </p>
              <p>
                <strong className="text-gray-900">
                  {getAdminTranslation("email", language)}:
                </strong>{" "}
                {selectedEmployee.email}
              </p>
              <p>
                <strong className="text-gray-900">
                  {getAdminTranslation("role", language)}:
                </strong>{" "}
                <span className="capitalize">{selectedEmployee.role}</span>
              </p>
              <p>
                <strong className="text-gray-900">
                  {getAdminTranslation("thDepartment", language)}:
                </strong>{" "}
                {selectedEmployee.department}
              </p>
              <p>
                <strong className="text-gray-900">
                  {getAdminTranslation("thMailsSent", language)}:
                </strong>{" "}
                {selectedEmployee.mailsToday}
              </p>
              <p>
                <strong className="text-gray-900">
                  {getAdminTranslation("status", language)}:
                </strong>{" "}
                <span
                  className={
                    selectedEmployee.status === "active"
                      ? "text-green-600 font-medium"
                      : "text-red-600 font-medium"
                  }
                >
                  <span className="capitalize">
                    {getAdminTranslation(selectedEmployee.status, language)}
                  </span>
                </span>
              </p>
            </div>
            <button
              onClick={() => setSelectedEmployee(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 transition"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* EDIT USER MODAL */}
      {editUser && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-[26rem] p-6 relative">
            <h2 className="text-xl font-bold text-indigo-600 mb-4 border-b pb-2">
              {getAdminTranslation("editUser", language)}:{" "}
              <span className="text-gray-800">{editUser.name}</span>{" "}
              <span className="text-sm font-normal text-gray-500">
                (#{editUser.id})
              </span>
            </h2>

            {/* DYNAMIC ROLE SELECTOR */}
            <div className="mb-4">
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                {getAdminTranslation("thRole", language)}
              </label>
              <select
                value={editUser.role}
                onChange={(e) =>
                  setEditUser({ ...editUser, role: e.target.value })
                }
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition capitalize"
              >
                {rolesList.length > 0 ? (
                  rolesList
                    .filter(
                      (role) =>
                        // Only show Super Admin option if the current user IS a Super Admin
                        isSuperAdmin || !isRoleSuperAdmin(role.name)
                    )
                    .map((role) => (
                      <option key={role.id} value={role.name}>
                        {role.name}
                      </option>
                    ))
                ) : (
                  <>
                    <option value="Admin">Admin</option>
                    <option value="Editor">Editor</option>
                    <option value="Viewer">Viewer</option>
                  </>
                )}
              </select>
            </div>

            {/* DEPARTMENT */}
            <div className="mb-4">
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                {getAdminTranslation("thDepartment", language)}
              </label>
              <select
                value={editUser.department}
                onChange={(e) =>
                  setEditUser({ ...editUser, department: e.target.value })
                }
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
              >
                <option value="-">
                  {getAdminTranslation("departmentSelect", language)}
                </option>
                <option value="IT">
                  {getAdminTranslation("deptIT", language)}
                </option>
                <option value="Support">
                  {getAdminTranslation("deptSupport", language)}
                </option>
                <option value="Marketing">
                  {getAdminTranslation("deptMarketing", language)}
                </option>
                <option value="Sales">
                  {getAdminTranslation("deptSales", language)}
                </option>
              </select>
            </div>

            {/* STATUS */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                {getAdminTranslation("thStatus", language)}
              </label>
              <select
                value={editUser.status}
                onChange={(e) =>
                  setEditUser({ ...editUser, status: e.target.value })
                }
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
              >
                <option value="active">
                  {getAdminTranslation("active", language)}
                </option>
                <option value="inactive">
                  {getAdminTranslation("inactive", language)}
                </option>
              </select>
            </div>

            {/* ACTION BUTTONS */}
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setEditUser(null)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition font-medium"
              >
                {getAdminTranslation("cancel", language)}
              </button>

              <button
                onClick={handleEditSave}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-medium shadow-md"
              >
                {getAdminTranslation("saveChanges", language)}
              </button>
            </div>

            {/* CLOSE */}
            <button
              onClick={() => setEditUser(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 transition"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default UserManagement;
