import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  FaUsers,
  FaEnvelope,
  FaFileAlt,
  FaTimesCircle,
  FaTimes,
  FaCheckCircle,
  FaBell,
  FaUserCircle
} from "react-icons/fa";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";

import { useTranslation } from "../../context/TranslationContext";
import { useAuth } from "../../context/AuthContext"; // ✅ Import Auth Context
import { getAdminTranslation } from "../../utils/adminTranslations";
import EmailLoader from "../../Components/EmailLoader";

const getUserId = () => {
  const uid = localStorage.getItem("user_id");
  if (!uid || uid === "null") return null;
  return uid;
};

const API = `${process.env.REACT_APP_API_URL}/auth`;

function AdminDashboard() {
  const { language } = useTranslation();
  const { user } = useAuth(); // ✅ Get current user data

  /* ---------------- STATE ---------------- */
  const [notifications, setNotifications] = useState([]);
  const [pendingUsers, setPendingUsers] = useState([]);
  const [selectedPending, setSelectedPending] = useState(null);
  const [users, setUsers] = useState([]);
  const [dashboardStats, setDashboardStats] = useState({ sent: 0, drafts: 0, failed: 0 });
  const [graphData, setGraphData] = useState([]);
  const [selectedPeriod, setSelectedPeriod] = useState("month");
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);
  
  const prevUsersRef = useRef([]);

  // ✅ HEARTBEAT (ADMIN)
  useEffect(() => {
    const userId = getUserId();
    if (!userId) return;

    const interval = setInterval(() => {
      fetch(`${process.env.REACT_APP_API_URL}/users/heartbeat`, {
        method: "POST",
        headers: {
          "X-User-Id": userId,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ user_id: userId }), 
      });
    }, 30000); 

    return () => clearInterval(interval);
  }, []);

  /* ---------------- API CALLS ---------------- */
  
  const fetchUsers = useCallback(async (initial = false) => {
    if (initial) setLoadingUsers(true);
    try {
      const userId = getUserId();
      if (!userId) return;

      const res = await fetch(`${API}/users`, {
        headers: {
          "X-User-Id": userId,
        },
      });
      if (!res.ok) return;
      const data = await res.json();
      if (data.users) {
        setUsers(data.users);
        prevUsersRef.current = data.users;
      }
    } catch (err) { console.error("Failed to fetch users", err); }
    finally {
      if (initial) setLoadingUsers(false);
    }
  }, []);

  const fetchPendingUsers = useCallback(async () => {
    try {
      const res = await fetch(`${API}/pending`);
      if (res.ok) {
        const data = await res.json();
        const pending = data.pending_users || [];
        setPendingUsers(pending);

        const pendingNotifications = pending.map((u) => ({
          id: u.id, 
          message: `${getAdminTranslation("approvalNeeded", language)}: ${u.first_name} ${u.last_name}`,
          time: "Waiting for approval",
        }));

        setNotifications(pendingNotifications);
      }
    } catch (err) { console.error("Failed pending users", err); }
  }, [language]); 

  const approveUser = async (id) => {
    try {
      const res = await fetch(`${API}/approve/${id}`, { method: "POST" });
      const data = await res.json();
      alert(data.message);
      setPendingUsers((prev) => prev.filter((u) => u.id !== id));
      setSelectedPending(null);
      fetchUsers();
    } catch (err) { console.error("Failed approve", err); }
  };

  const fetchDashboardStats = useCallback(async (initial = false) => {
    if (initial) setLoadingStats(true);
    try {
      const res = await fetch(`${API}/dashboard/stats`);
      if (res.ok) setDashboardStats(await res.json());
    } catch (err) { console.error("Failed stats", err); }
    finally {
      if (initial) setLoadingStats(false);
    }
  }, []);

  const fetchGraphData = useCallback(async () => {
    try {
      const res = await fetch(`${API}/dashboard/graph?period=${selectedPeriod}`);
      if (res.ok) {
        const result = await res.json();
        setGraphData(result.data || []);
      }
    } catch (err) { console.error("Failed graph", err); }
  }, [selectedPeriod]);


  useEffect(() => {
    fetchUsers(true);
    fetchPendingUsers();
    fetchDashboardStats(true);
    fetchGraphData(); 

    const interval = setInterval(() => {
      fetchUsers();
      fetchPendingUsers();
      fetchDashboardStats();
    }, 10000);

    return () => clearInterval(interval);
  }, [fetchUsers, fetchPendingUsers, fetchDashboardStats, fetchGraphData]); 

  /* ---------------- UI RENDER ---------------- */
  if (loadingUsers || loadingStats) {
    return (
      <div className="h-screen w-full bg-gray-50 flex items-center justify-center">
        <EmailLoader text="Loading Dashboard..." />
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-gray-50 flex flex-col font-sans overflow-hidden text-gray-800">
      
      {/* 1. HEADER (Fixed Height) */}
      <header className="h-16 px-6 bg-white border-b border-gray-200 flex justify-between items-center shrink-0 z-20">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-lg text-white">
            <FaUsers size={18} />
          </div>
          <h1 className="text-xl font-bold text-gray-900 tracking-tight">
            {getAdminTranslation("adminDashboard", language)}
          </h1>
        </div>

        {/* ✅ CHANGED: Replaced System Status with User Info */}
        <div className="flex items-center gap-3">
           <div className="text-right hidden sm:block">
             <p className="text-sm font-bold text-gray-900">
                {user ? user.name : "Administrator"}
             </p>
             <div className="flex justify-end">
                <span className="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full font-bold uppercase tracking-wide border border-indigo-100">
                    {user ? user.role : "Admin"}
                </span>
             </div>
           </div>
           <div className="h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 border border-gray-200">
              <FaUserCircle size={24} />
           </div>
        </div>
      </header>

      {/* 2. MAIN CONTENT */}
      <main className="flex-1 flex flex-col p-4 gap-4 overflow-hidden">
        
        {/* --- TOP ROW: Graph (2/3) & KPIs (1/3) --- */}
        <div className="h-[35%] min-h-[280px] flex gap-4 shrink-0">
          
          {/* Graph Section */}
          <div className="flex-[2] bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex flex-col">
            <div className="flex justify-between items-center mb-2">
              <div>
                <p className="text-xs text-gray-500 uppercase font-bold tracking-wide">
                  {getAdminTranslation("totalTraffic", language)}
                </p>
                <h2 className="text-2xl font-bold text-gray-900">
                  {(dashboardStats.sent + dashboardStats.drafts + dashboardStats.failed).toLocaleString()}
                </h2>
              </div>
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="bg-gray-50 border border-gray-300 text-gray-700 text-xs rounded-lg px-2.5 py-1.5 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              >
                <option value="day">{getAdminTranslation("last10Days", language)}</option>
                <option value="month">{getAdminTranslation("last12Months", language)}</option>
                <option value="year">{getAdminTranslation("allTime", language)}</option>
              </select>
            </div>
            
            <div className="flex-1 w-full min-h-0">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={graphData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorAdmin" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
                  <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 11 }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: "#9ca3af", fontSize: 11 }} />
                  <Tooltip contentStyle={{ borderRadius: "8px", border: "none", backgroundColor: "#1f2937", color: "#fff", fontSize: "12px" }} itemStyle={{ color: "#fff" }} />
                  <Area type="monotone" dataKey="emailsSent" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorAdmin)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* KPI Grid */}
          <div className="flex-1 grid grid-cols-2 gap-3 h-full">
            <MetricCard title={getAdminTranslation("employees", language)} value={users.length} icon={<FaUsers />} color="bg-blue-600" />
            <MetricCard title={getAdminTranslation("emailsSent", language)} value={dashboardStats.sent} icon={<FaEnvelope />} color="bg-emerald-600" />
            <MetricCard title={getAdminTranslation("drafts", language)} value={dashboardStats.drafts} icon={<FaFileAlt />} color="bg-amber-500" />
            <MetricCard title={getAdminTranslation("failed", language)} value={dashboardStats.failed} icon={<FaTimesCircle />} color="bg-rose-500" />
          </div>
        </div>

        {/* --- BOTTOM ROW: Users Table & Notifications --- */}
        <div className="flex-1 min-h-0 flex gap-4">
          
          {/* USERS TABLE CONTAINER */}
          <div className="flex-[2] bg-white rounded-xl border border-gray-200 shadow-sm flex flex-col overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50 shrink-0">
              <h3 className="font-bold text-gray-700 flex items-center gap-2">
                {getAdminTranslation("usersOverview", language)}
              </h3>
              <span className="text-xs bg-white border border-gray-200 px-2 py-0.5 rounded text-gray-500">
                {users.length} Users
              </span>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-white text-gray-500 text-xs uppercase font-semibold sticky top-0 shadow-sm z-10">
                  <tr>
                    <th className="px-5 py-3 bg-gray-50/95">ID</th>
                    <th className="px-5 py-3 bg-gray-50/95">{getAdminTranslation("name", language)}</th>
                    <th className="px-5 py-3 bg-gray-50/95">{getAdminTranslation("role", language)}</th>
                    <th className="px-5 py-3 bg-gray-50/95 text-center">{getAdminTranslation("mails", language)}</th>
                    <th className="px-5 py-3 bg-gray-50/95 text-right">{getAdminTranslation("status", language)}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {users.length > 0 ? users.map((u) => (
                    <tr key={u.id} className="hover:bg-indigo-50/40 transition-colors">
                      <td className="px-5 py-3 text-gray-400 text-xs font-mono">#{u.id}</td>
                      <td className="px-5 py-3 font-medium text-gray-700">{u.first_name} {u.last_name}</td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wide ${
                          u.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-center font-bold text-gray-600">{u.mails_count || 0}</td>
                      <td className="px-5 py-3 text-right">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium ${
                          u.is_online ? "bg-green-50 text-green-700 border border-green-100" : "bg-gray-50 text-gray-500 border border-gray-100"
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${u.is_online ? 'bg-green-500' : 'bg-gray-400'}`}></span>
                          {u.is_online ? "Online" : "Offline"}
                        </span>
                      </td>
                    </tr>
                  )) : (
                    <tr><td colSpan="5" className="p-10 text-center text-gray-400">No users found</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* NOTIFICATIONS PANEL */}
          <div className="flex-1 bg-white rounded-xl border border-gray-200 shadow-sm flex flex-col overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-100 bg-gray-50 shrink-0 flex justify-between items-center">
              <h3 className="font-bold text-gray-700 flex items-center gap-2">
                {getAdminTranslation("notifications", language)}
              </h3>
              {(pendingUsers.length > 0 || notifications.length > 0) && (
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                </span>
              )}
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              
              {pendingUsers.map((u) => (
                <div key={u.id} onClick={() => setSelectedPending(u)} className="bg-amber-50 border border-amber-100 p-3 rounded-lg cursor-pointer hover:bg-amber-100 transition shadow-sm group">
                  <div className="flex justify-between items-start">
                    <div className="flex gap-3">
                      <div className="mt-1 bg-amber-200 text-amber-700 w-6 h-6 rounded flex items-center justify-center text-xs">
                        <FaUsers />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-800">{getAdminTranslation("approvalNeeded", language)}</p>
                        <p className="text-xs text-gray-500">{u.first_name} {u.last_name}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-amber-600 bg-white px-1.5 py-0.5 rounded border border-amber-100 group-hover:border-amber-200">
                      ACTION
                    </span>
                  </div>
                </div>
              ))}

              {notifications.map((n) => (
                <div key={n.id} className="bg-white border border-gray-100 p-3 rounded-lg flex justify-between group hover:border-indigo-200 transition shadow-sm">
                  <div className="flex gap-3">
                    <div className="mt-1 bg-indigo-50 text-indigo-500 w-6 h-6 rounded flex items-center justify-center text-xs">
                      <FaBell />
                    </div>
                    <div>
                      <p className="text-sm text-gray-700 leading-tight">{n.message}</p>
                      <p className="text-[10px] text-gray-400 mt-1">{n.time}</p>
                    </div>
                  </div>
                </div>
              ))}

              {notifications.length === 0 && pendingUsers.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-gray-300">
                  <FaCheckCircle size={32} className="mb-2 opacity-50" />
                  <p className="text-xs font-medium">All caught up</p>
                </div>
              )}
            </div>
          </div>

        </div>
      </main>

      {/* 3. MODAL (Popup) */}
      {selectedPending && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="bg-indigo-600 p-4 flex justify-between items-center text-white">
              <h3 className="font-bold">{getAdminTranslation("approveRequest", language)}</h3>
              <button onClick={() => setSelectedPending(null)} className="hover:text-indigo-200"><FaTimes /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-lg font-bold text-gray-500">
                  {selectedPending.first_name[0]}
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-lg">{selectedPending.first_name} {selectedPending.last_name}</h4>
                  <p className="text-sm text-gray-500">{selectedPending.email}</p>
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg text-sm border border-gray-100">
                <div className="flex justify-between mb-1">
                  <span className="text-gray-500">Role:</span>
                  <span className="font-semibold capitalize">{selectedPending.role}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Date:</span>
                  <span className="font-semibold">Today</span>
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={() => setSelectedPending(null)} className="flex-1 py-2 border border-gray-300 rounded-lg text-sm font-semibold hover:bg-gray-50">
                  Cancel
                </button>
                <button onClick={() => approveUser(selectedPending.id)} className="flex-1 py-2 bg-indigo-600 text-white rounded-lg text-sm font-semibold hover:bg-indigo-700 shadow">
                  Approve
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= COMPACT METRIC CARD ================= */
function MetricCard({ title, value, icon, color }) {
  return (
    <div className={`relative overflow-hidden rounded-xl p-4 text-white shadow-md flex flex-col justify-between ${color}`}>
      <div className="absolute -right-2 -top-2 text-white/10 text-6xl">
        {icon}
      </div>
      <div className="relative z-10">
        <p className="text-[12px] font-bold uppercase opacity-80 tracking-wider mb-1">{title}</p>
        <p className="text-3xl font-extrabold mt-12">{value !== undefined ? value.toLocaleString() : "0"}</p>
      </div>
    </div>
  );
}

export default AdminDashboard;