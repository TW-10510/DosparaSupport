import React, { useState } from "react";

// ✅ CORRECTED PATHS (Go up two levels)
import { useTranslation } from "../../context/TranslationContext";
import { getAdminTranslation } from "../../utils/adminTranslations";

function Settings() {
  const { language, setLanguage } = useTranslation();

  const [settings, setSettings] = useState({
    appName: "Admin Dashboard",
    language: "English",
    timezone: "UTC",
    emailFrom: "support@company.com",
    replyTo: "noreply@company.com",
    emailEnabled: true,
    twoFactorAuth: false,
    sessionTimeout: 30,
  });

  const handleChange = (key, value) => {
    setSettings((prev) => ({ ...prev, [key]: value }));

    // ✅ Immediate Language Switch Logic for Admin
    if (key === "language") {
      const langMap = { English: "en", Japanese: "ja" };
      if (langMap[value]) {
        setLanguage(langMap[value]);
      }
    }
  };

  const handleSave = () => {
    alert(getAdminTranslation("savedAlert", language));
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen space-y-8">
      <h1 className="text-3xl font-bold text-gray-800">
        {getAdminTranslation("adminSettings", language)}
      </h1>

      {/* ================= GENERAL SETTINGS ================= */}
      <div className="bg-white rounded-2xl shadow p-6 space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">
          {getAdminTranslation("generalSettings", language)}
        </h2>

        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <label className="block font-medium mb-1">
              {getAdminTranslation("appName", language)}
            </label>
            <input
              value={settings.appName}
              onChange={(e) => handleChange("appName", e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block font-medium mb-1">
              {getAdminTranslation("defaultLanguage", language)}
            </label>
            <select
              value={settings.language}
              onChange={(e) => handleChange("language", e.target.value)}
              className="w-full border rounded px-3 py-2"
            >
              <option>English</option>
              <option>Japanese</option>
            </select>
          </div>

          <div>
            <label className="block font-medium mb-1">
              {getAdminTranslation("timeZone", language)}
            </label>
            <select
              value={settings.timezone}
              onChange={(e) => handleChange("timezone", e.target.value)}
              className="w-full border rounded px-3 py-2"
            >
              <option>UTC</option>
              <option>Asia/Tokyo</option>
              <option>Asia/Kolkata</option>
              <option>America/New_York</option>
            </select>
          </div>
        </div>
      </div>

      {/* ================= EMAIL SETTINGS ================= */}
      <div className="bg-white rounded-2xl shadow p-6 space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">
          {getAdminTranslation("emailSettings", language)}
        </h2>

        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <label className="block font-medium mb-1">
              {getAdminTranslation("fromEmail", language)}
            </label>
            <input
              value={settings.emailFrom}
              onChange={(e) => handleChange("emailFrom", e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div>
            <label className="block font-medium mb-1">
              {getAdminTranslation("replyTo", language)}
            </label>
            <input
              value={settings.replyTo}
              onChange={(e) => handleChange("replyTo", e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div className="flex items-center gap-3 mt-2">
            <input
              type="checkbox"
              checked={settings.emailEnabled}
              onChange={(e) => handleChange("emailEnabled", e.target.checked)}
            />
            <span>{getAdminTranslation("enableEmail", language)}</span>
          </div>
        </div>
      </div>

      {/* ================= SECURITY SETTINGS ================= */}
      <div className="bg-white rounded-2xl shadow p-6 space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">
          {getAdminTranslation("securitySettings", language)}
        </h2>

        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={settings.twoFactorAuth}
              onChange={(e) => handleChange("twoFactorAuth", e.target.checked)}
            />
            <span>{getAdminTranslation("enable2FA", language)}</span>
          </div>

          <div>
            <label className="block font-medium mb-1">
              {getAdminTranslation("sessionTimeout", language)}
            </label>
            <input
              type="number"
              value={settings.sessionTimeout}
              onChange={(e) => handleChange("sessionTimeout", e.target.value)}
              className="w-full border rounded px-3 py-2"
            />
          </div>
        </div>
      </div>

      {/* ================= SAVE ================= */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 font-medium"
        >
          {getAdminTranslation("saveSettings", language)}
        </button>
      </div>
    </div>
  );
}

export default Settings;
