import React, { useEffect, useState, useMemo } from "react";
import {
  FaFileAlt,
  FaUser,
  FaEnvelope,
  FaFilePdf,
  FaFileExcel,
  FaDownload,
  FaSearch,
  FaChevronDown,
  FaSlidersH,
  FaCalendarAlt,
  FaTimes
} from "react-icons/fa";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable"; 
import ExcelJS from "exceljs"; 
import { saveAs } from "file-saver"; 

// ✅ 1. Import BOTH images with unique names
import PdfHeaderImage from "../../assets/letter_pad.png";  // For PDF Background
import ExcelLogoImage from "../../assets/image.png";       // For Excel Header

const API_BASE = process.env.REACT_APP_API_URL || "http://localhost:8000/api";

function ReportsLogs() {
  const [reports, setReports] = useState([]);
  const [logs, setLogs] = useState([]);
  const [todayOnly, setTodayOnly] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [downloadDropdownOpen, setDownloadDropdownOpen] = useState(false);
  const [showFilters, setShowFilters] = useState(false); 

  const allColumns = [
    { key: "received_at", label: "Received", width: 20 },
    { key: "handled_at", label: "Handled", width: 20 },
    { key: "subject", label: "Subject", width: 40 },
    { key: "handled_by", label: "Handled By", width: 25 },
    { key: "status", label: "Status", width: 15 },
  ];

  const [visibleColumns, setVisibleColumns] = useState(
    allColumns.map((c) => c.key)
  );

  const toggleColumn = (key) => {
    setVisibleColumns((prev) =>
      prev.includes(key) ? prev.filter((v) => v !== key) : [...prev, key]
    );
  };

  const initialFilters = {
    received_from: "",
    received_to: "",
    handled_from: "",
    handled_to: "",
    subject: "",
    handled_by: "",
    status: "",
  };

  const [columnFilters, setColumnFilters] = useState(initialFilters);

  const resetFilters = () => {
    setColumnFilters(initialFilters);
    setTodayOnly(false);
    setVisibleColumns(allColumns.map((c) => c.key)); 
  };

  const activeFilterCount = Object.values(columnFilters).filter(Boolean).length;

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [emailRes, logsRes] = await Promise.all([
          fetch(`${API_BASE}/reports/email-activity`),
          fetch(
            `${API_BASE}/reports/logs/system?limit=500&today_only=${todayOnly}`
          ),
        ]);

        if (!emailRes.ok || !logsRes.ok) {
          throw new Error("Failed to fetch reports/logs");
        }

        const emailData = await emailRes.json();
        const logsData = await logsRes.json();

        setReports([
          { id: 1, title: "Total Emails", count: emailData.total, icon: <FaEnvelope />, color: "bg-blue-100 text-blue-600" },
          { id: 2, title: "Sent Emails", count: emailData.sent, icon: <FaFileAlt />, color: "bg-green-100 text-green-600" },
          { id: 3, title: "Failed Emails", count: emailData.failed, icon: <FaUser />, color: "bg-red-100 text-red-600" },
        ]);

        setLogs(logsData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [todayOnly]);

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const received = log.received_at ? new Date(log.received_at) : null;
      const receivedFrom = columnFilters.received_from ? new Date(columnFilters.received_from) : null;
      const receivedTo = columnFilters.received_to ? new Date(columnFilters.received_to) : null;
      if (receivedTo) receivedTo.setDate(receivedTo.getDate() + 1);

      return (
        (!receivedFrom || (received && received >= receivedFrom)) &&
        (!receivedTo || (received && received < receivedTo)) &&
        (!columnFilters.subject || log.subject?.toLowerCase().includes(columnFilters.subject.toLowerCase())) &&
        (!columnFilters.handled_by || log.handled_by?.toLowerCase().includes(columnFilters.handled_by.toLowerCase())) &&
        (!columnFilters.status || log.status === columnFilters.status)
      );
    });
  }, [logs, columnFilters]);

  // ==================== 📄 GENERATE PDF (Uses Letter Pad) ====================
  const generatePDF = () => {
    const doc = new jsPDF();

    // 1. Use 'PdfHeaderImage' (Letter Pad) for background
    try {
        doc.addImage(PdfHeaderImage, 'PNG', 0, 0, 210, 297);
    } catch (e) {
        console.warn("PDF Image error", e);
    }

    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(40, 40, 40);
    doc.text("System Logs Report", 105, 50, { align: "center" }); 

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 100, 100);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 105, 56, { align: "center" });

    let startY = 65;
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.setFont("helvetica", "bold");
    doc.text("Summary:", 14, startY);
    
    startY += 6;
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    
    let kpiX = 14;
    reports.forEach((r) => {
        doc.text(`${r.title}: ${r.count}`, kpiX, startY);
        kpiX += 50; 
    });

    const tableColumn = ["Received", "Handled", "Subject", "Handled By", "Status"];
    const tableRows = filteredLogs.map(log => [
        log.received_at ? new Date(log.received_at).toLocaleDateString() : "-",
        log.handled_at ? new Date(log.handled_at).toLocaleDateString() : "-",
        log.subject || "-",
        log.handled_by || "-",
        log.status || "-"
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: startY + 10,
      theme: 'grid',
      headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: 'bold' },
      styles: { fontSize: 8, cellPadding: 3 },
      margin: { top: 40, bottom: 30 }, 
    });

    doc.save("System_Logs_Report.pdf");
    setDownloadDropdownOpen(false);
  };

  // ==================== 📊 GENERATE EXCEL (Uses Simple Logo) ====================
  const generateExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("System Logs");

    // 2. Use 'ExcelLogoImage' (Simple Logo) for Excel
    try {
        const response = await fetch(ExcelLogoImage);
        const buffer = await response.arrayBuffer();
        const logoId = workbook.addImage({
            buffer: buffer,
            extension: 'png',
        });
        
        // Position the logo
        worksheet.addImage(logoId, {
            tl: { col: 0, row: 0 },
            ext: { width: 120, height: 50 } 
        });
    } catch (e) {
        console.warn("Excel Logo error", e);
    }

    const titleRow = worksheet.getRow(5);
    titleRow.getCell(1).value = "SYSTEM LOGS REPORT";
    worksheet.mergeCells('A5:E5');
    titleRow.getCell(1).font = { name: 'Arial', family: 4, size: 16, bold: true, color: { argb: 'FF4F46E5' } }; 
    titleRow.getCell(1).alignment = { vertical: 'middle', horizontal: 'center' };
    
    const dateRow = worksheet.getRow(6);
    dateRow.getCell(1).value = `Generated on: ${new Date().toLocaleString()}`;
    worksheet.mergeCells('A6:E6');
    dateRow.getCell(1).font = { size: 10, italic: true, color: { argb: 'FF666666' } };
    dateRow.getCell(1).alignment = { horizontal: 'center' };

    const activeColumns = allColumns.filter(c => visibleColumns.includes(c.key));
    
    worksheet.getRow(8).values = activeColumns.map(c => c.label);
    worksheet.columns = activeColumns.map(c => ({ key: c.key, width: c.width || 25 }));

    const headerRow = worksheet.getRow(8);
    headerRow.eachCell((cell) => {
        cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF4F46E5' } 
        };
        cell.font = {
            color: { argb: 'FFFFFFFF' }, 
            bold: true
        };
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
    });

    filteredLogs.forEach((log) => {
        const rowData = {};
        activeColumns.forEach(col => {
            if ((col.key === 'received_at' || col.key === 'handled_at') && log[col.key]) {
                rowData[col.key] = new Date(log[col.key]).toLocaleString();
            } else {
                rowData[col.key] = log[col.key] || '-';
            }
        });
        const row = worksheet.addRow(rowData);
        
        row.eachCell((cell) => {
            cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
            cell.alignment = { vertical: 'middle', wrapText: true };
        });
    });

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), "System_Logs_Report.xlsx");
    setDownloadDropdownOpen(false);
  };

  if (loading) return <div className="p-6 text-gray-600 text-center">Loading Data...</div>;
  if (error) return <div className="p-6 text-red-600 text-center">Error: {error}</div>;

  return (
    <div className="p-6 bg-gray-50 min-h-screen space-y-8 font-sans">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h1 className="text-3xl font-bold text-gray-800 tracking-tight">System Logs</h1>
            <p className="text-gray-500 text-sm mt-1">Monitor email activity and processing status</p>
        </div>

        <div className="relative">
          <button
            onClick={() => setDownloadDropdownOpen(!downloadDropdownOpen)}
            className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl hover:bg-indigo-700 transition shadow-sm font-medium"
          >
            <FaDownload className="text-sm" /> Export Data <FaChevronDown className="text-xs opacity-70"/>
          </button>

          {downloadDropdownOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-100 rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
              <button
                onClick={generatePDF}
                className="flex items-center gap-3 w-full px-4 py-3 hover:bg-gray-50 text-gray-700 transition"
              >
                <FaFilePdf className="text-red-500" /> Export as PDF
              </button>
              <button
                onClick={generateExcel} 
                className="flex items-center gap-3 w-full px-4 py-3 hover:bg-gray-50 text-gray-700 transition border-t border-gray-50"
              >
                <FaFileExcel className="text-green-500" /> Export as Excel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {reports.map((r) => (
          <div key={r.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex items-center justify-between hover:shadow-md transition-shadow">
            <div>
              <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">{r.title}</p>
              <p className="text-3xl font-extrabold text-gray-900 mt-1">{r.count}</p>
            </div>
            <div className={`p-4 rounded-xl ${r.color} text-xl`}>{r.icon}</div>
          </div>
        ))}
      </div>

      {/* 🛠️ FILTER & COLUMN CONTAINER */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm">
        
        <div className="p-4 flex flex-col lg:flex-row justify-between items-center gap-4">
            <div className="relative w-full lg:w-96">
                <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                    type="text" 
                    placeholder="Search subject..." 
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition outline-none"
                    value={columnFilters.subject}
                    onChange={(e) => setColumnFilters({ ...columnFilters, subject: e.target.value })}
                />
            </div>

            <div className="flex items-center gap-3 w-full lg:w-auto overflow-x-auto">
                <label className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border cursor-pointer transition select-none ${todayOnly ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                    <input 
                        type="checkbox" 
                        className="hidden" 
                        checked={todayOnly} 
                        onChange={() => setTodayOnly(!todayOnly)}
                    />
                    <FaCalendarAlt className={todayOnly ? "text-indigo-600" : "text-gray-400"} />
                    <span className="whitespace-nowrap font-medium text-sm">Today Only</span>
                </label>

                <button 
                    onClick={() => setShowFilters(!showFilters)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border transition ${showFilters || activeFilterCount > 0 ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                >
                    <FaSlidersH />
                    <span className="font-medium text-sm">Filters & View</span>
                    {activeFilterCount > 0 && (
                        <span className="bg-indigo-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                            {activeFilterCount}
                        </span>
                    )}
                </button>

                 {(activeFilterCount > 0 || todayOnly || visibleColumns.length !== allColumns.length) && (
                    <button 
                        onClick={resetFilters}
                        className="p-2.5 text-red-500 hover:bg-red-50 rounded-lg transition"
                        title="Reset All"
                    >
                        <FaTimes />
                    </button>
                 )}
            </div>
        </div>

        {showFilters && (
            <div className="px-6 pb-6 pt-4 border-t border-gray-100 bg-gray-50/50 space-y-6">
                 <div>
                    <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block">
                        Visible Columns
                    </label>
                    <div className="flex flex-wrap gap-2">
                        {allColumns.map((c) => {
                            const isActive = visibleColumns.includes(c.key);
                            return (
                                <button
                                    key={c.key}
                                    onClick={() => toggleColumn(c.key)}
                                    className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                                        isActive
                                            ? "bg-indigo-600 border-indigo-600 text-white shadow-sm"
                                            : "bg-white border-gray-300 text-gray-600 hover:bg-gray-100"
                                    }`}
                                >
                                    {isActive && <span className="mr-1">✓</span>}
                                    {c.label}
                                </button>
                            );
                        })}
                    </div>
                 </div>

                 <div className="border-t border-gray-200"></div>

                 <div>
                    <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block">
                        Advanced Filters
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs text-gray-500 font-medium">Status</label>
                            <div className="relative">
                                <select
                                    value={columnFilters.status}
                                    onChange={(e) => setColumnFilters({ ...columnFilters, status: e.target.value })}
                                    className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                                >
                                    <option value="">All Statuses</option>
                                    <option value="sent">Sent</option>
                                    <option value="failed">Failed</option>
                                    <option value="pending_approval">Pending Approval</option>
                                </select>
                                <FaChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 pointer-events-none" />
                            </div>
                        </div>

                        <div className="space-y-1">
                            <label className="text-xs text-gray-500 font-medium">Handled By</label>
                            <input
                                type="text"
                                placeholder="Agent Name..."
                                value={columnFilters.handled_by}
                                onChange={(e) => setColumnFilters({ ...columnFilters, handled_by: e.target.value })}
                                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                        </div>

                        <div className="space-y-1">
                            <label className="text-xs text-gray-500 font-medium">Date From</label>
                            <input
                                type="date"
                                value={columnFilters.received_from}
                                onChange={(e) => setColumnFilters({ ...columnFilters, received_from: e.target.value })}
                                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs text-gray-500 font-medium">Date To</label>
                            <input
                                type="date"
                                value={columnFilters.received_to}
                                onChange={(e) => setColumnFilters({ ...columnFilters, received_to: e.target.value })}
                                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                        </div>
                    </div>
                 </div>
            </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-50 text-gray-500 font-semibold border-b border-gray-200">
              <tr>
                {allColumns.map(
                  (c) =>
                    visibleColumns.includes(c.key) && (
                      <th key={c.key} className="p-4 whitespace-nowrap">
                        {c.label}
                      </th>
                    )
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredLogs.length > 0 ? (
                filteredLogs.map((log, i) => (
                    <tr key={i} className="hover:bg-gray-50/80 transition-colors align-top">
                    {allColumns.map(
                        (c) =>
                        visibleColumns.includes(c.key) && (
                            <td key={c.key} className="p-4 text-gray-700 break-words max-w-xs">
                             {c.key === 'status' ? (
                                <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${
                                    log[c.key] === 'sent' ? 'bg-green-100 text-green-700' :
                                    log[c.key] === 'failed' ? 'bg-red-100 text-red-700' :
                                    'bg-yellow-100 text-yellow-700'
                                }`}>
                                    {log[c.key]}
                                </span>
                             ) : (
                                log[c.key] || <span className="text-gray-300">—</span>
                             )}
                            </td>
                        )
                    )}
                    </tr>
                ))
              ) : (
                <tr>
                    <td colSpan={visibleColumns.length} className="p-8 text-center text-gray-400">
                        No logs found matching your filters.
                    </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        <div className="p-4 border-t border-gray-200 text-xs text-gray-400 text-center">
             Showing {filteredLogs.length} records
        </div>
      </div>
    </div>
  );
}

export default ReportsLogs;