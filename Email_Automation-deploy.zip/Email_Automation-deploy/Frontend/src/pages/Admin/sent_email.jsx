import React, { useState, useEffect } from "react";
import { FaEnvelope, FaCheckCircle, FaClock } from "react-icons/fa";

// ✅ Import Translation Hooks
import { useTranslation } from "../../context/TranslationContext";
import { getAdminTranslation } from "../../utils/adminTranslations";
import EmailLoader from "../../Components/EmailLoader";

function SentEmail() {
  const { language } = useTranslation();

  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters State
  const [statusFilter, setStatusFilter] = useState("all");
  const [timeFilter, setTimeFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEmail, setSelectedEmail] = useState(null);
// 1. Fetch Data
  useEffect(() => {
    const fetchEmails = async () => {
      try {
        // ✅ 1. Use the Env Variable (Port 8013) + /auth
        const API = `${process.env.REACT_APP_API_URL}/auth`;
        
        // ✅ 2. Define 'response' properly using the /emails endpoint
        const response = await fetch(`${API}/emails`);

        // ✅ 3. Check if response is valid
        if (!response.ok) throw new Error("Failed to fetch emails");
        
        const data = await response.json();
        
        // ✅ 4. Use 'data.emails' (Matches the /emails endpoint)
        setEmails(data.emails || []);
        setLoading(false);

      } catch (err) {
        console.error(err);
        setError(getAdminTranslation("loadError", language));
        setLoading(false);
      }
    };
    fetchEmails();
  }, [language]);
  // 2. Helper: Calculate Counts
  const totalEmails = emails.length;
  const sentCount = emails.filter((e) =>
    ["sent", "replied", "closed", "open"].includes(e.status?.toLowerCase())
  ).length;
  const pendingCount = emails.filter((e) =>
    ["pending", "draft", "in progress", "new", "pending_approval"].includes(
      e.status?.toLowerCase()
    )
  ).length;

  // 3. Helper: Time Ago (Translated)
  const getTimeAgo = (dateString) => {
    const created = new Date(dateString);
    const now = new Date();
    const diffHours = (now - created) / (1000 * 60 * 60);
    const diffDays = diffHours / 24;

    if (diffHours < 1) return getAdminTranslation("justNow", language);
    if (diffHours < 24)
      return `${Math.floor(diffHours)} ${getAdminTranslation(
        "hoursAgo",
        language
      )}`;
    if (diffDays < 7)
      return `${Math.floor(diffDays)} ${getAdminTranslation(
        "daysAgo",
        language
      )}`;
    if (diffDays < 30)
      return `${Math.floor(diffDays / 7)} ${getAdminTranslation(
        "weeksAgo",
        language
      )}`;
    return `${Math.floor(diffDays / 30)} ${getAdminTranslation(
      "monthsAgo",
      language
    )}`;
  };

  // 4. Helper: Get Status Color
  const getStatusDotColor = (status) => {
    switch (status?.toLowerCase()) {
      case "replied":
      case "sent":
      case "closed":
      case "open":
        return "bg-green-500";
      case "pending":
      case "in progress":
      case "draft":
      case "pending_approval":
        return "bg-yellow-500";
      case "failed":
        return "bg-red-500";
      default:
        return "bg-gray-400";
    }
  };

  // 5. Filter Logic
  const filteredEmails = emails.filter((email) => {
    // A. Status Filter
    if (statusFilter !== "all") {
      const s = email.status?.toLowerCase() || "pending";
      if (statusFilter === "pending") {
        if (
          ![
            "pending",
            "draft",
            "in progress",
            "new",
            "pending_approval",
          ].includes(s)
        )
          return false;
      } else if (statusFilter === "sent") {
        if (!["sent", "replied", "closed", "open"].includes(s)) return false;
      }
    }

    // B. Search
    const searchLower = searchQuery.toLowerCase();
    const employeeName = email.employee_name
      ? email.employee_name.toLowerCase()
      : "";
    const matchesSearch =
      employeeName.includes(searchLower) ||
      email.recipient_email.toLowerCase().includes(searchLower) ||
      (email.id && email.id.toString().includes(searchLower));

    if (!matchesSearch) return false;

    // C. Time Filter
    const created = new Date(email.created_at);
    const now = new Date();
    const diffHours = (now - created) / (1000 * 60 * 60);
    const diffDays = diffHours / 24;

    if (timeFilter === "24h" && diffHours > 24) return false;
    if (timeFilter === "3d" && (diffDays < 1 || diffDays > 3)) return false;
    if (timeFilter === "1w" && diffDays < 7) return false;
    if (timeFilter === "1m" && diffDays < 30) return false;

    return true;
  });

  if (loading)
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-50">
        <EmailLoader text={getAdminTranslation("loadingRecords", language)} />
      </div>
    );
  if (error) return <div className="p-8 text-center text-red-600">{error}</div>;

  return (
    <div className="p-6 bg-gray-50 min-h-screen font-sans text-gray-800">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">
        {getAdminTranslation("emailRecords", language)}
      </h1>

      {/* ================= CARDS SECTION ================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Total Emails */}
        <div className="bg-indigo-600 rounded-xl p-6 text-white shadow-lg flex flex-col justify-between h-32">
          <div className="flex justify-between items-start">
            <span className="text-sm font-medium opacity-80">
              {getAdminTranslation("totalEmails", language)}
            </span>
            <FaEnvelope className="text-xl opacity-60" />
          </div>
          <span className="text-4xl font-bold">{totalEmails}</span>
        </div>

        {/* Sent / Replied */}
        <div className="bg-blue-500 rounded-xl p-6 text-white shadow-lg flex flex-col justify-between h-32">
          <div className="flex justify-between items-start">
            <span className="text-sm font-medium opacity-80">
              {getAdminTranslation("sentReplied", language)}
            </span>
            <FaCheckCircle className="text-xl opacity-60" />
          </div>
          <span className="text-4xl font-bold">{sentCount}</span>
        </div>

        {/* Pending / Drafts */}
        <div className="bg-sky-400 rounded-xl p-6 text-white shadow-lg flex flex-col justify-between h-32">
          <div className="flex justify-between items-start">
            <span className="text-sm font-medium opacity-80">
              {getAdminTranslation("pendingDrafts", language)}
            </span>
            <FaClock className="text-xl opacity-60" />
          </div>
          <span className="text-4xl font-bold">{pendingCount}</span>
        </div>
      </div>

      {/* ================= FILTER BAR ================= */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-6 flex flex-col md:flex-row justify-between items-center gap-4">
        {/* Left: Search */}
        <div className="w-full md:w-1/3 relative">
          <span className="absolute left-3 top-2.5 text-gray-400">🔍</span>
          <input
            type="text"
            placeholder={getAdminTranslation("searchPlaceholder", language)}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition"
          />
        </div>

        {/* Right: Filters */}
        <div className="flex gap-3 w-full md:w-auto">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-gray-700 cursor-pointer min-w-[140px]"
          >
            <option value="all">
              {getAdminTranslation("allStatus", language)}
            </option>
            <option value="pending">
              {getAdminTranslation("pending", language)}
            </option>
            <option value="sent">
              {getAdminTranslation("sent", language)}
            </option>
          </select>

          {/* Time Filter */}
          <select
            value={timeFilter}
            onChange={(e) => setTimeFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-gray-700 cursor-pointer min-w-[140px]"
          >
            <option value="all">
              {getAdminTranslation("allTime", language)}
            </option>
            <option value="24h">
              {getAdminTranslation("less24h", language)}
            </option>
            <option value="3d">
              {getAdminTranslation("days1to3", language)}
            </option>
            <option value="1w">
              {getAdminTranslation("more1week", language)}
            </option>
            <option value="1m">
              {getAdminTranslation("more1month", language)}
            </option>
          </select>
        </div>
      </div>

      {/* ================= TABLE ================= */}
      <div className="bg-white rounded-xl shadow overflow-hidden border border-gray-100">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-gray-50 text-gray-700 font-semibold uppercase text-xs tracking-wider">
              <tr>
                <th className="p-4 border-b">
                  {getAdminTranslation("id", language)}
                </th>
                <th className="p-4 border-b">
                  {getAdminTranslation("customerMail", language)}
                </th>
                <th className="p-4 border-b">
                  {getAdminTranslation("subject", language)}
                </th>
                <th className="p-4 border-b">
                  {getAdminTranslation("assignTo", language)}
                </th>
                <th className="p-4 border-b">
                  {getAdminTranslation("status", language)}
                </th>
                <th className="p-4 border-b text-right">
                  {getAdminTranslation("received", language)}
                </th>
              </tr>
            </thead>
            <tbody className="text-sm divide-y divide-gray-100 text-gray-600">
              {filteredEmails.length > 0 ? (
                filteredEmails.map((email) => (
                  <tr
                    key={email.id}
                    className="hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() => setSelectedEmail(email)}
                  >
                    <td className="p-4 font-bold text-gray-800">#{email.id}</td>

                    {/* Customer Mail */}
                    <td className="p-4 text-blue-600 font-medium">
                      {email.recipient_email}
                    </td>

                    {/* Subject */}
                    <td className="p-4 truncate max-w-xs">{email.subject}</td>

                    {/* ✅ Assign To (Updated to allow "Unassigned" to show) */}
                    <td className="p-4">
                      {email.employee_name ? (
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                              email.employee_name === "Unassigned"
                                ? "bg-indigo-100 text-indigo-600"
                                : "bg-indigo-100 text-indigo-600"
                            }`}
                          >
                            {email.employee_name.charAt(0).toUpperCase()}
                          </div>
                          <span className="text-gray-700 font-medium">
                            {email.employee_name}
                          </span>
                        </div>
                      ) : (
                        <span className="text-gray-400 pl-2">-</span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <span
                          className={`h-2.5 w-2.5 rounded-full ${getStatusDotColor(
                            email.status
                          )}`}
                        ></span>
                        <span className="capitalize text-gray-700 font-medium">
                          {email.status === "pending_approval"
                            ? getAdminTranslation(
                                "statusPendingApproval",
                                language
                              )
                            : email.status === "replied"
                            ? getAdminTranslation("statusSent", language)
                            : email.status ||
                              getAdminTranslation("statusPending", language)}
                        </span>
                      </div>
                    </td>

                    {/* Time Since Received */}
                    <td className="p-4 text-right whitespace-nowrap font-medium text-gray-500">
                      {getTimeAgo(email.created_at)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan="6"
                    className="p-12 text-center text-gray-400 italic"
                  >
                    {getAdminTranslation("noEmailsFound", language)}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= DETAILS MODAL ================= */}
      {selectedEmail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-2xl">
              <div>
                <h2 className="text-xl font-bold text-gray-800">
                  {getAdminTranslation("emailDetails", language)}
                </h2>
                <p className="text-sm text-gray-500 mt-1">
                  ID: #{selectedEmail.id}
                </p>
              </div>
              <button
                onClick={() => setSelectedEmail(null)}
                className="text-gray-400 hover:text-gray-600 transition p-2 text-2xl"
              >
                &times;
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6">
              {/* Dates Row */}
              <div className="grid grid-cols-2 gap-4 bg-blue-50 p-4 rounded-xl border border-blue-100">
                <div>
                  <span className="block text-xs font-bold text-blue-500 uppercase tracking-wide">
                    {getAdminTranslation("received", language)}
                  </span>
                  <span className="text-gray-800 font-medium">
                    {new Date(selectedEmail.created_at).toLocaleString()}
                  </span>
                </div>
                <div>
                  <span className="block text-xs font-bold text-blue-500 uppercase tracking-wide">
                    {getAdminTranslation("sentAt", language)}
                  </span>
                  <span className="text-gray-800 font-medium">
                    {selectedEmail.sent_at
                      ? new Date(selectedEmail.sent_at).toLocaleString()
                      : getAdminTranslation("notSentYet", language)}
                  </span>
                </div>
              </div>

              {/* Subject & Body */}
              <div>
                <h3 className="text-sm font-bold text-gray-700 uppercase mb-2">
                  {getAdminTranslation("subject", language)}
                </h3>
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 text-gray-800 font-medium">
                  {selectedEmail.subject}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-bold text-gray-700 uppercase mb-2">
                  {getAdminTranslation("messageBody", language)}
                </h3>
                <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 text-gray-700 whitespace-pre-wrap leading-relaxed text-sm">
                  {selectedEmail.body}
                </div>
              </div>

              {/* Reply Section */}
              {selectedEmail.draft_reply && (
                <div className="bg-green-50 p-5 rounded-xl border border-green-100">
                  <h3 className="text-xs font-bold text-green-700 uppercase mb-3 flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    {getAdminTranslation("replyBy", language)}:{" "}
                    {selectedEmail.employee_name}
                  </h3>
                  <div className="text-gray-800 whitespace-pre-wrap text-sm leading-relaxed">
                    {selectedEmail.draft_reply}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-5 border-t border-gray-100 flex justify-end bg-gray-50 rounded-b-2xl">
              <button
                onClick={() => setSelectedEmail(null)}
                className="px-6 py-2.5 bg-white border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-100 transition shadow-sm"
              >
                {getAdminTranslation("close", language)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default SentEmail;
