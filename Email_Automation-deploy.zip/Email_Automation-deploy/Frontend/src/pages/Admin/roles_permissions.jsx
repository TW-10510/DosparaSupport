import React, { useState, useEffect } from "react";
import { FaEdit, FaTrash, FaPlus, FaUserShield, FaKey, FaTimes, FaLock } from "react-icons/fa";
import EmailLoader from "../../Components/EmailLoader";

function RolesPermissions() {
  const [roles, setRoles] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [loading, setLoading] = useState(true);

  // States for modals and editing
  const [editRole, setEditRole] = useState(null);
  const [editPermission, setEditPermission] = useState(null);
  const [addRoleOpen, setAddRoleOpen] = useState(false);
  const [newRole, setNewRole] = useState({
    name: "", description: "", level: "Basic", status: "active",
  });

  // Constants
  const SUPER_ADMIN_ROLE = "super admin";

  // ✅ GET API URL FROM ENV
  const API_URL = process.env.REACT_APP_API_URL || "http://127.0.0.1:8013/api";
  const currentUserId = localStorage.getItem("user_id");

  /* ================= FETCH DATA ================= */
  const fetchData = async () => {
    setLoading(true);
    try {
      // 1. Fetch Roles
      const rolesRes = await fetch(`${API_URL}/roles`);
      const rolesData = await rolesRes.json();
      setRoles(Array.isArray(rolesData) ? rolesData : []);

      // 2. Fetch Permissions
      const permsRes = await fetch(`${API_URL}/permissions`);
      const permsData = await permsRes.json();
      setPermissions(Array.isArray(permsData) ? permsData : []);

    } catch (error) {
      console.error("Error fetching data:", error);
      setRoles([]);
      setPermissions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  /* ================= HELPERS ================= */
  
  const normalizeRoleName = (roleName) => String(roleName || "").toLowerCase();

  // Find Role ID by Name (needed for API calls)
  const getRoleIdByName = (roleName) => {
    const match = roles.find(r => normalizeRoleName(r.name) === normalizeRoleName(roleName));
    return match ? match.id : null;
  };

  /* ================= HANDLERS ================= */

  // ... (Role CRUD handlers remain the same) ...
  const deleteRole = async (id) => {
    if(!window.confirm("Are you sure?")) return;
    try {
      await fetch(`${API_URL}/roles/${id}`, { method: "DELETE" });
      setRoles((prev) => prev.filter((r) => r.id !== id));
    } catch (error) { console.error(error); }
  };

  const createRole = async () => {
    if (!newRole.name.trim()) return;
    try {
      const response = await fetch(`${API_URL}/roles`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newRole),
      });
      if (!response.ok) throw new Error("Error");
      const createdRole = await response.json();
      setRoles((prev) => [...prev, createdRole]);
      setNewRole({ name: "", description: "", level: "Basic", status: "active" });
      setAddRoleOpen(false);
    } catch (error) { console.error(error); }
  };

  const updateRole = async (roleId, updates) => {
    setRoles((prev) => prev.map((role) => (role.id === roleId ? { ...role, ...updates } : role)));
    try {
      await fetch(`${API_URL}/roles/${roleId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
    } catch (error) { fetchData(); }
  };

  const saveRole = () => {
    updateRole(editRole.id, { description: editRole.description, status: editRole.status });
    setEditRole(null);
  };

  /* ================= PERMISSION HANDLERS ================= */

  const updatePermissionAssignment = (permissionId, roleName, isAssigned) => {
    setPermissions((prev) =>
      prev.map((perm) => {
        if (perm.id !== permissionId) return perm;
        const existingRoles = perm.assignedRoles || [];
        
        if (isAssigned) {
          if (existingRoles.some((r) => normalizeRoleName(r) === normalizeRoleName(roleName))) return perm;
          return { ...perm, assignedRoles: [...existingRoles, roleName] };
        } else {
          return { ...perm, assignedRoles: existingRoles.filter((r) => normalizeRoleName(r) !== normalizeRoleName(roleName)) };
        }
      })
    );
  };

  // ✅ 1. Handle Dropdown Selection
  const handleRoleSelect = async (permissionId, roleId) => {
    if (!roleId || !permissionId) return;
    
    const selectedRole = roles.find(r => String(r.id) === String(roleId));
    if (!selectedRole) return;

    // Optimistic Update
    updatePermissionAssignment(permissionId, selectedRole.name, true);

    try {
      const res = await fetch(`${API_URL}/roles/${roleId}/permissions/${permissionId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-User-Id": currentUserId || "" }
      });
      if (!res.ok) throw new Error("Failed");
    } catch (error) {
      updatePermissionAssignment(permissionId, selectedRole.name, false); // Revert
      alert("Failed to update database.");
    }
  };

  // ✅ 2. Handle Remove (Block Super Admin)
  const removeRoleAccess = async (permissionId, roleName) => {
    // 🔒 Security Check: Never remove Super Admin
    if (normalizeRoleName(roleName) === SUPER_ADMIN_ROLE) {
        alert("Super Admin access cannot be removed.");
        return;
    }

    const roleId = getRoleIdByName(roleName);
    if (!roleId) return;

    updatePermissionAssignment(permissionId, roleName, false);

    try {
        const res = await fetch(`${API_URL}/roles/${roleId}/permissions/${permissionId}`, {
            method: "DELETE",
            headers: { "Content-Type": "application/json", "X-User-Id": currentUserId || "" }
        });
        if (!res.ok) throw new Error("Failed");
    } catch (e) {
        updatePermissionAssignment(permissionId, roleName, true); // Revert
    }
  };

  // ... (Permission CRUD handlers) ...
  const savePermission = async () => {
    // Implement API call to save permission details if needed
    setPermissions((prev) => prev.map((p) => (p.id === editPermission.id ? editPermission : p)));
    setEditPermission(null);
  };
  
  const deletePermission = (id) => {
    setPermissions((prev) => prev.filter((p) => p.id !== id));
  };

  if (loading) return <div className="h-screen w-full flex items-center justify-center bg-gray-100"><EmailLoader text="Loading..." /></div>;

  return (
    <div className="p-6 bg-gray-100 min-h-screen space-y-10">
      
      {/* HEADER */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800">Roles & Permissions</h1>
        <button onClick={() => setAddRoleOpen(true)} className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 shadow-md">
          <FaPlus /> Add Role
        </button>
      </div>

      {/* ================= ROLES LIST ================= */}
      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-gray-700">
          <FaUserShield className="text-indigo-600" /> Roles
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array.isArray(roles) && roles.map((role) => (
            <div key={role.id} className="bg-white rounded-2xl shadow hover:shadow-lg transition overflow-hidden border border-gray-100">
              <div className="h-1 bg-gradient-to-r from-indigo-500 to-purple-500" />
              <div className="p-5 space-y-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center">
                      <FaUserShield size={18} />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-800">{role.name}</h3>
                      <p className="text-xs text-gray-500">{role.level} Access</p>
                    </div>
                  </div>
                  <select
                    value={role.status}
                    onChange={(e) => updateRole(role.id, { status: e.target.value })}
                    className={`text-xs px-2 py-1 rounded-full font-semibold border outline-none cursor-pointer ${
                      role.status === "active" ? "bg-green-50 text-green-700 border-green-200" : "bg-red-50 text-red-700 border-red-200"
                    }`}
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                <p className="text-sm text-gray-600 min-h-[40px]">{role.description || "No description provided."}</p>
                <div className="border-t pt-3 flex justify-between items-center text-sm text-gray-500">
                   <span>ID: {role.id}</span>
                   <div className="flex gap-2">
                      <button onClick={() => setEditRole({ ...role })} className="text-indigo-600 hover:text-indigo-800"><FaEdit /></button>
                      <button onClick={() => deleteRole(role.id)} className="text-red-500 hover:text-red-700"><FaTrash /></button>
                   </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ================= PAGE ACCESS TABLE ================= */}
      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-gray-700">
          <FaKey className="text-indigo-600" /> Page Access Control
        </h2>

        <div className="bg-white rounded-2xl shadow overflow-hidden border border-gray-100">
          <table className="w-full text-sm text-left">
            <thead className="bg-indigo-50 text-indigo-900 font-semibold">
              <tr>
                <th className="p-4 w-1/4">Page / Feature</th>
                <th className="p-4 w-1/6">Category</th>
                <th className="p-4 w-1/2">Allowed Roles</th>
                <th className="p-4 w-1/12 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {Array.isArray(permissions) && permissions.map((perm) => (
                <tr key={perm.id} className="hover:bg-gray-50 transition">
                  {/* Page Info */}
                  <td className="p-4 align-top">
                    <p className="font-bold text-gray-800">{perm.name}</p>
                    <p className="text-xs text-gray-500 mt-1">{perm.description}</p>
                  </td>
                  <td className="p-4 align-top text-gray-600 font-medium capitalize">{perm.category || "General"}</td>
                  
                  {/* ✅ ROLE ACCESS COLUMN */}
                  <td className="p-4 align-top">
                    <div className="space-y-3">
                      
                      {/* 1. Tags List */}
                      <div className="flex flex-wrap gap-2">
                        
                        {/* 🔒 FIXED SUPER ADMIN TAG (Always visible, no delete) */}
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 border border-purple-200 select-none">
                            <FaLock size={10} /> {SUPER_ADMIN_ROLE}
                        </span>

                        {/* Dynamic Tags */}
                        {perm.assignedRoles && perm.assignedRoles
                            .filter(r => normalizeRoleName(r) !== SUPER_ADMIN_ROLE) // Don't duplicate super admin
                            .map((roleName, idx) => (
                                <span key={idx} className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 shadow-sm">
                                    {roleName}
                                    <button 
                                        onClick={() => removeRoleAccess(perm.id, roleName)} 
                                        className="hover:text-red-600 focus:outline-none ml-1 p-0.5 rounded-full hover:bg-blue-100 transition-colors"
                                        title="Remove Access"
                                    >
                                        <FaTimes size={10} />
                                    </button>
                                </span>
                        ))}
                      </div>

                      {/* 2. Dropdown to Add Role */}
                      <div className="relative w-56">
                        <select 
                            className="w-full pl-3 pr-8 py-2 bg-white border border-gray-300 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-gray-600 cursor-pointer shadow-sm hover:border-gray-400 transition"
                            onChange={(e) => {
                                if (e.target.value) {
                                    handleRoleSelect(perm.id, e.target.value);
                                    e.target.value = ""; // Reset dropdown
                                }
                            }}
                            defaultValue=""
                        >
                            <option value="" disabled>+ Allow Access to Role...</option>
                            {roles
                                .filter(r => normalizeRoleName(r.name) !== SUPER_ADMIN_ROLE) // Hide Super Admin from dropdown
                                .filter(r => !(perm.assignedRoles || []).map(pr => normalizeRoleName(pr)).includes(normalizeRoleName(r.name))) // Hide already assigned
                                .map((role) => (
                                    <option key={role.id} value={role.id}>
                                        {role.name}
                                    </option>
                            ))}
                        </select>
                      </div>
                    </div>
                  </td>

                  <td className="p-4 align-top text-center">
                    <div className="flex justify-center gap-3">
                      <button onClick={() => setEditPermission({ ...perm })} className="text-gray-400 hover:text-indigo-600 p-2 rounded hover:bg-indigo-50 transition"><FaEdit /></button>
                      <button onClick={() => deletePermission(perm.id)} className="text-gray-400 hover:text-red-600 p-2 rounded hover:bg-red-50 transition"><FaTrash /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= ADD ROLE MODAL ================= */}
      {addRoleOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white w-[26rem] rounded-xl shadow-2xl p-6 animate-fade-in">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Create New Role</h2>
            <div className="space-y-4 text-sm">
              <input placeholder="Role name" value={newRole.name} onChange={(e) => setNewRole({ ...newRole, name: e.target.value })} className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500" />
              <textarea placeholder="Description" value={newRole.description} onChange={(e) => setNewRole({ ...newRole, description: e.target.value })} className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500" rows="3"/>
              <div className="grid grid-cols-2 gap-3">
                <select value={newRole.level} onChange={(e) => setNewRole({ ...newRole, level: e.target.value })} className="border rounded-lg px-3 py-2 bg-white"><option>System</option><option>Management</option><option>Basic</option></select>
                <select value={newRole.status} onChange={(e) => setNewRole({ ...newRole, status: e.target.value })} className="border rounded-lg px-3 py-2 bg-white"><option value="active">Active</option><option value="inactive">Inactive</option></select>
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setAddRoleOpen(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
              <button onClick={createRole} className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 shadow">Create Role</button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT MODALS (Simplified for brevity, same as previous) */}
      {editRole && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white w-[26rem] rounded-2xl shadow-xl p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Edit Role</h2>
            <div className="space-y-4 text-sm">
              <input value={editRole.name} onChange={(e) => setEditRole({ ...editRole, name: e.target.value })} className="w-full border rounded px-3 py-2" />
              <textarea value={editRole.description} onChange={(e) => setEditRole({ ...editRole, description: e.target.value })} className="w-full border rounded px-3 py-2" />
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setEditRole(null)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
              <button onClick={saveRole} className="px-4 py-2 bg-indigo-600 text-white rounded">Save</button>
            </div>
          </div>
        </div>
      )}
      
      {editPermission && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white w-[26rem] rounded-2xl shadow-xl p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Edit Page Details</h2>
            <div className="space-y-4 text-sm">
              <input value={editPermission.name} onChange={(e) => setEditPermission({ ...editPermission, name: e.target.value })} className="w-full border rounded px-3 py-2" />
              <textarea value={editPermission.description} onChange={(e) => setEditPermission({ ...editPermission, description: e.target.value })} className="w-full border rounded px-3 py-2" />
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setEditPermission(null)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
              <button onClick={savePermission} className="px-4 py-2 bg-indigo-600 text-white rounded">Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default RolesPermissions;