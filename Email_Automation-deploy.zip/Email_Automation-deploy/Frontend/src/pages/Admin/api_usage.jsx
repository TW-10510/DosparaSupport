import React, { useState, useEffect } from "react";
import { 
  FaServer, 
  FaExclamationTriangle, 
  FaCheckCircle, 
  FaSearch, 
  FaKey,
  FaChartLine,
  FaSpinner,
  FaTimes,
  FaBan
} from "react-icons/fa";

// CHANGE 8000 TO 8013 (or whatever port your uvicorn says in the terminal)
 const API_URL = process.env.REACT_APP_API_URL || "http://127.0.0.1:8013/api";

function ApiUsage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // State for Data
  const [systemStats, setSystemStats] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [userUsage, setUserUsage] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  
  // ✅ State for the main critical alert banner
  const [criticalAlert, setCriticalAlert] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const res = await fetch(`${API_URL}/admin/api-usage`); 
        
        if (!res.ok) throw new Error("Failed to fetch API usage data");
        
        const data = await res.json();
        
        // ✅ Check for a critical OpenAI-related alert for the top banner
        const mainCriticalAlert = data.notifications.find(
          n => n.type === 'critical' && n.id.includes('openai')
        );
        setCriticalAlert(mainCriticalAlert || null);

        setSystemStats(data.system_stats);
        setNotifications(data.notifications);
        setUserUsage(data.user_usage);

      } catch (err) {
        setError(err.message);
        // Also set a critical alert for UI consistency if fetch fails
        setCriticalAlert({
            id: 'fetch-error',
            type: 'critical',
            msg: `Failed to connect to backend: ${err.message}. Please ensure the server is running.`
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const getIcon = (type) => {
    switch (type) {
      case "server": return <FaServer />;
      case "key": return <FaKey />;
      case "alert": return <FaExclamationTriangle />;
      case "check": return <FaCheckCircle />;
      default: return <FaServer />;
    }
  };

  const filteredUsers = userUsage.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const dismissNotification = (id) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  // ✅ Keep general error display but the new banner will be more prominent
  if (error && !criticalAlert) {
    return (
        <div className="flex h-screen items-center justify-center bg-gray-50">
            {/* This can be a fallback or removed if the banner is sufficient */}
        </div>
    );
  }

  if (loading && !criticalAlert) { // Don't show main loader if we already have an alert
    return (
        <div className="flex h-screen w-full items-center justify-center bg-gray-50 text-indigo-600">
            <FaSpinner className="animate-spin text-4xl" />
        </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen font-sans space-y-8">
      
      {/* ✅ NEW - MAIN CRITICAL ALERT BANNER */}
      {criticalAlert && (
        <div className="bg-red-600/90 backdrop-blur-sm border border-red-700/50 text-white rounded-2xl shadow-lg p-4 flex items-center gap-4 animate-fade-in-down">
          <FaExclamationTriangle className="text-2xl flex-shrink-0" />
          <div className="flex-grow">
            <h2 className="font-bold text-lg">System Critical Alert</h2>
            <p className="text-sm text-red-100">{criticalAlert.msg}</p>
          </div>
        </div>
      )}

      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 tracking-tight">API Usage Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Monitor total consumption and individual key performance</p>
        </div>
        <button className="flex items-center gap-2 bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition shadow-sm font-medium">
          <FaChartLine /> View Detailed Logs
        </button>
      </div>

      {/* ⚠️ NOTIFICATIONS PANEL */}
      {notifications.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="bg-gray-50 px-6 py-3 border-b border-gray-200 flex justify-between items-center">
                <h3 className="font-bold text-gray-700 flex items-center gap-2">
                    <FaExclamationTriangle className="text-amber-500" />
                    System Alerts ({notifications.length})
                </h3>
            </div>
            <div className="divide-y divide-gray-100">
                {notifications.map((note) => (
                    <div 
                        key={note.id} 
                        className={`px-6 py-4 flex justify-between items-start transition hover:bg-gray-50 ${
                            note.type === 'critical' ? 'border-l-4 border-red-500 bg-red-50' : 'border-l-4 border-amber-400 bg-amber-50'
                        }`}
                    >
                        <div className="flex gap-4">
                            <div className={`mt-1 text-lg ${note.type === 'critical' ? 'text-red-500' : 'text-amber-500'}`}>
                                {note.type === 'critical' ? <FaBan /> : <FaExclamationTriangle />}
                            </div>
                            <div>
                                <p className={`font-bold text-sm ${note.type === 'critical' ? 'text-red-700' : 'text-amber-700'}`}>
                                    {note.type.toUpperCase()} ISSUE
                                </p>
                                <p className="text-gray-600 text-sm mt-1">{note.msg}</p>
                            </div>
                        </div>
                        <button 
                            onClick={() => dismissNotification(note.id)}
                            className="text-gray-400 hover:text-gray-600 p-1 rounded-md hover:bg-gray-200 transition"
                        >
                            <FaTimes />
                        </button>
                    </div>
                ))}
            </div>
        </div>
      )}

      {/* 📊 KPI CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {systemStats.map((stat, idx) => (
          <div key={idx} className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">{stat.title}</p>
              <p className="text-3xl font-extrabold text-gray-900 mt-2">{stat.value}</p>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded mt-2 inline-block ${
                  stat.trend === 'positive' ? 'text-green-600 bg-green-50' : 'text-red-600 bg-red-50'
              }`}>
                {stat.change}
              </span>
            </div>
            <div className={`p-4 rounded-xl text-xl ${stat.colorClass}`}>
                {getIcon(stat.iconType)}
            </div>
          </div>
        ))}
      </div>

      {/* 📋 INDIVIDUAL USAGE TABLE */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        
        <div className="p-6 border-b border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
          <h2 className="text-lg font-bold text-gray-800">Individual Key Usage</h2>
          
          <div className="relative w-full md:w-80">
            <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input 
              type="text" 
              placeholder="Search by ID or Name..." 
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white transition outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-50 text-gray-500 font-semibold border-b border-gray-200">
              <tr>
                <th className="px-6 py-4">Key ID</th>
                <th className="px-6 py-4">Owner Name</th>
                <th className="px-6 py-4">Usage (Calls)</th>
                <th className="px-6 py-4">Quota Limit</th>
                <th className="px-6 py-4">Usage %</th>
                <th className="px-6 py-4">Error / Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredUsers.length > 0 ? (
                filteredUsers.map((u) => {
                  const percentage = u.limit > 0 ? Math.min(100, Math.round((u.calls / u.limit) * 100)) : 0;
                  
                  let progressColor = "bg-indigo-600";
                  if (percentage > 80) progressColor = "bg-amber-500";
                  if (percentage >= 100) progressColor = "bg-red-500";

                  let statusContent;
                  if (u.status === 'Active') {
                      statusContent = (
                          <span className="px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wide bg-green-50 text-green-700 border border-green-200 flex items-center w-fit gap-1">
                              <FaCheckCircle className="text-xs" /> Active
                          </span>
                      );
                  } else if (u.status === 'Over Limit') {
                      statusContent = (
                          <div className="flex flex-col">
                              <span className="px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wide bg-red-50 text-red-700 border border-red-200 flex items-center w-fit gap-1">
                                  <FaExclamationTriangle /> Over Limit
                              </span>
                              <span className="text-[10px] text-red-500 font-medium mt-1 ml-1">
                                  Quota Exceeded
                              </span>
                          </div>
                      );
                  } else { // Revoked
                      statusContent = (
                          <div className="flex flex-col">
                              <span className="px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wide bg-gray-100 text-gray-600 border border-gray-200 flex items-center w-fit gap-1">
                                  <FaBan /> Revoked
                              </span>
                              <span className="text-[10px] text-gray-400 font-medium mt-1 ml-1">
                                  Access Denied
                              </span>
                          </div>
                      );
                  }

                  return (
                    <tr key={u.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4 font-mono text-gray-500">{u.id}</td>
                      <td className="px-6 py-4 font-medium text-gray-800">{u.name}</td>
                      <td className="px-6 py-4 text-gray-700">{u.calls.toLocaleString()}</td>
                      <td className="px-6 py-4 text-gray-500">{u.limit.toLocaleString()}</td>
                      
                      <td className="px-6 py-4 w-48">
                        <div className="flex items-center gap-3">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className={`${progressColor} h-2 rounded-full transition-all duration-500`} 
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-semibold w-8">{percentage}%</span>
                        </div>
                      </td>

                      <td className="px-6 py-4">
                        {statusContent}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-gray-400">
                    No active API keys found matching "{searchTerm}"
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default ApiUsage;