import React, { useEffect, useMemo, useState } from "react";
import { FaEdit, FaTrash, FaPlus, FaSearch } from "react-icons/fa";
import EmailLoader from "../../Components/EmailLoader";

const API = process.env.REACT_APP_API_URL;

const STATUS_STYLES = {
  open: "bg-green-100 text-green-700",
  closed: "bg-gray-200 text-gray-700",
  pending: "bg-yellow-100 text-yellow-700",
  "in progress": "bg-blue-100 text-blue-700",
};

const AUTO_CLOSE_DAYS = 3;
const AUTO_CLOSE_MS = AUTO_CLOSE_DAYS * 24 * 60 * 60 * 1000;

const formatStatus = (value) => {
  const normalized = (value || "pending").toString().trim().toLowerCase();
  const label = normalized.replace(/_/g, " ");
  return label.replace(/\b\w/g, (char) => char.toUpperCase());
};

const parseDateValue = (value) => {
  if (!value) return null;
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return null;
  return parsed;
};

const truncateValue = (value, max = 16) => {
  if (!value) return "-";
  if (value.length <= max) return value;
  return `${value.slice(0, max)}...`;
};

function Tickets() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [selectedTicket, setSelectedTicket] = useState(null);
  const [search, setSearch] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [createLoading, setCreateLoading] = useState(false);
  const [formData, setFormData] = useState({
    subject: "",
    recipient_email: "",
    body: "",
  });

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API}/tickets`);
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setTickets(data.tickets || []);
    } catch (err) {
      console.error(err);
      setTickets([]);
      setError("Failed to load tickets.");
    } finally {
      setLoading(false);
    }
  };

  const filteredTickets = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return tickets;

    return tickets.filter((ticket) => {
      const subjectMatch = (ticket.subject || "").toLowerCase().includes(term);
      const threadMatch = (ticket.thread_id || "").toLowerCase().includes(term);
      return subjectMatch || threadMatch;
    });
  }, [tickets, search]);

  const threadStats = useMemo(() => {
    const stats = new Map();

    tickets.forEach((ticket) => {
      const threadKey = ticket.thread_id || `ticket-${ticket.id}`;
      const createdAt = parseDateValue(ticket.created_at);
      const sentAt = parseDateValue(ticket.sent_at);
      const entry = stats.get(threadKey) || {
        latestCreatedAt: null,
        lastAgentSentAt: null,
      };

      if (createdAt && (!entry.latestCreatedAt || createdAt > entry.latestCreatedAt)) {
        entry.latestCreatedAt = createdAt;
      }

      if (sentAt && (!entry.lastAgentSentAt || sentAt > entry.lastAgentSentAt)) {
        entry.lastAgentSentAt = sentAt;
      }

      stats.set(threadKey, entry);
    });

    return stats;
  }, [tickets]);

  const isTicketClosed = (ticket) => {
    const normalizedStatus = (ticket.status || "pending")
      .toString()
      .trim()
      .toLowerCase();

    if (normalizedStatus === "closed") return true;

    const threadKey = ticket.thread_id || `ticket-${ticket.id}`;
    const stats = threadStats.get(threadKey);
    if (!stats || !stats.lastAgentSentAt) return false;

    if (stats.latestCreatedAt && stats.latestCreatedAt > stats.lastAgentSentAt) {
      return false;
    }

    const ageMs = Date.now() - stats.lastAgentSentAt.getTime();
    return ageMs >= AUTO_CLOSE_MS;
  };

  const summary = useMemo(() => {
    const total = tickets.length;
    const open = tickets.filter((t) => !isTicketClosed(t)).length;
    const closed = tickets.filter((t) => isTicketClosed(t)).length;

    return { total, open, closed };
  }, [tickets, threadStats]);

  const handleCreateChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleCreate = async (event) => {
    event.preventDefault();
    setCreateLoading(true);
    setError("");

    try {
      const res = await fetch(`${API}/tickets`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!res.ok) throw new Error(await res.text());
      const created = await res.json();

      setTickets((prev) => [created, ...prev]);
      setCreateOpen(false);
      setFormData({ subject: "", recipient_email: "", body: "" });
    } catch (err) {
      console.error(err);
      setError("Failed to create ticket.");
    } finally {
      setCreateLoading(false);
    }
  };

  const handleDelete = async (id) => {
    setError("");
    try {
      const res = await fetch(`${API}/tickets/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error(await res.text());
      setTickets((prev) => prev.filter((ticket) => ticket.id !== id));
      if (selectedTicket && selectedTicket.id === id) {
        setSelectedTicket(null);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to delete ticket.");
    }
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen space-y-8">
      {/* HEADER */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800">Tickets</h1>
        <button
          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
          onClick={() => setCreateOpen(true)}
        >
          <FaPlus /> Create Ticket
        </button>
      </div>

      {/* SUMMARY */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-indigo-600 text-white rounded-2xl p-5">
          <p className="text-sm">Total Tickets</p>
          <p className="text-4xl font-bold">{summary.total}</p>
        </div>
        <div className="bg-indigo-500 text-white rounded-2xl p-5">
          <p className="text-sm">Open</p>
          <p className="text-4xl font-bold">{summary.open}</p>
        </div>
        <div className="bg-indigo-400 text-white rounded-2xl p-5">
          <p className="text-sm">Closed</p>
          <p className="text-4xl font-bold">{summary.closed}</p>
        </div>
      </div>

      {/* FILTER BAR */}
      <div className="bg-white rounded-2xl shadow p-4 flex flex-wrap gap-4 items-center">
        <div className="relative flex-1 min-w-[220px]">
          <FaSearch className="absolute left-3 top-3 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by subject or thread"
            className="w-full pl-10 pr-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl">
          {error}
        </div>
      )}

      {/* TABLE */}
      <div className="bg-white rounded-2xl shadow overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <EmailLoader text="Loading Records..." />
          </div>
        ) : (
          <div className="overflow-y-auto max-h-[60vh]">
            <table className="w-full text-sm">
              <thead className="bg-indigo-100 sticky top-0">
                <tr>
                  <th className="p-4 text-left">ID</th>
                  <th className="p-4 text-left">Subject</th>
                  <th className="p-4 text-left">Thread</th>
                  <th className="p-4 text-left">Reassignments</th>
                  <th className="p-4 text-left">Status</th>
                  <th className="p-4 text-center">Actions</th>
                </tr>
              </thead>

              <tbody>
                {filteredTickets.map((ticket) => {
                  const normalizedStatus = (ticket.status || "pending")
                    .toString()
                    .trim()
                    .toLowerCase();
                  const autoClosed = isTicketClosed(ticket);
                  const displayStatus = autoClosed ? "closed" : normalizedStatus;
                  const statusClass =
                    STATUS_STYLES[displayStatus] ||
                    "bg-indigo-100 text-indigo-700";

                  return (
                    <tr key={ticket.id} className="border-b hover:bg-indigo-50">
                      <td className="p-4">{ticket.id}</td>

                      <td
                        className="p-4 font-semibold text-indigo-700 cursor-pointer hover:underline"
                        onClick={() => setSelectedTicket(ticket)}
                      >
                        {ticket.subject || "-"}
                      </td>

                      <td className="p-4 font-mono text-xs text-gray-600">
                        {truncateValue(ticket.thread_id)}
                      </td>

                      <td className="p-4">
                        <span className="inline-flex items-center justify-center min-w-[32px] px-2 py-1 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-700">
                          {ticket.reassigned_count ?? 0}
                        </span>
                      </td>

                      <td className="p-4">
                        <span
                          className={`inline-flex items-center justify-center px-3 py-1 rounded-full text-xs font-semibold text-center whitespace-nowrap ${statusClass}`}
                        >
                          {autoClosed ? "Closed" : formatStatus(ticket.status)}
                        </span>
                      </td>

                      <td className="p-4 text-center">
                        <div className="flex justify-center gap-3">
                          <button
                            onClick={() => setSelectedTicket(ticket)}
                            className="text-indigo-600 hover:text-indigo-800"
                          >
                            <FaEdit />
                          </button>
                          <button
                            onClick={() => handleDelete(ticket.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <FaTrash />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}

                {filteredTickets.length === 0 && (
                  <tr>
                    <td
                      className="p-6 text-center text-gray-500"
                      colSpan={6}
                    >
                      No tickets found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-xl w-[28rem] p-6 relative">
            <h2 className="text-2xl font-bold text-indigo-600 mb-4">
              Ticket Details
            </h2>

            <div className="space-y-2 text-sm">
              <p>
                <strong>Subject:</strong> {selectedTicket.subject}
              </p>
              <p>
                <strong>Thread:</strong>{" "}
                {selectedTicket.thread_id || "-"}
              </p>
              <p>
                <strong>Status:</strong>{" "}
                {isTicketClosed(selectedTicket)
                  ? "Closed"
                  : formatStatus(selectedTicket.status)}
              </p>
              <p>
                <strong>Assigned To:</strong>{" "}
                {selectedTicket.assigned_to ?? "-"}
              </p>
              <p>
                <strong>Reassignments:</strong>{" "}
                {selectedTicket.reassigned_count ?? 0}
              </p>
              <p>
                <strong>Created:</strong>{" "}
                {selectedTicket.created_at || "-"}
              </p>
            </div>

            <button
              onClick={() => setSelectedTicket(null)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-800"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {createOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-xl w-[30rem] p-6 relative">
            <h2 className="text-2xl font-bold text-indigo-600 mb-4">
              Create Ticket
            </h2>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="text-sm font-semibold text-gray-700">
                  Subject
                </label>
                <input
                  name="subject"
                  value={formData.subject}
                  onChange={handleCreateChange}
                  className="w-full mt-2 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-semibold text-gray-700">
                  Recipient Email
                </label>
                <input
                  name="recipient_email"
                  type="email"
                  value={formData.recipient_email}
                  onChange={handleCreateChange}
                  className="w-full mt-2 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-semibold text-gray-700">
                  Body
                </label>
                <textarea
                  name="body"
                  rows="4"
                  value={formData.body}
                  onChange={handleCreateChange}
                  className="w-full mt-2 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setCreateOpen(false)}
                  className="px-4 py-2 rounded-lg border text-gray-600 hover:bg-gray-50"
                  disabled={createLoading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700"
                  disabled={createLoading}
                >
                  {createLoading ? "Creating..." : "Create"}
                </button>
              </div>
            </form>

            <button
              onClick={() => setCreateOpen(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-800"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Tickets;
