import React, { useEffect, useState } from "react";
import { useTranslation } from "../context/TranslationContext";
import { getTranslation } from "../utils/translations";
import EmailLoader from "../Components/EmailLoader";

const API = process.env.REACT_APP_API_URL || "http://localhost:8000/api";

export default function Account() {
  const { language } = useTranslation();

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const currentUser = (() => {
    try {
      return JSON.parse(localStorage.getItem("user"));
    } catch {
      return null;
    }
  })();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await fetch(`${API}/auth/users`);
        const data = await res.json();
        const all = data.users || [];

        const found = all.find((u) => u.email === currentUser?.email);
        setUser(found || currentUser);
      } catch (err) {
        console.error(err);
        setUser(currentUser);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  if (loading)
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-100">
        <EmailLoader text={getTranslation("loadingProfile", language)} />
      </div>
    );

  if (!user)
    return <div className="p-6">{getTranslation("noUserData", language)}</div>;

  const initials =
    (user.first_name?.[0] || user.name?.[0] || "U") +
    (user.last_name?.[0] || "");

  return (
    <div className="p-6 bg-gray-100 min-h-screen space-y-6">
      <h1 className="text-xl font-semibold text-gray-800">
        {getTranslation("myProfile", language)}
      </h1>

      {/* ================= PROFILE HEADER ================= */}
      <div className="bg-white rounded-2xl shadow p-6 flex items-center gap-6">
        <div className="w-20 h-20 rounded-full bg-indigo-600 text-white flex items-center justify-center text-3xl font-bold">
          {initials}
        </div>

        <div>
          <p className="text-xl font-semibold text-gray-900">
            {user.first_name} {user.last_name}
          </p>
          <p className="text-sm text-gray-500 capitalize">
            {user.role || getTranslation("employee", language)}
          </p>
          <p className="text-sm text-gray-400">
            {user.city || "—"}, {user.country || ""}
          </p>
        </div>
      </div>

      {/* ================= PERSONAL INFO ================= */}
      <Section
        title={getTranslation("personalInformation", language)}
        language={language}
      >
        <InfoGrid>
          <Info
            label={getTranslation("firstName", language)}
            value={user.first_name || "-"}
          />
          <Info
            label={getTranslation("lastName", language)}
            value={user.last_name || "-"}
          />
          <Info
            label={getTranslation("emailAddress", language)}
            value={user.email || "-"}
          />
          <Info
            label={getTranslation("phoneNumber", language)}
            value={user.phone || "-"}
          />
          <Info
            label={getTranslation("userRole", language)}
            value={user.role || getTranslation("employee", language)}
          />
          <Info
            label={getTranslation("joinedOn", language)}
            value={
              user.created_at ? new Date(user.created_at).toDateString() : "-"
            }
          />
        </InfoGrid>
      </Section>

      {/* ================= ADDRESS ================= */}
      <Section title={getTranslation("address", language)} language={language}>
        <InfoGrid>
          <Info
            label={getTranslation("country", language)}
            value={user.country || "-"}
          />
          <Info
            label={getTranslation("city", language)}
            value={user.city || "-"}
          />
          <Info
            label={getTranslation("postalCode", language)}
            value={user.postal_code || "-"}
          />
        </InfoGrid>
      </Section>
    </div>
  );
}

/* ================= UI COMPONENTS ================= */

function Section({ title, children, language }) {
  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800">{title}</h2>
        <button className="text-sm px-4 py-1.5 rounded-lg border border-gray-300 hover:bg-gray-50">
          {getTranslation("edit", language)}
        </button>
      </div>
      {children}
    </div>
  );
}

function InfoGrid({ children }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {children}
    </div>
  );
}

function Info({ label, value }) {
  return (
    <div>
      <p className="text-xs text-gray-500 mb-1">{label}</p>
      <p className="text-sm font-medium text-gray-900">{value}</p>
    </div>
  );
}
