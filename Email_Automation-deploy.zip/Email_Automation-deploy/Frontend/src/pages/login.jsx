import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import log from "../assets/image.png"; // Ensure path is correct
// import gmail from "../assets/microsoft.png"; // Unused
import { useAuth } from "../context/AuthContext";

function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const normalizeRole = (role) => (role || "").toLowerCase();

  const redirectByRole = (role) => {
    const normalizedRole = normalizeRole(role);
    
    // Admin & Super Admin -> Admin Dashboard
    if (normalizedRole === "super admin" || normalizedRole === "admin") {
      navigate("/admin/admindashboard");
      return;
    }
    
    // Viewer -> Admin Reports (Corrected URL)
    // NOTE: This assumes Reports is inside /admin/ in your App.js
    if (normalizedRole === "viewer") {
      navigate("/admin/reports_logs"); 
      return;
    }

    // Employee -> Home
    if (normalizedRole === "employee") {
      navigate("/home");
      return;
    }

    // Default Fallback
    navigate("/");
  };

  const handleSignIn = async () => {
    if (!email || !password) {
      alert("Please enter email and password");
      return;
    }

    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.detail || "Invalid credentials");
        return;
      }

      // ✅ CRITICAL FIX: Include 'permissions' in the user object
      login({
        token: data.token || null,
        user: {
          id: data.user_id,
          name: `${data.first_name} ${data.last_name}`,
          email,
          role: data.role,
          permissions: data.permissions || [], // <--- THIS WAS MISSING
        },
      });

      redirectByRole(data.role);

    } catch (err) {
      console.error(err);
      alert("Backend not reachable");
    }
  };

  return (
    <div className="min-h-screen flex bg-white mx-56">
      {/* LEFT SIDE */}
      <div className="w-1/2 flex items-center justify-center">
        <div className="flex flex-col items-center mr-10">
          <img src={log} alt="logo" className="h-28 mb-2" />
          <h1 className="text-3xl font-semibold mt-4">Ebina Call Center</h1>
          <p className="text-sm text-gray-500 mt-2">AI Automation Solutions</p>
        </div>
      </div>

      {/* RIGHT SIDE */}
      <div className="w-1/2 flex items-center justify-center my-20 mx-10">
        <div className="w-full max-w-md bg-white border rounded-3xl shadow-xl px-10 py-12">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Sign in</h1>
          <p className="text-sm text-gray-500 mb-8">Sign in with your account</p>

          <div className="flex flex-col gap-5">
            <input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-4 py-3"
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-4 py-3"
            />

            <button
              onClick={handleSignIn}
              className="w-full bg-blue-800 hover:bg-blue-900 text-white py-3 rounded-lg font-medium"
            >
              Sign in
            </button>
          </div>

          <p className="mt-6 text-center text-sm text-gray-500">
            New user?{" "}
            <span
              className="text-blue-900 font-medium cursor-pointer"
              onClick={() => navigate("/register")}
            >
              Create Account
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;