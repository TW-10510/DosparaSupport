import React, { useEffect, useState } from "react";
import {
  FaInbox,
  FaPaperPlane,
  FaClock,
  FaCheckCircle,
  FaUserCheck,
} from "react-icons/fa";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  Defs,
  linearGradient,
} from "recharts";

// ✅ Import Translation Context & Helpers
import { useTranslation } from "../context/TranslationContext";
import { getTranslation } from "../utils/translations";
import EmailLoader from "../Components/EmailLoader";

const getUserId = () => {
  const uid = localStorage.getItem("user_id");
  if (!uid || uid === "null") return null;
  return uid;
};


const API = `${process.env.REACT_APP_API_URL}/auth`;

/* ================= HOME COMPONENT ================= */
function Home() {
  useEffect(() => {
  const userId = getUserId();
  if (!userId) return;

  const interval = setInterval(() => {
    fetch(`${process.env.REACT_APP_API_URL}/users/heartbeat`, {
      method: "POST",
      headers: {
        "X-User-Id": userId,
      },
    });
  }, 30000); // every 30 seconds

  return () => clearInterval(interval);
}, []);

  // 1. Get Language Context
  const { language } = useTranslation();

  // 2. State Management
  const [employees, setEmployees] = useState([]);
  const [stats, setStats] = useState({ assigned: 0, handled: 0, pending: 0 });
  const [graphData, setGraphData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState("Employee");

  // Filter State (Default: 7 Days)
  const [filterPeriod, setFilterPeriod] = useState("7");

  // 3. Fetch Data Effect
  useEffect(() => {
    const fetchData = async () => {
      try {
        const userId = getUserId();
        if (!userId) return;

        const storedName = localStorage.getItem("first_name");

        if (storedName) setUserName(storedName);

        // Fetch Users (for Team Table) and Personal Stats (for Graph/Boxes)
        const promises = [
          fetch(`${API}/users`, {
            headers: {
              "X-User-Id": userId,
            },
          }),
        ];

        if (userId) {
          promises.push(
            fetch(`${API}/employee/stats/${userId}?period=${filterPeriod}`)
          );
        }

        const responses = await Promise.all(promises);
        const usersRes = responses[0];
        const statsRes = responses[1];

        // Process Users Table
        if (usersRes.ok) {
          const usersData = await usersRes.json();
          if (usersData.users) {
            const mapped = usersData.users.map((u) => ({
              id: u.id,
              name: `${u.first_name} ${u.last_name}`,
              department: u.role === "employee" ? "Support" : "General",
              online: u.is_online,
            }));
            setEmployees(mapped);
          }
        }

        // Process Personal Stats
        if (statsRes && statsRes.ok) {
          const statsData = await statsRes.json();
          setStats(statsData.metrics);
          if (statsData.graph && statsData.graph.length > 0) {
            setGraphData(statsData.graph);
          } else {
            setGraphData([]);
          }
        }
      } catch (err) {
        console.error("Error loading dashboard:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [filterPeriod]); // Re-run when filter changes

  const totalEmployees = employees.length;
  const onlineEmployees = employees.filter((e) => e.online).length;

  if (loading)
    return (
      <div className="h-screen w-full flex items-center justify-center bg-slate-50">
        <EmailLoader text={getTranslation("loadingDashboard", language)} />
      </div>
    );

  return (
    <div className="p-6 bg-slate-50 min-h-screen space-y-8 font-sans text-slate-800">
      {/* --- HEADER --- */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-2">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">
            {getTranslation("welcomeBack", language)},{" "}
            <span className="text-indigo-600">{userName}</span>
          </h1>
          <p className="text-slate-500 mt-1 font-medium">
            {getTranslation("performanceOverview", language)}
          </p>
        </div>
      </div>

      {/* --- METRICS BOXES --- */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Metric
          title={getTranslation("assignedTasks", language)}
          value={stats.assigned}
          icon={<FaInbox />}
          gradient="from-indigo-400 to-indigo-300"
        />
        <Metric
          title={getTranslation("mailsHandled", language)}
          value={stats.handled}
          icon={<FaCheckCircle />}
          gradient="from-emerald-400 to-teal-300"
        />
        <Metric
          title={getTranslation("pendingActions", language)}
          value={stats.pending}
          icon={<FaClock />}
          gradient="from-amber-400 to-orange-300"
          subtitle={`(${getTranslation("drafts", language)})`}
        />
        <Metric
          title={getTranslation("activeTeam", language)}
          value={onlineEmployees}
          subtitle={`${getTranslation("total", language)}: ${totalEmployees}`}
          icon={<FaUserCheck />}
          gradient="from-sky-400 to-blue-300"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* --- GRAPH SECTION --- */}
        <div className="lg:col-span-2 bg-white rounded-3xl shadow-lg shadow-slate-200/50 p-8 border border-slate-100">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-lg font-bold text-slate-700">
              {getTranslation("performanceAnalytics", language)}
            </h2>

            {/* Filter Dropdown */}
            <select
              value={filterPeriod}
              onChange={(e) => setFilterPeriod(e.target.value)}
              className="bg-slate-50 border border-slate-200 text-sm font-semibold text-slate-600 rounded-xl px-4 py-2 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300 cursor-pointer hover:bg-slate-100 transition outline-none"
            >
              <option value="3">{getTranslation("last3Days", language)}</option>
              <option value="7">{getTranslation("last7Days", language)}</option>
              <option value="14">
                {getTranslation("last14Days", language)}
              </option>
              <option value="20">
                {getTranslation("last20Days", language)}
              </option>
              <option value="30">
                {getTranslation("last30Days", language)}
              </option>
              <option value="90">
                {getTranslation("last3Months", language)}
              </option>
              <option value="year">
                {getTranslation("thisYear", language)}
              </option>
            </select>
          </div>

          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={graphData}
                margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorEmails" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#818cf8" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#818cf8" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#f1f5f9"
                />
                <XAxis
                  dataKey="name"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#94a3b8", fontSize: 12, fontWeight: 500 }}
                  dy={10}
                  interval="preserveStartEnd"
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#94a3b8", fontSize: 12, fontWeight: 500 }}
                  allowDecimals={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e293b",
                    color: "#f8fafc",
                    borderRadius: "8px",
                    border: "none",
                    boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
                    padding: "8px 12px",
                  }}
                  itemStyle={{ color: "#f8fafc" }}
                  cursor={{
                    stroke: "#818cf8",
                    strokeWidth: 2,
                    strokeDasharray: "4 4",
                  }}
                />
                <Area
                  type="natural"
                  dataKey="emails"
                  name={getTranslation("mailsSent", language)}
                  stroke="#6366f1"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#colorEmails)"
                  activeDot={{ r: 6, strokeWidth: 0, fill: "#4f46e5" }}
                />
              </AreaChart>
            </ResponsiveContainer>
            {graphData.length === 0 && (
              <div className="text-center text-slate-400 mt-[-200px]">
                {getTranslation("noActivity", language)}
              </div>
            )}
          </div>
        </div>

        {/* --- TEAM TABLE --- */}
        <div className="bg-white rounded-3xl shadow-lg shadow-slate-200/50 p-6 border border-slate-100 overflow-hidden">
          <h2 className="text-lg font-bold text-slate-700 mb-4">
            {getTranslation("teamStatus", language)}
          </h2>
          <div className="overflow-y-auto max-h-[380px] pr-2 custom-scrollbar">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 border-b border-slate-100">
                  <th className="pb-3 font-semibold pl-2">
                    {getTranslation("member", language)}
                  </th>
                  <th className="pb-3 font-semibold">
                    {getTranslation("status", language)}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {employees.map((e) => (
                  <tr
                    key={e.id}
                    className="group hover:bg-slate-50 transition-colors duration-200"
                  >
                    <td className="py-3 pl-2">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-sm ${
                            e.online ? "bg-indigo-500" : "bg-slate-300"
                          }`}
                        >
                          {e.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-semibold text-slate-700">
                            {e.name}
                          </p>
                          <p className="text-xs text-slate-400 font-medium">
                            {e.department}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3">
                      <span
                        className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          e.online
                            ? "bg-emerald-50 text-emerald-600 border border-emerald-100"
                            : "bg-slate-100 text-slate-400 border border-slate-200"
                        }`}
                      >
                        {e.online
                          ? getTranslation("online", language)
                          : getTranslation("offline", language)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= METRIC CARD ================= */
function Metric({ title, value, icon, gradient, subtitle }) {
  return (
    <div
      className={`bg-gradient-to-br ${gradient} text-white rounded-3xl p-6 shadow-xl shadow-slate-200/50 transform transition hover:-translate-y-1 hover:shadow-2xl duration-300 relative overflow-hidden`}
    >
      {/* Decorative Circles */}
      <div className="absolute -right-6 -top-6 w-32 h-32 bg-white opacity-20 rounded-full blur-3xl"></div>
      <div className="absolute -left-6 -bottom-6 w-24 h-24 bg-black opacity-5 rounded-full blur-2xl"></div>

      <div className="flex justify-between items-start z-10 relative">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider opacity-90 mb-1 drop-shadow-sm">
            {title}
          </p>
          <h3 className="text-4xl font-extrabold drop-shadow-md">{value}</h3>
          {subtitle && (
            <p className="text-xs opacity-80 mt-1 font-medium">{subtitle}</p>
          )}
        </div>
        <div className="text-2xl bg-white/20 p-3 rounded-2xl backdrop-blur-md shadow-inner border border-white/10">
          {icon}
        </div>
      </div>
    </div>
  );
}

export default Home;
