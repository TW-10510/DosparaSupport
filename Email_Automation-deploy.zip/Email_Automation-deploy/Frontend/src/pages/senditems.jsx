import React, { useEffect, useState, useMemo } from "react";
import { useTranslation } from "../context/TranslationContext";
import { getTranslation } from "../utils/translations";
import ReactMarkdown from "react-markdown"; // ✅ Import ReactMarkdown
import EmailLoader from "../Components/EmailLoader";

const API = process.env.REACT_APP_API_URL || "http://localhost:8000/api";

/* Helper to get initials from email */
function getInitials(value) {
  if (!value) return "?";
  const clean = value.split("@")[0];
  const parts = clean.split(/[\s._-]+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

export default function Senditems({ search }) {
  const [sent, setSent] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);
  const { language } = useTranslation();

  // Filter sent items based on search
  const filteredSent = useMemo(() => {
    if (!search) return sent;
    const q = search.toLowerCase();
    return sent.filter(
      (s) =>
        (s.to && s.to.toLowerCase().includes(q)) ||
        (s.subject && s.subject.toLowerCase().includes(q)) ||
        (s.body && s.body.toLowerCase().includes(q))
    );
  }, [sent, search]);

  useEffect(() => {
    fetchSent();
  }, []);

  // Fetch sent emails
  async function fetchSent() {
    setLoading(true);
    try {
      const userId = localStorage.getItem("user_id");
      const res = await fetch(`${API}/auth/sent`, {
        headers: {
          "X-User-Id": userId,
          "Content-Type": "application/json",
        },
      });

      if (!res.ok) throw new Error("Failed to fetch sent items");

      const j = await res.json();
      const sorted = (j.sent || []).sort(
        (a, b) => (b.sent_at || 0) - (a.sent_at || 0)
      );
      setSent(sorted);
      if (!selected && sorted.length) setSelected(sorted[0]);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      {loading && sent.length === 0 ? (
        <div className="h-screen w-full flex items-center justify-center bg-gray-50">
          <EmailLoader text="Loading Sent Items..." />
        </div>
      ) : (
    <div className="flex h-full p-4 gap-4 text-sm text-gray-700 animate-fade-in">
      {/* LEFT PANEL: LIST OF SENT ITEMS */}
      <div className="w-1/4 bg-white rounded-xl shadow border border-gray-300 flex flex-col overflow-hidden">
        <div className="px-4 py-3 border-b font-semibold text-lg bg-gray-50 text-indigo-700">
          {getTranslation("senditems", language) || "Sent Items"}
        </div>

        <div className="flex-1 overflow-auto custom-scrollbar">
          {filteredSent.length === 0 ? (
            <div className="p-8 text-center text-gray-400 italic">
              No sent items found
            </div>
          ) : (
            filteredSent.map((s) => {
              const isSelected = selected?.id === s.id;
              return (
                <div
                  key={s.id}
                  onClick={() => setSelected(s)}
                  className={`p-3 border-b flex gap-3 cursor-pointer transition
                    ${
                      isSelected
                        ? "bg-indigo-400 text-white"
                        : "hover:bg-indigo-50"
                      }`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-semibold
                      ${
                        isSelected
                          ? "bg-white text-indigo-500"
                          : "bg-indigo-500 text-white"
                    }`}
                  >
                    {getInitials(s.to)}
                  </div>

                  {/* Email preview */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline mb-1">
                      <div
                      className={`truncate font-medium ${
                          isSelected ? "text-white" : "text-gray-800"
                        }`}
                      >
                        {s.to}
                      </div>
                      <div className="text-xs text-gray-400 whitespace-nowrap ml-2">
                        {new Date((s.sent_at || Date.now()) * 1000).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </div>
                    </div>

                    <div
                      className={`truncate font-semibold mb-0.5 ${
                        isSelected ? "text-indigo-100" : "text-gray-700"
                      }`}
                    >
                      {s.subject || "(No subject)"}
                    </div>
                    <div
                      className={`text-xs truncate ${
                        isSelected ? "text-indigo-100" : "text-gray-500"
                      }`}
                    >
                      {(s.body || "").slice(0, 50)}...
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* RIGHT PANEL: SELECTED EMAIL DETAILS */}
      <div className="flex-1 bg-white rounded-xl shadow border border-gray-300 p-8 overflow-auto custom-scrollbar">
        {!selected ? (
          <div className="h-full flex flex-col items-center justify-center text-gray-400">
            <svg
              className="w-16 h-16 mb-4 text-gray-300"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
              ></path>
            </svg>
            <span className="text-lg">Select a message to view details</span>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto">
            {/* Header */}
            <div className="border-b pb-6 mb-6">
              <div className="flex justify-between items-start mb-4">
                <h1 className="text-2xl font-bold text-gray-900 leading-tight">
                  {selected.subject}
                </h1>
                <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold uppercase rounded-full tracking-wide">
                  {selected.status || "Sent"}
                </span>
              </div>

              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-white">
                    {getInitials(selected.to)}
                  </div>
                  <div>
                    <div className="text-gray-500">To:</div>
                    <div className="font-medium text-gray-900">{selected.to}</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-gray-500">Sent on:</div>
                  <div className="font-medium text-gray-900">
                    {selected.sent_at
                      ? new Date(selected.sent_at * 1000).toLocaleString()
                      : "Unknown"}
                  </div>
                </div>
              </div>
            </div>

            {/* ✅ EMAIL BODY (formatted with Markdown) */}
            <div className="bg-white text-gray-800 text-base leading-7 p-4 border border-gray-100 rounded-lg shadow-sm">
              <ReactMarkdown>{selected.body}</ReactMarkdown>
            </div>
          </div>
        )}
      </div>
    </div>
      )}
    </>
  );
}
