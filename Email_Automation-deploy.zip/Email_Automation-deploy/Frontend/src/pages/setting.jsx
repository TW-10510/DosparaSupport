import React, { useEffect, useState } from "react";
import { useTranslation } from "../context/TranslationContext";
import { getTranslation } from "../utils/translations";

function Setting() {
  const { language, setLanguage } = useTranslation();

  const [settings, setSettings] = useState({
    language: language || "en",
    timezone: "Asia/Tokyo",
    theme: "Light",
    emailNotifications: true,
    desktopNotifications: false,
  });

  /* ---------------- LOAD SAVED PREFS (NO APPLY) ---------------- */
  useEffect(() => {
    const savedLang = localStorage.getItem("language");
    if (savedLang) {
      setSettings((prev) => ({ ...prev, language: savedLang }));
    }
  }, []);

  /* ---------------- HANDLE FIELD CHANGE ---------------- */
  const handleChange = (key, value) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  /* ---------------- SAVE SETTINGS ---------------- */
  const handleSave = () => {
    // ✅ APPLY LANGUAGE ONLY HERE
    setLanguage(settings.language);
    localStorage.setItem("language", settings.language);

    alert(getTranslation("settingsSaved", settings.language));
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen space-y-8">
      {/* PAGE TITLE */}
      <h1 className="text-3xl font-bold text-gray-800">
        {getTranslation("setting", language)}
      </h1>

      {/* ================= PREFERENCES ================= */}
      <div className="bg-white rounded-2xl shadow p-6 space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">
          {getTranslation("preferences", language)}
        </h2>

        <div className="grid md:grid-cols-2 gap-4 text-sm">
          {/* -------- LANGUAGE -------- */}
          <div>
            <label className="block font-medium mb-1">
              {getTranslation("language", language)}
            </label>
            <select
              value={settings.language}
              onChange={(e) => handleChange("language", e.target.value)}
              className="w-full border rounded px-3 py-2"
            >
              <option value="en">English</option>
              <option value="ja">Japanese (日本語)</option>
              <option value="ta">Tamil (தமிழ்)</option>
              <option value="fr">French (Français)</option>
              <option value="ru">Russian (Русский)</option>
              <option value="hi">Hindi (हिन्दी)</option>
              <option value="es">Spanish (Español)</option>
            </select>
          </div>

          {/* -------- TIMEZONE -------- */}
          <div>
            <label className="block font-medium mb-1">
              {getTranslation("timezone", language)}
            </label>
            <select
              value={settings.timezone}
              onChange={(e) => handleChange("timezone", e.target.value)}
              className="w-full border rounded px-3 py-2"
            >
              <option>Asia/Tokyo</option>
              <option>Asia/Kolkata</option>
              <option>UTC</option>
              <option>America/New_York</option>
            </select>
          </div>

          {/* -------- THEME -------- */}
          <div>
            <label className="block font-medium mb-1">
              {getTranslation("theme", language)}
            </label>
            <select
              value={settings.theme}
              onChange={(e) => handleChange("theme", e.target.value)}
              className="w-full border rounded px-3 py-2"
            >
              <option>Light</option>
              <option>Dark</option>
              <option>System Default</option>
            </select>
          </div>
        </div>
      </div>

      {/* ================= NOTIFICATIONS ================= */}
      <div className="bg-white rounded-2xl shadow p-6 space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">
          {getTranslation("notifications", language)}
        </h2>

        <div className="space-y-3 text-sm">
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={settings.emailNotifications}
              onChange={(e) =>
                handleChange("emailNotifications", e.target.checked)
              }
            />
            <span>{getTranslation("emailNotifications", language)}</span>
          </label>

          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={settings.desktopNotifications}
              onChange={(e) =>
                handleChange("desktopNotifications", e.target.checked)
              }
            />
            <span>{getTranslation("desktopNotifications", language)}</span>
          </label>
        </div>
      </div>

      {/* ================= SAVE ================= */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700"
        >
          {getTranslation("saveChanges", language)}
        </button>
      </div>
    </div>
  );
}

export default Setting;
