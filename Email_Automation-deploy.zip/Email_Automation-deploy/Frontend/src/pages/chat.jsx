import React, { useState } from "react";
import { 
  Wand2, 
  Search, 
  ArrowUpDown, 
  Tag, 
  Settings2, 
  Plus, 
  Users, 
  MoreHorizontal,
  CheckCheck, 
  MapPin,
  ChevronDown, // Added this
  Paperclip, 
  Image, 
  Smile, 
  Send, 
  X 
} from "lucide-react";

const Chart = () => {
  // State to manage User Section visibility
  const [isUserSectionOpen, setIsUserSectionOpen] = useState(true);
  const [message, setMessage] = useState("");

  const tickets = [
    { id: "#232", name: "Melody Cols", msg: "Hello, May I help you?", time: "3m", priority: "Medium", status: "ACTIVE", count: 12, active: true },
    { id: "gino_flores", name: "Gino Flores", msg: "I have a question related...", time: "3m", priority: "Medium", status: "ACTIVE", count: 10, social: "ig" },
    { id: "#231", name: "Benny Hulme", msg: "Yes thank you! How can I ...", time: "3m", priority: "Medium", status: "IN PROGRESS", color: "blue" },
  ];

  return (
    <div className="flex h-full bg-white text-slate-800 font-sans overflow-hidden">
      
      {/* COLUMN 1: Ticket List */}
      <div className="w-80 border-r border-slate-200 flex flex-col shrink-0">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-medium text-slate-500">
            <span>All open tickets (2)</span>
            <ChevronDown size={14} />
          </div>
          <div className="flex gap-3 text-slate-400">
            <ArrowUpDown size={18} />
            <Search size={18} />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {tickets.map((ticket, i) => (
            <div key={i} className={`p-4 border-b border-slate-50 cursor-pointer hover:bg-slate-50 ${ticket.active ? 'bg-indigo-50/50' : ''}`}>
              <div className="flex gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden shrink-0">
                  <img src={`https://ui-avatars.com/api/?name=${ticket.name}`} alt="avatar" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <h4 className="text-sm font-semibold text-indigo-600 truncate">Issue {ticket.id}</h4>
                    <span className="text-xs text-slate-400">{ticket.time}</span>
                  </div>
                  <p className="text-xs text-slate-500 mb-1">{ticket.name}</p>
                  <p className="text-sm text-slate-600 truncate">{ticket.msg}</p>
                </div>
              </div>
              <div className="flex justify-between items-center mt-3">
                {ticket.count && <span className="bg-orange-100 text-orange-600 text-[10px] font-bold px-1.5 py-0.5 rounded">{ticket.count}</span>}
                <div className="flex items-center gap-2 ml-auto">
                  <span className="w-2 h-2 rounded-full bg-green-500"></span>
                  <span className="text-[10px] font-bold text-slate-400">{ticket.priority}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${ticket.color === 'blue' ? 'bg-blue-100 text-blue-600' : 'text-green-600'}`}>
                    {ticket.status}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

{/* COLUMN 2: Chat Interface - flex-col and overflow-hidden ensures it stays fixed */}
{/* COLUMN 2: Chat Interface */}
<div className="flex-1 flex flex-col bg-white min-w-0 h-full overflow-hidden">
  
  {/* Chat Header - shrink-0 keeps it fixed at the top */}
  <div className="h-16 border-b border-slate-200 px-6 flex items-center justify-between shrink-0 bg-white">
    <div className="flex items-center gap-3">
      <h2 className="text-lg font-bold text-slate-800">Issue #232</h2>
      <span className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded">ACTIVE</span>
    </div>
    <div className="flex items-center gap-3">
      <button className="flex items-center gap-2 border border-slate-200 px-4 py-1.5 rounded-full text-sm font-medium hover:bg-slate-50 transition">
        <Wand2 size={16} className="text-indigo-600" />
        Summarize
      </button>
      <div className="flex items-center gap-4 text-slate-400 ml-4 border-l pl-4 border-slate-100">
        <Tag size={20} className="hover:text-slate-600 cursor-pointer" />
        <Settings2 size={20} className="hover:text-slate-600 cursor-pointer" />
        <Plus size={20} className="hover:text-slate-600 cursor-pointer" />
        <Users 
          size={20} 
          onClick={() => setIsUserSectionOpen(!isUserSectionOpen)}
          className={`cursor-pointer transition-colors ${isUserSectionOpen ? 'text-indigo-600' : 'hover:text-slate-600'}`} 
        />
      </div>
    </div>
  </div>

  
  <div className="flex-1  p-2 space-y-6 bg-[#F8F9FD] ">
    <div className="text-center text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-8">Feb 24, 2024</div>
    
 {/* Outgoing Human Agent Message */}
<div className="flex justify-end gap-3 ">
  <div className="flex flex-col items-end gap-1">
    <div className="bg-indigo-600 text-white p-3 rounded-2xl rounded-tr-none max-w-md text-sm relative shadow-sm break-words">
      {/* Label changed from AI Chatbot to Agent/User Name */}
      <span className="absolute -top-5 right-0 text-[10px] font-bold text-slate-400">Agent (You)</span>
      
      Hi there Melody! I'm looking into your delivery status right now.
    </div>
    
    {/* Status and Time */}
    <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1 pr-1">
      16:54 <CheckCheck size={12} className="text-green-500" />
    </div>
  </div>

  {/* SENDER ICON (Human Avatar) */}
  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center shrink-0 shadow-sm border border-slate-100 overflow-hidden">
    {/* Using a UI avatar or UserCircleIcon instead of a Wand */}
    <img 
      src="https://ui-avatars.com/api/?name=Admin+User&background=6C72E6&color=fff" 
      alt="Agent Avatar" 
      className="w-full h-full object-cover"
    />
  </div>
</div>

    {/* Incoming Message */}
    <div className="flex gap-3">
      <div className="w-8 h-8 rounded-full bg-slate-200 shrink-0 overflow-hidden border border-slate-100">
         <img src="https://ui-avatars.com/api/?name=Melody+Cols&background=random" alt="avatar" />
      </div>
      <div className="flex flex-col gap-1">
        <div className="bg-white p-3 rounded-2xl rounded-tl-none max-w-md text-sm shadow-sm border border-slate-100">
          <span className="block text-[10px] font-bold text-slate-400 mb-1">Melody Cols</span>
          Can you please provide location of my food delivery?
        </div>
        <span className="text-[10px] text-slate-400 ml-1">16:55</span>
      </div>
    </div>
  </div>

  {/* MESSAGE INPUT SECTION - shrink-0 keeps it fixed at the bottom */}
  <div className="p-4 border-t border-slate-200 bg-white shrink-0">
    <div className="flex flex-col border border-slate-200 rounded-xl focus-within:border-indigo-300 focus-within:ring-4 focus-within:ring-indigo-50 transition-all bg-white shadow-sm">
      <textarea 
        rows="2"
        className="w-full p-3 text-sm focus:outline-none resize-none bg-transparent"
        placeholder="Type your message here..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <div className="flex items-center justify-between p-2 border-t border-slate-50 bg-slate-50/50 rounded-b-xl">
        <div className="flex items-center gap-3 text-slate-400 ml-1">
          <label className="cursor-pointer hover:text-indigo-600 transition p-1.5 hover:bg-white rounded-md">
            <Paperclip size={18} />
            <input type="file" className="hidden" />
          </label>
          <label className="cursor-pointer hover:text-indigo-600 transition p-1.5 hover:bg-white rounded-md">
            <Image size={18} />
            <input type="file" accept="image/*" className="hidden" />
          </label>
          <div className="p-1.5 hover:bg-white rounded-md cursor-pointer hover:text-indigo-600 transition">
            <Smile size={18} />
          </div>
        </div>
        <button 
          className={`p-2 px-4 rounded-lg flex items-center gap-2 transition-all font-medium text-sm ${message ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'bg-slate-100 text-slate-400'}`}
          disabled={!message}
        >
          <span>Send</span>
          <Send size={16} />
        </button>
      </div>
    </div>
  </div>
</div>

      {/* COLUMN 3: Details Sidebar (Closable) */}
      <div className={`transition-all duration-300 ease-in-out border-l border-slate-200 flex flex-col overflow-hidden bg-white
        ${isUserSectionOpen ? 'w-72' : 'w-0 border-l-0'}`}
      >
        <div className="min-w-[18rem] p-6 flex flex-col gap-8">
          <div className="flex justify-between items-start">
             <div className="flex flex-col items-center text-center flex-1">
                <div className="w-16 h-16 rounded-full overflow-hidden mb-3 ring-2 ring-indigo-50 ring-offset-2">
                  <img src="https://ui-avatars.com/api/?name=Melody+Cols" alt="Melody" />
                </div>
                <h3 className="font-bold text-slate-800">Melody Cols</h3>
                <button className="mt-2 text-[10px] font-bold px-3 py-1 border border-slate-200 rounded text-slate-500 uppercase">Custom</button>
             </div>
             <X 
               size={18} 
               className="text-slate-400 cursor-pointer hover:text-slate-600" 
               onClick={() => setIsUserSectionOpen(false)}
             />
          </div>

          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase mb-4">Ticket Information</h4>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-slate-400">Ticket ID</span><span className="font-medium">#232</span></div>
              <div className="flex justify-between"><span className="text-slate-400">Priority</span><span className="font-medium">Medium</span></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase">Customer fields</h4>
              <Settings2 size={14} className="text-slate-400" />
            </div>
            <div className="space-y-4">
              <div>
                 <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Segment <span className="text-red-400">*</span></label>
                 <input type="text" className="w-full border-b border-slate-200 py-1 focus:outline-none text-sm bg-transparent" placeholder="Add segment" />
              </div>
              <div>
                 <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Email <span className="text-red-400">*</span></label>
                 <input type="text" className="w-full border-b border-slate-200 py-1 focus:outline-none text-sm bg-transparent" value="melody@example.com" readOnly />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chart;