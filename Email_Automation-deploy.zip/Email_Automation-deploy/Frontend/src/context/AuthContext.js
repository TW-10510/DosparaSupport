import React, { createContext, useContext, useMemo, useState } from "react";

const AuthContext = createContext(null);

// Helper to safely lower-case roles
const normalizeRole = (role) => (role || "").toLowerCase();

const getStoredAuth = () => {
  const token = localStorage.getItem("token");
  const userId = localStorage.getItem("user_id");
  const role = localStorage.getItem("role");
  const userRaw = localStorage.getItem("user");
  const permissionsRaw = localStorage.getItem("permissions");

  let user = null;
  if (userRaw) {
    try {
      user = JSON.parse(userRaw);
    } catch (err) {
      user = null;
    }
  }

  let permissions = [];
  if (permissionsRaw) {
    try {
      permissions = JSON.parse(permissionsRaw);
    } catch (err) {
      permissions = [];
    }
  }

  return {
    token: token || null,
    userId: userId ? Number(userId) : null,
    role: role || user?.role || null,
    user,
    permissions,
  };
};

export function AuthProvider({ children }) {
  const stored = getStoredAuth();
  
  // State initialization
  const [token, setToken] = useState(stored.token);
  const [user, setUser] = useState(stored.user);
  const [userId, setUserId] = useState(stored.userId);
  const [role, setRole] = useState(stored.role);
  // ✅ New State for Permissions
  const [userPermissions, setUserPermissions] = useState(stored.permissions);

  const login = ({ token: newToken, user: newUser }) => {
    const resolvedRole = newUser?.role || null;
    const resolvedToken = newToken || null;
    const resolvedUserId = newUser?.id ?? null;
    // ✅ Extract Permissions from user object (sent from backend or login.js)
    const resolvedPermissions = newUser?.permissions || [];

    // 1. Update State
    setToken(resolvedToken);
    setUser(newUser);
    setUserId(resolvedUserId);
    setRole(resolvedRole);
    setUserPermissions(resolvedPermissions);

    // 2. Persist to LocalStorage
    if (resolvedToken) {
      localStorage.setItem("token", resolvedToken);
    } else {
      localStorage.removeItem("token");
    }

    if (resolvedUserId !== null) {
      localStorage.setItem("user_id", String(resolvedUserId));
    } else {
      localStorage.removeItem("user_id");
    }

    if (resolvedRole) {
      localStorage.setItem("role", resolvedRole);
    } else {
      localStorage.removeItem("role");
    }

    if (newUser) {
      localStorage.setItem("user", JSON.stringify(newUser));
    } else {
      localStorage.removeItem("user");
    }

    // ✅ Save Permissions
    localStorage.setItem("permissions", JSON.stringify(resolvedPermissions));
  };

  const logout = () => {
    // 1. Clear State
    setToken(null);
    setUser(null);
    setUserId(null);
    setRole(null);
    setUserPermissions([]);

    // 2. Clear Storage
    localStorage.removeItem("token");
    localStorage.removeItem("user_id");
    localStorage.removeItem("role");
    localStorage.removeItem("user");
    localStorage.removeItem("permissions");
  };

  const value = useMemo(
    () => ({
      token,
      user,
      userId,
      role,
      userPermissions, // ✅ Exposed to App.js
      normalizedRole: normalizeRole(role),
      isAuthenticated: Boolean(userId),
      login,
      logout,
    }),
    [token, user, userId, role, userPermissions]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}