import React, { createContext, useState, useContext, useRef } from "react";

const TranslationContext = createContext();

export const TranslationProvider = ({ children }) => {
  const [language, setLanguage] = useState("en");
  const [loading, setLoading] = useState(false);

  // 🔥 Translation cache (key = lang:text)
  const cacheRef = useRef(new Map());

  const getCached = (key) => cacheRef.current.get(key);
  const setCached = (key, value) => cacheRef.current.set(key, value);

  // normalize base url
  const base = (process.env.REACT_APP_API_URL || "").replace(/\/+$/, "");

  const translate = async (text) => {
    if (!text) return text;
    if (language === "en") return text; // no-op

    const cacheKey = `${language}::${text}`;
    if (getCached(cacheKey)) return getCached(cacheKey);

    const endpoints = ["/api/ai/translate", "/api/drafts/translate"];

    for (const ep of endpoints) {
      try {
        const url = `${base}${ep}`;
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text, targetLang: language }),
        });
        if (!res.ok) continue;
        const data = await res.json();
        const t = data.translated || data.translation || data.result || data.text || text;
        setCached(cacheKey, t);
        return t;
      } catch (err) {
        continue;
      }
    }

    // fallback: return original text (avoid inserting debug annotations)
    setCached(cacheKey, text);
    return text;
  };

  const value = {
    language,
    setLanguage,
    loading,
    setLoading,
    getCached,
    setCached,
    translate,
  };

  return (
    <TranslationContext.Provider value={value}>
      {children}
    </TranslationContext.Provider>
  );
};

export const useTranslation = () => useContext(TranslationContext);
