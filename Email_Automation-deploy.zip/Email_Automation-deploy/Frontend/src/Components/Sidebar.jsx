import React, { useEffect, useState } from "react";
import logo from "../assets/image1.png";
import { NavLink, useLocation } from "react-router-dom";
import {
  HomeIcon,
  EnvelopeIcon,
  ChartBarIcon,
  Cog6ToothIcon,
  UserCircleIcon,
  ChevronDownIcon,
  InboxIcon,
  PaperAirplaneIcon,
  DocumentIcon,
  ChatBubbleLeftRightIcon,
  Bars3Icon,
} from "@heroicons/react/24/outline";

import { getTranslation } from "../utils/translations";
import { useTranslation } from "../context/TranslationContext";
import { useAuth } from "../context/AuthContext";

const ROLES = {
  SUPER_ADMIN: "super admin",
  ADMIN: "admin",
  EMPLOYEE: "employee",
  VIEWER: "viewer",
};

const EMPLOYEE_ACCESS = [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.EMPLOYEE];

export default function Sidebar({ language = "en" }) {
  const location = useLocation();
  const { language: contextLanguage } = useTranslation();
  const lang = contextLanguage || language;
  const { normalizedRole } = useAuth();
  
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [emailOpen, setEmailOpen] = useState(false);
  const [activeItem, setActiveItem] = useState("");

  const isRoleAllowed = (allowedRoles) => !allowedRoles || allowedRoles.includes(normalizedRole);

  useEffect(() => {
    const path = location.pathname;
    if (path.startsWith("/inbox")) { setEmailOpen(true); setActiveItem("inbox"); }
    else if (path.startsWith("/senditems")) { setEmailOpen(true); setActiveItem("senditems"); }
    else if (path.startsWith("/email/draft")) { setEmailOpen(true); setActiveItem("draft"); }
    else if (path === "/analytics") setActiveItem("analytics");
    else if (path === "/chat") setActiveItem("chat");
    else if (path === "/") setActiveItem("home");
    else if (path === "/account") setActiveItem("account");
    else if (path === "/setting") setActiveItem("settings");
  }, [location.pathname]);

  const menuItems = [
    { name: getTranslation("home", lang), path: "/home", icon: HomeIcon, key: "home", allowedRoles: EMPLOYEE_ACCESS },
    { name: getTranslation("email", lang), path: "/email", icon: EnvelopeIcon, hasDropdown: true, key: "email", allowedRoles: EMPLOYEE_ACCESS },
    { name: getTranslation("analytics", lang), path: "/analytics", icon: ChartBarIcon, key: "analytics", allowedRoles: EMPLOYEE_ACCESS },
    { name: getTranslation("chat", lang), path: "/chat", icon: ChatBubbleLeftRightIcon, key: "chat", allowedRoles: EMPLOYEE_ACCESS },
  ];

  // DEFINITION ADDED HERE TO FIX 'no-undef' ERROR
  const emailSubMenu = [
    { name: getTranslation("inbox", lang), path: "/inbox", icon: InboxIcon, key: "inbox", allowedRoles: EMPLOYEE_ACCESS },
    { name: getTranslation("senditems", lang), path: "/senditems", icon: PaperAirplaneIcon, key: "senditems", allowedRoles: EMPLOYEE_ACCESS },
    { name: getTranslation("draft", lang), path: "/email/draft", icon: DocumentIcon, key: "draft", allowedRoles: EMPLOYEE_ACCESS },
  ];

  const bottomItems = [
    { name: getTranslation("account", lang), path: "/account", icon: UserCircleIcon, key: "account", allowedRoles: EMPLOYEE_ACCESS },
    { name: getTranslation("setting", lang), path: "/setting", icon: Cog6ToothIcon, key: "settings", allowedRoles: EMPLOYEE_ACCESS },
  ];

  const filteredMenuItems = menuItems.filter(item => isRoleAllowed(item.allowedRoles));
  const filteredEmailSubMenu = emailSubMenu.filter(item => isRoleAllowed(item.allowedRoles));
  const filteredBottomItems = bottomItems.filter(item => isRoleAllowed(item.allowedRoles));

  return (
    <aside className={`${isCollapsed ? "w-20" : "w-64"} h-screen flex flex-col justify-between bg-[#6C72E6] text-white shadow-lg transition-all duration-300`}>
      <div className="py-4 flex flex-col items-center">
        <div className="flex items-center justify-between w-full px-4 mb-4">
          {!isCollapsed && <img src={logo} alt="Logo" className="h-8 w-auto object-contain" />}
          <button onClick={() => setIsCollapsed(!isCollapsed)} className="p-2 rounded-lg hover:bg-[#7D81EC]">
            <Bars3Icon className="w-6 h-6" />
          </button>
        </div>
        <hr className="w-full border-[#8C90F0]" />
      </div>

      <nav className="flex-1 px-3 overflow-y-auto">
        <ul className="flex flex-col gap-1">
          {filteredMenuItems.map((item) => {
            const Icon = item.icon;
            if (item.hasDropdown && !isCollapsed) {
              return (
                <li key={item.key}>
                  <button onClick={() => { setEmailOpen(!emailOpen); setActiveItem("email"); }}
                    className={`flex items-center justify-between w-full px-4 py-3 rounded-lg transition ${activeItem === "email" ? "bg-white text-[#6C72E6]" : "hover:bg-[#7D81EC]"}`}>
                    <div className="flex items-center gap-3">
                      <Icon className="w-6 h-6" />
                      <span>{item.name}</span>
                    </div>
                    <ChevronDownIcon className={`w-4 h-4 transition-transform ${emailOpen ? "rotate-180" : ""}`} />
                  </button>
                  {emailOpen && (
                    <ul className="ml-4 mt-1 space-y-1">
                      {filteredEmailSubMenu.map((sub) => (
                        <li key={sub.key}>
                          <NavLink to={sub.path} onClick={() => setActiveItem(sub.key)}
                            className={`flex items-center gap-3 px-4 py-2 rounded-md text-sm transition ${activeItem === sub.key ? "bg-white text-[#6C72E6]" : "hover:bg-[#8E92F2]"}`}>
                            <sub.icon className="w-4 h-4" />
                            <span>{sub.name}</span>
                          </NavLink>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              );
            }
            return (
              <li key={item.key}>
                <NavLink to={item.path} title={isCollapsed ? item.name : ""} onClick={() => setActiveItem(item.key)}
                  className={`flex items-center ${isCollapsed ? "justify-center" : "gap-3"} px-4 py-3 rounded-lg transition ${activeItem === item.key ? "bg-white text-[#6C72E6]" : "hover:bg-[#7D81EC]"}`}>
                  <Icon className="w-6 h-6 shrink-0" />
                  {!isCollapsed && <span>{item.name}</span>}
                </NavLink>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="px-3 mb-6">
        <hr className="border-white/40 mb-3" />
        <ul className="flex flex-col gap-1">
          {filteredBottomItems.map((item) => (
            <li key={item.key}>
              <NavLink to={item.path} title={isCollapsed ? item.name : ""} onClick={() => setActiveItem(item.key)}
                className={`flex items-center ${isCollapsed ? "justify-center" : "gap-3"} px-4 py-3 rounded-lg transition ${activeItem === item.key ? "bg-white text-[#6C72E6]" : "hover:bg-[#7D81EC]"}`}>
                <item.icon className="w-6 h-6 shrink-0" />
                {!isCollapsed && <span>{item.name}</span>}
              </NavLink>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}