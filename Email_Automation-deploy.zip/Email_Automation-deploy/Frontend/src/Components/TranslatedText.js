import React, { useEffect, useState, useRef } from "react";
import { useTranslation } from "../context/TranslationContext";

function TranslatedText({ text }) {
  const { language, setLoading, getCached, setCached } = useTranslation();

  const [translated, setTranslated] = useState(text);
  const abortRef = useRef(null);

  useEffect(() => {
    // 1️⃣ English → no translation
    if (!text || language === "en") {
      setTranslated(text);
      return;
    }

    // 2️⃣ Cache key
    const cacheKey = `${language}:${text}`;

    // 3️⃣ Serve from cache (INSTANT)
    const cached = getCached(cacheKey);
    if (cached) {
      setTranslated(cached);
      return;
    }

    // 4️⃣ Cancel previous request
    if (abortRef.current) {
      abortRef.current.abort();
    }

    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);

    fetch(`${process.env.REACT_APP_API_URL}/api/ai/translate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, targetLang: language }),
      signal: controller.signal,
    })
      .then((res) => res.json())
      .then((data) => {
        if (data?.translated) {
          setTranslated(data.translated);
          setCached(cacheKey, data.translated); // ✅ cache it
        } else {
          setTranslated(text);
        }
      })
      .catch((err) => {
        if (err.name !== "AbortError") {
          setTranslated(text);
        }
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [text, language]);

  return <>{translated}</>;
}

export default TranslatedText;
