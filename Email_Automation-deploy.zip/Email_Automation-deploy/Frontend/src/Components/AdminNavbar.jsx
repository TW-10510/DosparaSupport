import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  ChartBarIcon,
  TicketIcon,
  UsersIcon,
  ShieldCheckIcon,
  Cog6ToothIcon,
  DocumentTextIcon,
  ClipboardDocumentListIcon,
  ArrowRightOnRectangleIcon,
  EnvelopeIcon,
  UserCircleIcon,
  ChevronUpIcon
} from "@heroicons/react/24/outline";

// Context & Utils
import { useTranslation } from "../context/TranslationContext";
import { getAdminTranslation } from "../utils/adminTranslations";
import { useAuth } from "../context/AuthContext";

export default function AdminNavbar() {
  const navigate = useNavigate();
  const { language } = useTranslation();
  
  // ✅ Get user, permissions, and role
  const { user, normalizedRole, userPermissions, logout } = useAuth();
  
  // State for toggling the user menu (Logout option)
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/", { replace: true });
  };

  const canAccess = (permissionName) => {
    if (normalizedRole === "super admin") return true;
    return userPermissions && userPermissions.includes(permissionName);
  };

  const navItemClass = ({ isActive }) =>
    `flex items-center gap-3 px-4 py-2 rounded-md text-sm font-medium transition
      ${isActive ? "bg-indigo-600 text-white" : "text-gray-700 hover:bg-gray-100"}`;

  return (
    <aside className="w-64 min-h-screen bg-white border-r shadow-sm flex flex-col font-sans">
      {/* Header */}
      <div className="px-6 py-4 border-b shrink-0">
        <h1 className="text-lg font-bold text-indigo-600">
          {getAdminTranslation("adminPanel", language)}
        </h1>
        <p className="text-xs text-gray-500">
          {getAdminTranslation("emailSystem", language)}
        </p>
      </div>

      {/* Navigation (Scrollable) */}
      <nav className="p-4 space-y-1 flex-1 overflow-y-auto">
        
        {/* Dashboard */}
        {canAccess("admin_dashboard") && (
          <NavLink to="/admin/admindashboard" className={navItemClass}>
            <ChartBarIcon className="w-5 h-5" />
            {getAdminTranslation("dashboard", language)}
          </NavLink>
        )}

        {/* Tickets */}
        {canAccess("tickets") && (
          <NavLink to="/admin/tickets" className={navItemClass}>
            <TicketIcon className="w-5 h-5" />
            {getAdminTranslation("tickets", language)}
          </NavLink>
        )}

        {/* Sent Emails */}
        {canAccess("email_history") && (
          <NavLink to="/admin/sent_email" className={navItemClass}>
            <EnvelopeIcon className="w-5 h-5" />
            {getAdminTranslation("sentEmails", language)}
          </NavLink>
        )}

        {/* User Management */}
        {canAccess("user_management") && (
          <NavLink to="/admin/user_management" className={navItemClass}>
            <UsersIcon className="w-5 h-5" />
            {getAdminTranslation("userManagement", language)}
          </NavLink>
        )}

        {/* Roles & Permissions */}
        {canAccess("roles_permissions") && (
          <NavLink to="/admin/roles_permissions" className={navItemClass}>
            <ShieldCheckIcon className="w-5 h-5" />
            {getAdminTranslation("rolesPermissions", language)}
          </NavLink>
        )}

        {/* Templates */}
        {canAccess("templates") && (
          <NavLink to="/admin/templates" className={navItemClass}>
            <DocumentTextIcon className="w-5 h-5" />
            {getAdminTranslation("templates", language)}
          </NavLink>
        )}

        {/* Reports & Logs */}
        {canAccess("reports") && (
          <NavLink to="/admin/reports_logs" className={navItemClass}>
            <ClipboardDocumentListIcon className="w-5 h-5" />
            {getAdminTranslation("reportsLogs", language)}
          </NavLink>
        )}

        
        {/* Reports & Logs */}
        {canAccess("API Keys Usage") && (
          <NavLink to="/admin/api_usage" className={navItemClass}>
            <ClipboardDocumentListIcon className="w-5 h-5" />
            {getAdminTranslation("API Keys Usage", language)}
          </NavLink>
        )}

        {/* Settings */}
        {canAccess("settings") && (
          <NavLink to="/admin/settings" className={navItemClass}>
            <Cog6ToothIcon className="w-5 h-5" />
            {getAdminTranslation("settings", language)}
          </NavLink>
        )}
      </nav>

      {/* ✅ NEW FOOTER: User Profile & Toggle Menu */}
      <div className="p-4 border-t relative">
        
        {/* Pop-up Menu (Logout) */}
        {isUserMenuOpen && (
          <div className="absolute bottom-full left-0 w-full px-4 pb-2 z-20">
            <div className="bg-white border border-gray-200 shadow-lg rounded-xl p-1 overflow-hidden animate-in slide-in-from-bottom-2 fade-in duration-200">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 text-sm text-red-600 hover:bg-red-50 px-3 py-2.5 rounded-lg w-full transition font-medium"
              >
                <ArrowRightOnRectangleIcon className="w-5 h-5" />
                {getAdminTranslation("logout", language)}
              </button>
            </div>
          </div>
        )}

        {/* User Profile Button */}
        <button 
          onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
          className={`flex items-center gap-3 w-full p-2 rounded-lg transition-colors border border-transparent ${
            isUserMenuOpen ? "bg-indigo-50 border-indigo-100" : "hover:bg-gray-50"
          }`}
        >
          <div className="h-9 w-9 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center shrink-0">
             <UserCircleIcon className="w-6 h-6" />
          </div>
          
          <div className="flex-1 text-left min-w-0">
            <p className="text-sm font-semibold text-gray-900 truncate">
              {user?.name || "Admin User"}
            </p>
            <p className="text-xs text-gray-500 capitalize truncate">
              {user?.role || "Administrator"}
            </p>
          </div>

          <ChevronUpIcon 
            className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${
              isUserMenuOpen ? "rotate-180" : ""
            }`} 
          />
        </button>
      </div>
    </aside>
  );
}