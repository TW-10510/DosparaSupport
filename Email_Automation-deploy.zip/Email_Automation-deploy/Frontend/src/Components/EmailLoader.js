import React from "react";
import Lottie from "lottie-react";
import loadingAnimation from "../assets/gif/Loading_Paperplane.json";

function EmailLoader({ text = "Loading...", className = "" }) {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div className="w-40 h-40">
        <Lottie animationData={loadingAnimation} loop />
      </div>
      <p className="mt-4 text-sm text-gray-600">{text}</p>
    </div>
  );
}

export default EmailLoader;
