import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { getTranslation } from "../utils/translations";
import { useTranslation } from "../context/TranslationContext";

const API = process.env.REACT_APP_API_URL || "http://localhost:8000/api";

export default function TopNavbar({ search, setSearch, language = "en" }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { language: contextLanguage } = useTranslation();
  const lang = contextLanguage || language;
  const navigate = useNavigate();

  const currentUser = (() => {
    try {
      return JSON.parse(localStorage.getItem("user"));
    } catch {
      return null;
    }
  })();

  const handleLogout = async () => {
    try {
      if (currentUser?.id) {
        await fetch(`${API}/auth/logout`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_id: currentUser.id }),
        });
      }
    } catch (err) {
      console.error("Logout error:", err);
    } finally {
      localStorage.removeItem("user");
      setMenuOpen(false);
      navigate("/");
    }
  };

  return (
    <div className="topbar flex justify-between items-center px-4 py-8 bg-white shadow-sm">
      {/* Search */}
      <div className="w-1/3">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={getTranslation("searchPlaceholder", lang)}
          className="border rounded-md px-3 py-2 w-full"
        />
      </div>

      {/* User */}
      <div className="flex items-center space-x-3 relative">
        <div className="w-9 h-9 rounded-full bg-gray-400" />
        <span className="text-sm font-medium">
          {currentUser?.email || "User"}
        </span>

        <ChevronDownIcon
          className="w-5 h-5 cursor-pointer"
          onClick={() => setMenuOpen(!menuOpen)}
        />

        {menuOpen && (
          <div className="absolute right-0 top-12 w-40 bg-white border shadow rounded">
            <ul>
              <li
                className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                onClick={handleLogout}
              >
                {getTranslation("logout", lang)}
              </li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
