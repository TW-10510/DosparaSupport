import os
import logging
import threading
 
from dotenv import load_dotenv
load_dotenv()
 
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
 
# ---------------------------------------------------------
# Imports that do NOT depend on app
# ---------------------------------------------------------
from services.ms_auth import get_auth_url, exchange_code
from services.graph_inbox_worker import poll
from database import Base, engine
from services.sla_watcher import run_sla_watcher
from services.ms_auth import _load
 
import models
# ---------------------------------------------------------
# Create FastAPI app
# ---------------------------------------------------------
app = FastAPI(title="Email Automation Backend")
 
# ---------------------------------------------------------
# Logging
# ---------------------------------------------------------
logger = logging.getLogger("backend.main")
logging.basicConfig(level=logging.INFO)
 
# ---------------------------------------------------------
# CORS
# ---------------------------------------------------------
origins = [
    "http://localhost:3000",
    "http://localhost:3002",
    "http://localhost:3016",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:3002",
    "http://127.0.0.1:3016",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3012",
    "http://127.0.0.1:3012",
    "http://localhost:3013",
    "http://127.0.0.1:3013",
]
 
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
 
# ---------------------------------------------------------
# Include routers
# ---------------------------------------------------------
included = []
 
# 1. AUTH
try:
    import importlib
    auth_mod = importlib.import_module("routers.auth")
    app.include_router(auth_mod.router)
    included.append("auth")
except Exception as e:
    logger.exception("Failed to include auth router: %s", e)
 
# 2. RAG
try:
    from routers import rag_generate as rag_mod
    app.include_router(rag_mod.router, prefix="/api/rag")
    included.append("rag")
except Exception as e:
    logger.warning("Could not include rag_generate router: %s", e)
 
# 3. CLASSIFY
try:
    from routers import classify as classify_mod
    app.include_router(classify_mod.router, prefix="/api/classify")
    included.append("classify")
except Exception as e:
    logger.warning("Could not include classify router: %s", e)
 
# 4. INBOX
try:
    from routers import inbox as inbox_mod
    app.include_router(inbox_mod.router, prefix="/api/inbox")
    included.append("inbox")
except Exception as e:
    logger.warning("Could not include inbox router: %s", e)
 
# 5. DRAFTS
try:
    from routers import drafts as drafts_mod
    app.include_router(drafts_mod.router, prefix="/api/drafts")
    included.append("drafts")
except Exception as e:
    logger.warning("Could not include drafts router: %s", e)
 
# 6. SEND EMAIL
# IMPORTANT: do NOT silence this router
from routers import send_email as send_mod
app.include_router(send_mod.router, prefix="/api/send-email")
included.append("send-email")
 
# 7. SENT ITEMS
try:
    from routers import sent as sent_mod
    app.include_router(sent_mod.router, prefix="/api/sent")
    included.append("sent")
except Exception as e:
    logger.warning("Could not include sent router: %s", e)
 
# 8. ADMIN ASSIGNMENT
try:
    from routers import admin_assignment as admin_assign_mod
    app.include_router(admin_assign_mod.router)
    included.append("admin")
except Exception as e:
    logger.warning("Could not include admin router: %s", e)
 
# 9. TEMPLATES (✅ MERGED HERE)
try:
    from routers import templates as templates_mod
    # Prefix is already defined in templates.py as "/api/templates"
    # providing it again here is optional but safe if they match
    app.include_router(templates_mod.router)
    included.append("templates")
except Exception as e:
    logger.warning("Could not include templates router: %s", e)

# 10. TICKETS
try:
    from routes import tickets as tickets_mod
    app.include_router(tickets_mod.router)
    included.append("tickets")
except Exception as e:
    logger.warning("Could not include tickets router: %s", e)

logger.info("Included routers: %s", included)
 
 # 11. REPORTS & LOGS
from routers import reports   # or reportlogs
app.include_router(reports.router, prefix="/api/reports")
included.append("reports")

# ---------------------------------------------------------
# Microsoft Graph Auth Routes
# ---------------------------------------------------------
@app.get("/auth/login")
def graph_login():
    return {"auth_url": get_auth_url()}
 
@app.get("/auth/callback")
def graph_callback(request: Request):
    code = request.query_params.get("code")
 
    if not code:
        return JSONResponse({"error": "Missing code"}, status_code=400)
 
    # If token already exists, do not re-exchange
    if _load():
        return RedirectResponse(url="/auth/success")
 
    try:
        exchange_code(code)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
 
    return RedirectResponse(url="/auth/success")
 
# ---------------------------------------------------------
# Start Background Workers
# ---------------------------------------------------------
@app.on_event("startup")
def start_workers():
    # 🔥 ENSURE TABLES EXIST BEFORE ANY WORKERS
    Base.metadata.create_all(bind=engine)
    logger.info("✅ Database tables ensured")
 
    logger.info("Starting Microsoft Graph inbox worker...")
    threading.Thread(target=poll, daemon=True).start()
 
    logger.info("Starting SLA watcher...")
    threading.Thread(target=run_sla_watcher, daemon=True).start()
 
 
 
# ---------------------------------------------------------
# Serve frontend build (optional)
# ---------------------------------------------------------
FRONTEND_BUILD_DIR = os.getenv(
    "FRONTEND_BUILD_DIR",
    os.path.abspath(os.path.join(os.path.dirname(__file__), "../frontend/build")),
)
 
if os.path.isdir(FRONTEND_BUILD_DIR):
    static_dir = os.path.join(FRONTEND_BUILD_DIR, "static")
 
    if os.path.isdir(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")
 
    index_file = os.path.join(FRONTEND_BUILD_DIR, "index.html")
 
    @app.get("/", response_class=HTMLResponse)
    async def serve_index():
        return FileResponse(index_file)
 
    @app.get("/{full_path:path}", response_class=HTMLResponse)
    async def serve_spa(full_path: str):
        if full_path.startswith("api") or full_path.startswith("static"):
            return JSONResponse({"detail": "Not Found"}, status_code=404)
        return FileResponse(index_file)
 
else:
    @app.get("/")
    async def api_root():
        return {"status": "backend running", "routers": included}



