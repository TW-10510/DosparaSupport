import time, json, os, requests
from services.ms_auth import get_access_token
from services.rag_pipeline import generate_reply_for_email
from services.prefilter import should_ignore_email
from services.classifier import classify_email
from bs4 import BeautifulSoup

DATA_DIR = os.getenv('DATA_DIR','email_automation_dataset')
INBOX = os.path.join(DATA_DIR,'inbox.jsonl')

processed=set()
if os.path.exists(INBOX):
    with open(INBOX,'r',encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    processed.add(json.loads(line).get('id'))
                except: pass
print('Processed IDs:', len(processed))

BASE='https://graph.microsoft.com/v1.0'
headers={'Authorization':f'Bearer {get_access_token()}','Content-Type':'application/json'}
params={'$top':50,'$orderby':'receivedDateTime desc'}
resp=requests.get(f'{BASE}/me/mailFolders/Inbox/messages', headers=headers, params=params)
resp.raise_for_status()
msgs=resp.json().get('value',[])
print('Fetched', len(msgs),'messages')

count=0
for m in msgs:
    if m.get('id') in processed: continue
    msg_id=m.get('id')
    sender_obj=m.get('from',{}).get('emailAddress',{})
    sender_email=sender_obj.get('address')
    sender_name=sender_obj.get('name') or 'Customer'
    subject=m.get('subject','')
    body_obj=m.get('body',{})
    raw=body_obj.get('content','')
    if body_obj.get('contentType','').lower()=='html':
        soup=BeautifulSoup(raw,'html.parser')
        for tag in soup(['script','style']): tag.decompose()
        body=' '.join(soup.get_text(separator=' ').split())
    else:
        body=raw or ''
    ignore, reason = should_ignore_email(subject, sender_email, body)
    if ignore:
        print('Skipping', subject, 'reason', reason)
        continue
    classification = classify_email(body)
    try:
        rag = generate_reply_for_email(body, sender_name=sender_name)
        draft = rag.get('reply','')
    except Exception as e:
        print('RAG failed, using empty draft for', subject, e)
        draft=''
    item={
        'id': msg_id,
        'sender_email': sender_email,
        'sender_name': sender_name,
        'subject': subject,
        'content': body,
        'preview': (body[:120] if body else ''),
        'classification': classification,
        'draft_reply': draft,
        'status': 'pending_approval',
        'received_at': int(time.time()),
    }
    with open(INBOX,'a',encoding='utf-8') as f:
        f.write(json.dumps(item, ensure_ascii=False)+'\n')
    processed.add(msg_id)
    count+=1
    print('Appended:', subject)
    if count>=20: break
print('Done, appended',count)
