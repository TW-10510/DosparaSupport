from sqlalchemy import Column, BigInteger, String, Boolean, TIMESTAMP
from sqlalchemy.sql import func
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(BigInteger, primary_key=True, index=True)

    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)

    email = Column(String(255), unique=True, nullable=False, index=True)

    password_hash = Column(String, nullable=False)

    role = Column(String(20), nullable=False, default="employee")
    # allowed values: employee | customer

    is_active = Column(Boolean, default=True)

    created_at = Column(
        TIMESTAMP(timezone=True),
        server_default=func.now()
    )
    # ✅ ADD THIS (VERY IMPORTANT)
    last_seen_at = Column(
        TIMESTAMP(timezone=True),
        nullable=True
    )