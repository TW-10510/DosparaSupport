from sqlalchemy import (
    Column,
    Integer,
    BigInteger,
    Text,
    String,
    DateTime,
    ForeignKey,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
 
from database import Base
 
 
class EmailRecord(Base):
    __tablename__ = "email_records"
 
    # -----------------------------
    # Primary key
    # -----------------------------
    id = Column(BigInteger, primary_key=True, index=True)
 
    # -----------------------------
    # Timestamps
    # -----------------------------
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    assigned_at = Column(DateTime, nullable=True)
    sent_at = Column(DateTime, nullable=True)
 
    # -----------------------------
    # THREADING (NEW ✅)
    # -----------------------------
    # Outlook conversationId
    thread_id = Column(Text, index=True, nullable=True)
 
    # Previous email in the same thread
    parent_id = Column(
        BigInteger,
        ForeignKey("email_records.id", ondelete="SET NULL"),
        nullable=True
    )
 
    # -----------------------------
    # Email content
    # -----------------------------
    recipient_email = Column(Text, nullable=False)
    subject = Column(Text, nullable=False)
    body = Column(Text, nullable=False)
 
    # -----------------------------
    # AI / RAG fields
    # -----------------------------
    draft_reply = Column(Text, nullable=True)
    language = Column(String(5), default="en")
 
    # -----------------------------
    # Message IDs (deduplication)
    # -----------------------------
    gmail_msg_id = Column(Text, unique=True, nullable=True)
    outlook_id = Column(Text, unique=True, nullable=True)
 
    # -----------------------------
    # Assignment & ownership
    # -----------------------------
    assigned_to = Column(Integer, nullable=True)   # who it is assigned to now
    handled_by = Column(Integer, nullable=True)    # who actually handled/sent it
 
    # -----------------------------
    # SLA
    # -----------------------------
    sla_deadline = Column(DateTime, nullable=True)
 
    # -----------------------------
    # Status
    # -----------------------------
    status = Column(Text, nullable=True)
 
    # -----------------------------
    # Relationships (OPTIONAL BUT VERY USEFUL)
    # -----------------------------
    parent = relationship(
        "EmailRecord",
        remote_side=[id],
        backref="children",
        passive_deletes=True,
    )