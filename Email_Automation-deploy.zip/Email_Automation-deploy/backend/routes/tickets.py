from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text

from database import SessionLocal


router = APIRouter(prefix="/api/tickets", tags=["tickets"])


class TicketCreate(BaseModel):
    subject: str = Field(..., min_length=1)
    recipient_email: str = Field(..., min_length=1)
    body: str = Field(..., min_length=1)


SELECT_TICKETS_SQL = """
SELECT
    id,
    subject,
    COALESCE(status, 'pending') AS status,
    assigned_to,
    created_at,
    sent_at,
    thread_id,
    COALESCE(reassigned_count, 0) AS reassigned_count,
    locked_by,
    locked_at
FROM email_records
ORDER BY created_at DESC NULLS LAST, id DESC
"""


@router.get("/")
def list_tickets():
    db = SessionLocal()
    try:
        rows = db.execute(text(SELECT_TICKETS_SQL)).mappings().all()
        return {"tickets": [dict(row) for row in rows]}
    finally:
        db.close()


@router.post("/")
def create_ticket(payload: TicketCreate):
    db = SessionLocal()
    try:
        row = db.execute(
            text(
                """
                INSERT INTO email_records (recipient_email, subject, body, status)
                VALUES (:recipient_email, :subject, :body, 'pending')
                RETURNING
                    id,
                    subject,
                    COALESCE(status, 'pending') AS status,
                    assigned_to,
                    created_at,
                    sent_at,
                    thread_id,
                    COALESCE(reassigned_count, 0) AS reassigned_count,
                    locked_by,
                    locked_at
                """
            ),
            payload.dict(),
        ).mappings().first()

        db.commit()

        if not row:
            raise HTTPException(status_code=500, detail="Ticket creation failed")

        return dict(row)
    except HTTPException:
        raise
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(exc))
    finally:
        db.close()


@router.delete("/{ticket_id}")
def delete_ticket(ticket_id: int):
    db = SessionLocal()
    try:
        result = db.execute(
            text("DELETE FROM email_records WHERE id = :ticket_id RETURNING id"),
            {"ticket_id": ticket_id},
        ).first()

        if not result:
            raise HTTPException(status_code=404, detail="Ticket not found")

        db.commit()
        return {"message": "Ticket deleted", "id": result[0]}
    except HTTPException:
        raise
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(exc))
    finally:
        db.close()
