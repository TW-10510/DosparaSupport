-- RBAC schema updates for permissions + role_permissions
CREATE TABLE IF NOT EXISTS permissions (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  category VARCHAR(50),
  scope VARCHAR(50),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (role_id, permission_id)
);

CREATE INDEX IF NOT EXISTS idx_roles_name_lower ON roles (LOWER(name));

-- Optional seed permissions (safe to re-run)
INSERT INTO permissions (name, description, category, scope)
VALUES
  ('roles.manage_permissions', 'Assign or revoke role permissions', 'Roles', 'Global'),
  ('users.manage', 'Create and manage users', 'Users', 'Global'),
  ('reports.view', 'View reports and logs', 'Reports', 'Global')
ON CONFLICT (name) DO NOTHING;
