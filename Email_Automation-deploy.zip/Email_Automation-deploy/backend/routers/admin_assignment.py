# backend/routers/admin_assignment.py
 
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
import psycopg2
import os
import json
import time
from datetime import datetime
 
from services.assignment_engine import get_next_employee_id
 
router = APIRouter(prefix="/api/admin", tags=["admin"])
 
DATABASE_URL = os.getenv("DATABASE_URL")
DATA_DIR = os.getenv("DATA_DIR", "email_automation_dataset")
INBOX_PATH = os.path.join(DATA_DIR, "inbox.jsonl")
 
# ---------------------------------------------------------
# Models
# ---------------------------------------------------------
class ReassignRequest(BaseModel):
    email_id: str
    new_user_id: int
    reason: str
 
# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------
def get_db_conn():
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL not set")
    return psycopg2.connect(DATABASE_URL)
 
def _read_jsonl(path):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf8") as f:
        return [json.loads(l) for l in f if l.strip()]
 
def _write_jsonl(path, items):
    with open(path, "w", encoding="utf8") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")
 
def _get_user_id(request: Request):
    uid = request.headers.get("X-User-Id")
    if not uid:
        raise HTTPException(status_code=401, detail="Missing user")
    return int(uid)
 
def _assert_admin(user_id: int):
    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute("SELECT role FROM users WHERE id = %s", (user_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()
 
    if not row or row[0] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
 
# ---------------------------------------------------------
# POST /api/admin/reassign  (manual reassignment)
# ---------------------------------------------------------
@router.post("/reassign", summary="Admin reassign email ownership")
def admin_reassign(req: ReassignRequest, request: Request):
    admin_id = _get_user_id(request)
    _assert_admin(admin_id)
 
    inbox_items = _read_jsonl(INBOX_PATH)
    inbox_item = next(
        (it for it in inbox_items if str(it.get("id")) == str(req.email_id)),
        None
    )
 
    if not inbox_item:
        raise HTTPException(status_code=404, detail="Email not found")
 
    old_user = inbox_item.get("assigned_to")
    now = int(time.time())
 
    try:
        conn = get_db_conn()
        cur = conn.cursor()
 
        cur.execute("""
            UPDATE email_records
            SET assigned_to = %s,
                reassigned_count = COALESCE(reassigned_count, 0) + 1
            WHERE id = %s
        """, (req.new_user_id, req.email_id))
 
        cur.execute("""
            INSERT INTO email_assignment_log
            (email_id, old_user_id, new_user_id, reason, changed_at)
            VALUES (%s, %s, %s, %s, NOW())
        """, (
            req.email_id,
            old_user,
            req.new_user_id,
            req.reason
        ))
 
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"DB update failed: {e}")
    finally:
        cur.close()
        conn.close()
 
    for it in inbox_items:
        if str(it.get("id")) == str(req.email_id):
            it["assigned_to"] = req.new_user_id
            it["assigned_at"] = now
            it.setdefault("metadata", {})
            it["metadata"]["admin_reassign_reason"] = req.reason
            it["metadata"]["admin_reassigned_at"] = now
            break
 
    _write_jsonl(INBOX_PATH, inbox_items)
 
    return {
        "status": "ok",
        "email_id": req.email_id,
        "old_user": old_user,
        "new_user": req.new_user_id
    }
 
# ---------------------------------------------------------
# PUT /api/admin/users/{user_id}/deactivate
# ---------------------------------------------------------
@router.put("/users/{user_id}/deactivate",
            summary="Deactivate employee and redistribute emails")
def deactivate_user(user_id: int, request: Request):
    admin_id = _get_user_id(request)
    _assert_admin(admin_id)
 
    inbox_items = _read_jsonl(INBOX_PATH)
    now = int(time.time())
 
    try:
        conn = get_db_conn()
        cur = conn.cursor()
 
        # ---- Validate employee ----
        cur.execute("""
            SELECT id, is_active
            FROM users
            WHERE id = %s AND role = 'employee'
        """, (user_id,))
        row = cur.fetchone()
 
        if not row:
            raise HTTPException(status_code=404, detail="Employee not found")
 
        if row[1] is False:
            return {"status": "ok", "message": "User already inactive"}
 
        # ---- Ensure at least one other active employee ----
        cur.execute("""
            SELECT COUNT(*) FROM users
            WHERE role = 'employee'
            AND is_active = true
            AND id != %s
        """, (user_id,))
        if cur.fetchone()[0] == 0:
            raise HTTPException(
                status_code=400,
                detail="Cannot deactivate the last active employee"
            )
 
        # ---- Fetch ALL open / pending emails ----
        cur.execute("""
            SELECT id FROM email_records
            WHERE assigned_to = %s
            AND status IN ('open', 'pending', 'pending_approval')
        """, (user_id,))
        email_ids = [r[0] for r in cur.fetchall()]
 
        redistributed = 0
 
        for email_id in email_ids:
            new_user = get_next_employee_id(exclude_user_id=user_id)
 
            cur.execute("""
                UPDATE email_records
                SET assigned_to = %s,
                    assigned_at = NOW(),
                    sla_deadline = NOW() + INTERVAL '60 minutes',
                    reassigned_count = COALESCE(reassigned_count, 0) + 1
                WHERE id = %s
            """, (new_user, email_id))
 
            for it in inbox_items:
                if str(it.get("id")) == str(email_id):
                    it["assigned_to"] = new_user
                    it["assigned_at"] = now
                    it.setdefault("metadata", {})
                    it["metadata"]["auto_redistributed"] = True
                    it["metadata"]["previous_owner"] = user_id
                    break
 
            redistributed += 1
 
        # ---- Deactivate user ----
        cur.execute(
            "UPDATE users SET is_active = false WHERE id = %s",
            (user_id,)
        )
 
        conn.commit()
 
    except HTTPException:
        conn.rollback()
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()
 
    _write_jsonl(INBOX_PATH, inbox_items)
 
    return {
        "status": "ok",
        "user_id": user_id,
        "emails_redistributed": redistributed
    }