import os
import json
import sys
from dotenv import load_dotenv
 
# required libs
try:
    import numpy as np
except Exception as e:
    raise RuntimeError("Missing dependency 'numpy'. Install: pip install numpy") from e
 
try:
    import faiss
except Exception as e:
    raise RuntimeError("Missing dependency 'faiss'. Install: pip install faiss-cpu") from e
 
# optional: python openai client
_try_openai_import = None
try:
    import openai as _openai_pkg
    _try_openai_import = ("python", _openai_pkg)
except Exception:
    _try_openai_import = None
 
# requests fallback
try:
    import requests
except Exception as e:
    raise RuntimeError("Missing dependency 'requests'. Install: pip install requests") from e
 
# ✅ DATABASE ACCESS
from sqlalchemy.orm import Session
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import SessionLocal
from models.template import Template
 
# -------------------------
# CONFIG
# -------------------------
load_dotenv()
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INDEX_PATH = os.path.join(BASE_DIR, "faiss_index", "index.faiss")
META_PATH = os.path.join(BASE_DIR, "faiss_index", "kb_metadata.json")
 
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")
CHAT_MODEL = os.getenv("CHAT_MODEL", "gpt-5")
TOP_K = int(os.getenv("TOP_K", 6))
MAX_PROMPT_EVIDENCE_TOKENS = int(os.getenv("MAX_PROMPT_EVIDENCE_TOKENS", 1800))
OPENAI_KEY_ENV = os.getenv("OPENAI_KEY_ENV", "OPENAI_API_KEY")
 
OPENAI_KEY = os.getenv(OPENAI_KEY_ENV)
if not OPENAI_KEY:
    raise RuntimeError(f"Set {OPENAI_KEY_ENV} in your backend/.env before running.")
 
# ------------ Clients ------------
_openai_client = None
_openai_mode = None
 
if _try_openai_import:
    _pkg = _try_openai_import[1]
    try:
        from openai import OpenAI as _OpenAIClient
        try:
            _client = _OpenAIClient(api_key=OPENAI_KEY)
            _openai_client = _client
            _openai_mode = "new_client"
        except Exception:
            _openai_client = None
    except Exception:
        try:
            _pkg.api_key = OPENAI_KEY
            _openai_client = _pkg
            _openai_mode = "v1_module"
        except Exception:
            _openai_client = None
 
_OPENAI_API_BASE = "https://api.openai.com/v1"
 
# -------------------------
# Helpers
# -------------------------
def _rest_embeddings(input_text):
    url = f"{_OPENAI_API_BASE}/embeddings"
    headers = {"Authorization": f"Bearer {OPENAI_KEY}", "Content-Type": "application/json"}
    payload = {"model": EMBEDDING_MODEL, "input": input_text}
    r = requests.post(url, headers=headers, json=payload, timeout=60)
    if r.status_code != 200: raise RuntimeError(f"Embeddings error: {r.text}")
    data = r.json().get("data", [])
    if not data: raise RuntimeError("No embedding data returned.")
    return data
 
def _rest_chat_completion(messages, model=CHAT_MODEL, temperature=0.1, max_tokens=400):
    url = f"{_OPENAI_API_BASE}/chat/completions"
    headers = {"Authorization": f"Bearer {OPENAI_KEY}", "Content-Type": "application/json"}
    payload = {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
    r = requests.post(url, headers=headers, json=payload, timeout=120)
    if r.status_code != 200: raise RuntimeError(f"Chat error: {r.text}")
    j = r.json()
    if "choices" in j and len(j["choices"]) > 0:
        return j["choices"][0].get("message", {}).get("content", "") or j["choices"][0].get("text", "")
    raise RuntimeError("Could not parse chat response.")
 
def _call_embeddings_single(input_text):
    if _openai_client and _openai_mode == "new_client":
        try: return _openai_client.embeddings.create(model=EMBEDDING_MODEL, input=input_text)
        except Exception: pass
    if _openai_client and _openai_mode == "v1_module":
        try:
            pkg = _openai_client
            if hasattr(pkg, "embeddings"): return pkg.embeddings.create(model=EMBEDDING_MODEL, input=input_text)
        except Exception: pass
    return {"data": _rest_embeddings(input_text)}
 
def get_embedding_single(text):
    inp = text.replace("\n", " ")[:2000]
    resp = _call_embeddings_single(inp)
    data = resp.get("data", []) if isinstance(resp, dict) else getattr(resp, "data", [])
    if not data: raise RuntimeError("No embedding data.")
    item = data[0]
    emb = item.get("embedding") if isinstance(item, dict) else getattr(item, "embedding", None)
    return np.array(emb).astype("float32")
 
def _call_chat_completion(messages, model=CHAT_MODEL, temperature=0.1, max_tokens=400):
    if _openai_client and _openai_mode == "new_client":
        try:
            resp = _openai_client.chat.completions.create(model=model, messages=messages, temperature=temperature, max_tokens=max_tokens)
            return resp.choices[0].message.content
        except Exception: pass
    return _rest_chat_completion(messages, model=model, temperature=temperature, max_tokens=max_tokens)
 
def load_index_and_meta(index_path=INDEX_PATH, meta_path=META_PATH):
    if not os.path.exists(index_path) or not os.path.exists(meta_path): raise RuntimeError("Index not found.")
    return faiss.read_index(index_path), json.load(open(meta_path, "r", encoding="utf8"))
 
def search_index(index, metadata, query_emb, top_k=TOP_K):
    q = np.array([query_emb]).astype("float32")
    faiss.normalize_L2(q)
    D, I = index.search(q, top_k)
    results = []
    for score, idx in zip(D[0], I[0]):
        if idx < 0 or idx >= len(metadata): continue
        results.append({**metadata[idx], "score": float(score)})
    return results
 
# -------------------------
# Template & Prompt Logic
# -------------------------
 
def get_template_for_category(category: str):
    if not category: return None
    db = SessionLocal()
    try:
        # 1. Exact match
        t = db.query(Template).filter(Template.category.ilike(category), Template.status == "Active").first()
        # 2. Partial match
        if not t: t = db.query(Template).filter(Template.category.ilike(f"%{category}%"), Template.status == "Active").first()
        return t
    except Exception as e:
        print(f"Error fetching template: {e}")
        return None
    finally:
        db.close()
 
def detect_language(text: str) -> str:
    if not text: return "en"
    jp_chars = sum(1 for char in text if "\u3040" <= char <= "\u9FFF")
    return "ja" if len(text) > 0 and jp_chars / len(text) > 0.1 else "en"
 
def _infer_category_from_text(text: str) -> str:
    t = (text or "").lower()
    if any(k in t for k in ["return", "refund", "cancel"]): return "Returns"
    if any(k in t for k in ["invoice", "billing", "payment"]): return "Billing"
    if any(k in t for k in ["error", "broken", "screen", "wifi", "laptop", "computer", "not working"]): return "Technical"
    if any(k in t for k in ["price", "buy", "quote"]): return "Sales"
    return "Support"
 
# ✅ UPDATED SYSTEM INSTRUCTIONS (Neutral - No hardcoded signature)
SYSTEM_INSTRUCTIONS = """
You are a professional customer support assistant for Dospara Corp.
 
Write replies in clean Markdown.
 
Formatting rules:
- Every step MUST be written on two lines:
  Title␠␠
  Explanation
- NEVER leave a blank line between a title and its explanation
- Leave ONE blank line after each explanation
- Use `---` before the Next Steps section
- Use Next Steps as a bold heading
- Do NOT use bullet points or numbered lists
"""
 
 
 
 
 
 
# ✅ UPDATED ASSEMBLE PROMPT
def assemble_prompt(email_text, retrieved, category_hint=None, request_instructions=None):
    category = (category_hint or "").strip() or _infer_category_from_text(email_text)
   
    # Try finding specific template -> Fallback to "Support" -> Fallback to None
    db_template = get_template_for_category(category)
    if not db_template and category != "Support":
        print(f"⚠️ No template for '{category}'. Checking 'Support'.")
        db_template = get_template_for_category("Support")
 
    prompt_guidance = ""
   
   # 1. IF TEMPLATE EXISTS: Enforce it strictly
    if db_template:
        print(f"✅ Using Template: {db_template.name}")
        prompt_guidance = f"""
        IMPORTANT: The user has a STRICT template for this email.
        - You MUST use the content structure below.
        - The template contains a Subject line and the Email Body.
        - Output the final email clearly.
        - Use the specific signature provided in the template.
 
        --- TEMPLATE STRUCTURE ---
        Subject: {db_template.subject}
       
        {db_template.body}
        --- END TEMPLATE ---
       
        Task: Fill in the [AI will insert...] section with specific troubleshooting steps based on the evidence. Replace {{name}} and {{order_id}}.
        """
    # 2. NO TEMPLATE: Use default personality
    else:
        print(f"⚠️ Using Default AI Fallback (No Template)")
        prompt_guidance = f"""
        No template provided. Please draft a professional reply.
        - Tone: {category} (Professional & Helpful).
        - Structure: Greeting -> Answer -> Next Steps -> Signature.
        - Signature:
            Best regards,
            Adnan Khan
            Dospara Corp Customer Support
        - Always include a "Next steps" section.
        """
 
    # Evidence String
    evidence_text = "\n\n".join([f"Evidence: {r['text']}" for r in retrieved]) or "No evidence."
 
    user_text = f"""
    Customer Email:
    {email_text}
 
    Knowledge Base:
    {evidence_text}
 
    Instructions:
    {prompt_guidance}
 
    {request_instructions or ""}
   
        Task: Write the final email reply using this exact structure:
 
        Greeting
 
        One short sentence acknowledging the customer's issue.
 
        Then write:
        "To address this, please try:"
 
        Then a numbered list in this exact Markdown format:
 
        1. **Step name**
        One sentence explanation
 
        2. **Step name**
        One sentence explanation
 
        3. **Step name**
        One sentence explanation
 
        Then write:
 
        ---
        **Next Steps**
        One or two follow-up instructions for the customer.
 
        Then end with:
 
        Best regards,  
        **Adnan Khan**  
        Dospara Corp Customer Support
 
        """
 
    return [
        {"role": "system", "content": SYSTEM_INSTRUCTIONS},
        {"role": "user", "content": user_text}
    ]
 
# -------------------------
# Main Pipeline
# -------------------------
def generate_reply_for_email(email_text, sender_name=None, top_k=TOP_K, temperature=0.08, category_hint=None, request_instructions=None, language=None):
    if language is None: language = detect_language(email_text)
    index, metadata = load_index_and_meta()
    emb = get_embedding_single(email_text)
    retrieved = search_index(index, metadata, emb, top_k=top_k)
 
    # Note: Greeting is appended here. If your template has 'Dear {{name}}',
    # the AI usually handles the duplicate gracefully, or we can remove this if template handles it.
    greeting = f"{sender_name}様へ" if language == "ja" else (f"Dear {sender_name}," if sender_name else "Dear Customer,")
   
    # Pass 'greeting_instr' separately so we don't break the logic above
    greeting_instr = f"\nStart with: {greeting}"
 
    messages = assemble_prompt(
        email_text,
        retrieved,
        category_hint=category_hint,
        request_instructions=(request_instructions or "") + greeting_instr
    )
   
    reply = _call_chat_completion(messages, model=CHAT_MODEL, temperature=temperature, max_tokens=500)
    return {"reply": reply, "retrieved": retrieved, "messages": messages, "language": language}
 
if __name__ == "__main__":
    email_text = sys.argv[1] if len(sys.argv) >= 2 else input("Email text:\n")
    print(f"Detected Category: {_infer_category_from_text(email_text)}")
    out = generate_reply_for_email(email_text, top_k=TOP_K)
    print("\n---- REPLY ----\n")
    print(out["reply"])
# -------------------------
# CLI Runner
# -------------------------
if __name__ == "__main__":
    if len(sys.argv) >= 2:
        email_text = sys.argv[1]
    else:
        email_text = input("Email text:\n")
   
    # Test category inference
    cat = _infer_category_from_text(email_text)
    print(f"Detected Category: {cat}")
   
    out = generate_reply_for_email(email_text, top_k=TOP_K)
    print("\n---- REPLY ----\n")
    print(out["reply"])