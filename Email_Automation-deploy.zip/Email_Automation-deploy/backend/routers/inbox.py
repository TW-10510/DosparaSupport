from fastapi import APIRouter, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel
from typing import Optional, Tuple

from database import SessionLocal
from models.email_record import EmailRecord

router = APIRouter()

# -------------------------------------------------
# Auth helper
# -------------------------------------------------
def _get_user_id(request: Request) -> int:
    uid = request.headers.get("X-User-Id")
    if not uid or uid == "null":
        raise HTTPException(status_code=401, detail="Missing X-User-Id")
    try:
        return int(uid)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid X-User-Id")


# -------------------------------------------------
# Email body splitter (reply vs quoted)
# -------------------------------------------------
def split_email_body(body: str) -> Tuple[str, Optional[str]]:
    if not body:
        return "", None

    markers = [
        "\nFrom:",
        "\nSent:",
        "\nOn ",
        "\n-----Original Message-----",
        "\n________________________________",
    ]

    for m in markers:
        idx = body.find(m)
        if idx != -1:
            return body[:idx].strip(), body[idx:].strip()

    return body.strip(), None


# -------------------------------------------------
# GET inbox (latest email per thread)
# Shows response from draft_reply if exists
# -------------------------------------------------
@router.get("/")
def list_inbox(request: Request):
    user_id = _get_user_id(request)
    db: Session = SessionLocal()

    try:
        subquery = (
            db.query(
                EmailRecord.thread_id,
                func.max(EmailRecord.created_at).label("latest_created_at")
            )
            .filter(
                (EmailRecord.assigned_to == user_id) |
                (EmailRecord.handled_by == user_id)
            )
            .group_by(EmailRecord.thread_id)
            .subquery()
        )

        records = (
            db.query(EmailRecord)
            .join(
                subquery,
                (EmailRecord.thread_id == subquery.c.thread_id) &
                (EmailRecord.created_at == subquery.c.latest_created_at)
            )
            .order_by(EmailRecord.created_at.desc())
            .all()
        )

        emails = []
        for e in records:
            reply_body, _ = split_email_body(e.body or "")

            # ✅ Prefer response if exists
            display_body = e.draft_reply.strip() if e.draft_reply else reply_body

            emails.append({
                "id": e.id,
                "thread_id": e.thread_id,
                "subject": e.subject,
                "preview": display_body[:120],
                "content": display_body,
                "sender_email": e.recipient_email,
                "sender_name": (
                    e.recipient_email.split("@")[0]
                    if e.recipient_email else "Customer"
                ),
                "assigned_to": e.assigned_to,
                "status": e.status,
                "received_at": int(e.created_at.timestamp()),
                "draft_reply": e.draft_reply,
                "language": e.language,
                "has_response": bool(e.draft_reply),
            })

        return {"emails": emails}

    finally:
        db.close()


# -------------------------------------------------
# GET FULL THREAD HISTORY
# Includes client mail + agent response (draft_reply)
# -------------------------------------------------
@router.get("/thread/{email_id}")
def get_thread(email_id: int, request: Request):
    user_id = _get_user_id(request)
    db: Session = SessionLocal()

    try:
        base_email = (
            db.query(EmailRecord)
            .filter(EmailRecord.id == email_id)
            .first()
        )

        if not base_email:
            raise HTTPException(status_code=404, detail="Email not found")

        if not base_email.thread_id:
            raise HTTPException(status_code=400, detail="Email has no thread")

        records = (
            db.query(EmailRecord)
            .filter(
                EmailRecord.thread_id == base_email.thread_id,
                (EmailRecord.assigned_to == user_id) |
                (EmailRecord.handled_by == user_id)
            )
            .order_by(EmailRecord.created_at.asc())
            .all()
        )

        messages = []
        for e in records:
            reply_body, quoted_body = split_email_body(e.body or "")

            # ---------------- RECEIVED ----------------
            messages.append({
                "id": e.id,
                "thread_id": e.thread_id,
                "type": "received",
                "sender_email": e.recipient_email,
                "sender_name": (
                    e.recipient_email.split("@")[0]
                    if e.recipient_email else "Customer"
                ),
                "subject": e.subject,
                "reply_body": reply_body,
                "quoted_body": quoted_body,
                "timestamp": int(e.created_at.timestamp()),
            })

            # ---------------- SENT (RESPONSE) ----------------
            if e.draft_reply:
                messages.append({
                    "id": f"draft-{e.id}",
                    "thread_id": e.thread_id,
                    "type": "sent",
                    "sender_email": "d_sriram@twave.co.jp",
                    "sender_name": "You",
                    "subject": f"Re: {e.subject}",
                    "reply_body": e.draft_reply,
                    "quoted_body": None,
                    "timestamp": int(
                        (e.sent_at or e.created_at).timestamp()
                    ),
                })

        return {"messages": messages}

    finally:
        db.close()


# -------------------------------------------------
# UPDATE inbox item (status / draft reply)
# -------------------------------------------------
class InboxUpdate(BaseModel):
    status: Optional[str] = None
    draft_reply: Optional[str] = None


@router.put("/{email_id}")
def update_inbox_item(
    email_id: int,
    payload: InboxUpdate,
    request: Request
):
    user_id = _get_user_id(request)
    db: Session = SessionLocal()

    try:
        email = (
            db.query(EmailRecord)
            .filter(EmailRecord.id == email_id)
            .first()
        )

        if not email:
            raise HTTPException(status_code=404, detail="Email not found")

        if email.assigned_to != user_id:
            raise HTTPException(status_code=403, detail="Not allowed")

        if payload.status is not None:
            email.status = payload.status

        if payload.draft_reply is not None:
            email.draft_reply = payload.draft_reply

        db.commit()
        return {"status": "ok", "email_id": email_id}

    finally:
        db.close()
