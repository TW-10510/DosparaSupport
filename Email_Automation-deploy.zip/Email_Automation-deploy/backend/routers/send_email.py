# backend/routers/send_email.py

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import os
import json
import time
import psycopg2

from services.outlook_graph_client import (
    reply_to_message_strict,
    get_message_metadata
)

router = APIRouter()

DATABASE_URL = os.getenv("DATABASE_URL")

OUTBOX_DIR = os.path.join(os.path.dirname(__file__), "..", "outbox")
OUTBOX_FILE = os.path.join(OUTBOX_DIR, "sent_emails.jsonl")
os.makedirs(OUTBOX_DIR, exist_ok=True)

# ✅ NEW: inbox path (NON-BREAKING)
DATA_DIR = os.getenv("DATA_DIR", "email_automation_dataset")
INBOX_PATH = os.path.join(DATA_DIR, "inbox.jsonl")


class SendEmailRequest(BaseModel):
    message_id: str
    body: str
    language: Optional[str] = None  # "en" or "ja"


def get_db_conn():
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL is not set")
    return psycopg2.connect(DATABASE_URL)


# ✅ NEW: helpers (ADDITIVE)
def _read_jsonl(path):
    items = []
    if not os.path.exists(path):
        return items
    with open(path, "r", encoding="utf8") as f:
        for line in f:
            if line.strip():
                try:
                    items.append(json.loads(line))
                except:
                    continue
    return items


def _write_jsonl(path, items):
    with open(path, "w", encoding="utf8") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")


def _get_user_id(request: Request):
    uid = request.headers.get("X-User-Id")
    if not uid:
        raise HTTPException(status_code=401, detail="Missing user")
    return int(uid)


@router.post("/", status_code=200)
def send_email(req: SendEmailRequest, request: Request):
    user_id = _get_user_id(request)

    # -------------------------------------------------
    # ✅ 0️⃣ Ownership & status validation (ADDED)
    # -------------------------------------------------
    inbox_items = _read_jsonl(INBOX_PATH)
    draft = next((it for it in inbox_items if str(it.get("id")) == str(req.message_id)), None)

    if not draft:
        raise HTTPException(status_code=404, detail="Email not found in inbox")

    if draft.get("assigned_to") != user_id:
        raise HTTPException(status_code=403, detail="You are not the owner of this email")

    if draft.get("status") == "sent":
        raise HTTPException(status_code=400, detail="Email already sent")

    # -------------------------------------------------
    # 1️⃣ Send reply via Outlook Graph
    # -------------------------------------------------
    try:
        reply_id = reply_to_message_strict(
            message_id=req.message_id,
            body=req.body
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Graph send failed: {e}"
        )

    # -------------------------------------------------
    # 2️⃣ Fetch metadata (to + subject)
    # -------------------------------------------------
    try:
        to_email, subject = get_message_metadata(req.message_id)
    except Exception:
        to_email, subject = "unknown", "(reply)"

    # -------------------------------------------------
    # 3️⃣ Store in Postgres
    # -------------------------------------------------
    try:
        conn = get_db_conn()
        cur = conn.cursor()

        cur.execute(
            """
            INSERT INTO email_records
            (created_at, recipient_email, subject, body, gmail_msg_id)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (
                datetime.utcnow(),
                to_email or "unknown",
                subject or "(reply)",
                req.body,
                reply_id
            )
        )

        conn.commit()
        cur.close()
        conn.close()

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"DB insert failed: {e}"
        )

    # -------------------------------------------------
    # ✅ 3.5️⃣ Update inbox status (ADDED)
    # -------------------------------------------------
    now = int(time.time())
    for it in inbox_items:
        if str(it.get("id")) == str(req.message_id):
            it["status"] = "sent"
            it["sent_at"] = now
            it["sent_at_iso"] = datetime.utcfromtimestamp(now).isoformat()
            break

    _write_jsonl(INBOX_PATH, inbox_items)

    # -------------------------------------------------
    # 4️⃣ Store in JSONL outbox
    # -------------------------------------------------
    record = {
        "timestamp": now,
        "to": to_email or "unknown",
        "subject": subject or "(reply)",
        "body": req.body,
        "message_id": reply_id,
        "language": req.language or "en"
    }

    try:
        with open(OUTBOX_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception as e:
        print("⚠️ Outbox JSON write failed:", e)

    return {
        "status": "sent",
        "reply_id": reply_id
    }