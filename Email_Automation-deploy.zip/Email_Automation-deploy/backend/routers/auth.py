from fastapi import APIRouter, HTTPException, Header, Depends
from pydantic import BaseModel, EmailStr
from typing import Optional, List
import psycopg2
from psycopg2.extras import RealDictCursor
from sqlalchemy import text
import os
import hashlib
import secrets
from dotenv import load_dotenv
from database import SessionLocal

load_dotenv()

# Prefix matches your frontend calls: /api/auth/login, /api/roles, etc.
router = APIRouter(prefix="/api", tags=["auth"])

ITERATIONS = 310_000

# ------------------- Helpers -------------------
def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    pwd_hash = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode(),
        salt.encode(),
        ITERATIONS
    )
    return f"pbkdf2_sha256${ITERATIONS}${salt}${pwd_hash.hex()}"

def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algo, iterations, salt, hash_hex = stored_hash.split("$")
        new_hash = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode(),
            salt.encode(),
            int(iterations)
        ).hex()
        return new_hash == hash_hex
    except Exception:
        return False

def get_db_connection():
    return psycopg2.connect(os.getenv("DATABASE_URL"))

# ------------------- Schemas -------------------
class RegisterRequest(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    password: str
    confirm_password: str
    role: str

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class LogoutRequest(BaseModel):
    user_id: int

class UserUpdateRequest(BaseModel):
    role: str
    is_active: bool

class RoleCreateRequest(BaseModel):
    name: str
    description: str
    level: str
    status: str

class RoleUpdateRequest(BaseModel):
    description: Optional[str] = None
    status: Optional[str] = None

# ------------------- Auth Dependency -------------------
def get_current_user(required_permission: Optional[str] = None):
    def _dependency(x_user_id: int = Header(..., alias="X-User-Id")):
        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        try:
            cur.execute(
                """
                SELECT id, first_name, last_name, email, role, is_active
                FROM users
                WHERE id = %s
                """,
                (x_user_id,),
            )
            user = cur.fetchone()
            if not user or not user["is_active"]:
                raise HTTPException(status_code=401, detail="Invalid or inactive user")

            # Super Admins bypass permission checks
            if user["role"].lower() == "super admin":
                return user

            if required_permission:
                cur.execute(
                    """
                    SELECT 1
                    FROM roles r
                    JOIN role_permissions rp ON rp.role_id = r.id
                    JOIN permissions p ON p.id = rp.permission_id
                    WHERE LOWER(r.name) = LOWER(%s)
                      AND p.name = %s
                    LIMIT 1
                    """,
                    (user["role"], required_permission),
                )
                if not cur.fetchone():
                    raise HTTPException(status_code=403, detail="Insufficient permissions")

            return user
        finally:
            conn.close()

    return _dependency

# ==================================================================
# AUTH ROUTES (Login/Register)
# ==================================================================

@router.post("/auth/register")
def register_user(payload: RegisterRequest):
    if payload.password != payload.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    conn = get_db_connection()
    cur = conn.cursor()

    # Check existing users
    cur.execute("SELECT id FROM users WHERE email = %s", (payload.email,))
    if cur.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Email already registered")

    cur.execute("SELECT id FROM pending_users WHERE email = %s", (payload.email,))
    if cur.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Email already pending approval")

    password_hash = hash_password(payload.password)

    cur.execute(
        """
        INSERT INTO pending_users (first_name, last_name, email, password_hash, role)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (payload.first_name, payload.last_name, payload.email, password_hash, payload.role,)
    )
    conn.commit()
    conn.close()

    return {"message": "Registration submitted. Waiting for admin approval."}

# ✅ UPDATED LOGIN FUNCTION
@router.post("/auth/login")
def login_user(payload: LoginRequest):
    conn = get_db_connection()
    cur = conn.cursor()
    
    # 1. Fetch User Data
    cur.execute(
        """
        SELECT u.id, u.first_name, u.last_name, u.password_hash, u.role, u.is_active, r.status
        FROM users u
        LEFT JOIN roles r ON LOWER(r.name) = LOWER(u.role)
        WHERE u.email = %s
        """,
        (payload.email,),
    )
    user = cur.fetchone()
    
    if not user:
        conn.close()
        raise HTTPException(status_code=401, detail="Invalid credentials")

    user_id, first_name, last_name, password_hash, role, is_active, role_status = user

    # 2. Validation Checks
    if not is_active:
        conn.close()
        raise HTTPException(status_code=403, detail="Account disabled")
    if role_status and role_status.lower() == "inactive":
        conn.close()
        raise HTTPException(status_code=403, detail="Role disabled")
    if not verify_password(payload.password, password_hash):
        conn.close()
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # 3. Update Online Status
    cur.execute("UPDATE users SET is_online = TRUE WHERE id = %s", (user_id,))
    conn.commit()

    # ✅ 4. FETCH PERMISSIONS LIST
    permissions = []
    if role.lower() == "super admin":
        # Super Admin gets ALL permissions
        cur.execute("SELECT name FROM permissions")
        permissions = [row[0] for row in cur.fetchall()]
    else:
        # Fetch assigned permissions for role
        cur.execute(
            """
            SELECT p.name 
            FROM permissions p
            JOIN role_permissions rp ON p.id = rp.permission_id
            JOIN roles r ON rp.role_id = r.id
            WHERE LOWER(r.name) = LOWER(%s)
            """,
            (role,)
        )
        permissions = [row[0] for row in cur.fetchall()]

    conn.close()

    # 5. Return Response with Permissions
    return {
        "message": "Login successful",
        "token": "fake-jwt-token", # Replace with real token logic if you have it
        "user_id": user_id,
        "first_name": first_name,
        "last_name": last_name,
        "role": role,
        "permissions": permissions # <--- SENT TO FRONTEND
    }

@router.post("/auth/logout")
def logout_user(payload: LogoutRequest):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE users SET is_online = FALSE WHERE id = %s", (payload.user_id,))
    conn.commit()
    conn.close()
    return {"message": "Logged out successfully"}

# ==================================================================
# ROLE MANAGEMENT ROUTES
# ==================================================================

@router.get("/roles")
def get_roles():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        query = """
            SELECT 
                r.id, r.name, r.description, r.level, r.status, 
                TO_CHAR(r.created_at, 'YYYY-MM-DD') as "createdAt",
                (SELECT COUNT(*) FROM users u WHERE LOWER(u.role) = LOWER(r.name)) as "usersCount"
            FROM roles r
            ORDER BY r.id;
        """
        cur.execute(query)
        return cur.fetchall()
    finally:
        conn.close()

@router.post("/roles")
def create_role(payload: RoleCreateRequest):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        query = """
            INSERT INTO roles (name, description, level, status) 
            VALUES (%s, %s, %s, %s) 
            RETURNING id, name, description, level, status, 
            TO_CHAR(created_at, 'YYYY-MM-DD') as "createdAt"
        """
        cur.execute(query, (payload.name, payload.description, payload.level, payload.status))
        new_role = cur.fetchone()
        conn.commit()
        new_role['usersCount'] = 0
        return new_role
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        conn.close()

@router.put("/roles/{role_id}")
def update_role(role_id: int, payload: RoleUpdateRequest):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        fields = []
        values = []
        if payload.description:
            fields.append("description = %s")
            values.append(payload.description)
        if payload.status:
            fields.append("status = %s")
            values.append(payload.status)
        
        if not fields:
            raise HTTPException(status_code=400, detail="No fields")

        values.append(role_id)
        cur.execute(f"UPDATE roles SET {', '.join(fields)} WHERE id = %s", values)
        conn.commit()
        return {"message": "Role updated"}
    finally:
        conn.close()

@router.delete("/roles/{role_id}")
def delete_role(role_id: int):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("DELETE FROM roles WHERE id = %s", (role_id,))
        conn.commit()
        return {"message": "Role deleted"}
    finally:
        conn.close()

# ==================================================================
# PERMISSION ROUTES
# ==================================================================

@router.get("/permissions")
def get_permissions():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        query = """
            SELECT 
                p.id, p.name, p.description, p.category, p.scope,
                TO_CHAR(p.created_at, 'YYYY-MM-DD') as "createdAt",
                COALESCE(ARRAY_AGG(r.name) FILTER (WHERE r.name IS NOT NULL), '{}') as "assignedRoles"
            FROM permissions p
            LEFT JOIN role_permissions rp ON p.id = rp.permission_id
            LEFT JOIN roles r ON rp.role_id = r.id
            GROUP BY p.id
            ORDER BY p.id;
        """
        cur.execute(query)
        return cur.fetchall()
    finally:
        conn.close()

@router.post("/roles/{role_id}/permissions/{permission_id}")
def assign_permission_to_role(
    role_id: int, 
    permission_id: int, 
    current_user: dict = Depends(get_current_user())
):
    user_role = current_user.get("role", "").lower()
    print(f"DEBUG: Requesting User Role: '{user_role}'")
    print(f"DEBUG: Target Role ID: {role_id}")
    allowed_roles = ["super admin", "admin", "administrator"]
    if current_user.get("role", "").lower() not in allowed_roles:
        print(f"FAILED: User role '{current_user.get('role')}' is not in allowed list.")
        raise HTTPException(status_code=403, detail="Not authorized")
    
    db = SessionLocal()
    try:
        if role_id == 1 and user_role != "super admin":
            print("BLOCKED: Attempt to modify Super Admin")
            raise HTTPException(status_code=403, detail="Only Super Admins can modify the Super Admin role.")

        db.execute(text("INSERT INTO role_permissions (role_id, permission_id) VALUES (:rid, :pid) ON CONFLICT DO NOTHING"), 
                   {"rid": role_id, "pid": permission_id})
        db.commit()
        return {"message": "Permission assigned"}
    finally:
        db.close()


# ✅ 2. UPDATE REVOKE PERMISSION (DELETE)
@router.delete("/roles/{role_id}/permissions/{permission_id}")
def revoke_permission_from_role(
    role_id: int, 
    permission_id: int, 
    current_user: dict = Depends(get_current_user())
):
    user_role = current_user.get("role", "").lower()
    print(f"DEBUG: Requesting User Role: '{user_role}'")
    print(f"DEBUG: Target Role ID: {role_id}")
    allowed_roles = ["super admin", "admin", "administrator"]
    if current_user.get("role", "").lower() not in allowed_roles:
        print(f"FAILED: User role '{current_user.get('role')}' is not in allowed list.")
        raise HTTPException(status_code=403, detail="Not authorized")
    
    db = SessionLocal()
    try:
        if role_id == 1 and user_role != "super admin":
            print("BLOCKED: Attempt to modify Super Admin")
            raise HTTPException(status_code=403, detail="Only Super Admins can modify the Super Admin role.")

        db.execute(text("DELETE FROM role_permissions WHERE role_id = :rid AND permission_id = :pid"), 
                   {"rid": role_id, "pid": permission_id})
        db.commit()
        return {"message": "Permission revoked"}
    finally:
        db.close()

# Include other existing routes (users, pending, emails, sent, stats, dashboard)...
# (The rest of your file remains unchanged, ensure you keep get_all_users, etc.)


# ==================================================================
# AUTH & USER ROUTES (/api/auth/...)
# ==================================================================

@router.post("/auth/register")
def register_user(payload: RegisterRequest):
    if payload.password != payload.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    # ❌ FIX: Removed restriction so new dynamic roles (Viewer, Editor) work
    # if payload.role not in ("employee", "customer", "admin"):
    #    raise HTTPException(status_code=400, detail="Invalid role")

    conn = get_db_connection()
    cur = conn.cursor()

    # 🔒 Check users table
    cur.execute("SELECT id FROM users WHERE email = %s", (payload.email,))
    if cur.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Email already registered")

    # 🔒 Check pending_users table
    cur.execute("SELECT id FROM pending_users WHERE email = %s", (payload.email,))
    if cur.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Email already pending approval")

    password_hash = hash_password(payload.password)

    # ✅ INSERT INTO pending_users ONLY
    cur.execute(
        """
        INSERT INTO pending_users (
            first_name,
            last_name,
            email,
            password_hash,
            role
        )
        VALUES (%s, %s, %s, %s, %s)
        """,
        (
            payload.first_name,
            payload.last_name,
            payload.email,
            password_hash,
            payload.role,
        )
    )

    conn.commit()
    conn.close()

    return {
        "message": "Registration submitted. Waiting for admin approval."
    }

@router.post("/auth/login")
def login_user(payload: LoginRequest):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT u.id, u.first_name, u.last_name, u.password_hash, u.role, u.is_active, r.status
        FROM users u
        LEFT JOIN roles r ON LOWER(r.name) = LOWER(u.role)
        WHERE u.email = %s
        """,
        (payload.email,),
    )
    user = cur.fetchone()
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    user_id, first_name, last_name, password_hash, role, is_active, role_status = user
    if not is_active:
        raise HTTPException(status_code=403, detail="Account disabled")
    if role_status and role_status.lower() == "inactive":
        raise HTTPException(status_code=403, detail="Account disabled")
    if not verify_password(payload.password, password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    cur.execute("UPDATE users SET is_online = TRUE WHERE id = %s", (user_id,))
    conn.commit()
    conn.close()

    return {
        "message": "Login successful",
        "user_id": user_id,
        "first_name": first_name,
        "last_name": last_name,
        "role": role,
    }

@router.post("/auth/logout")
def logout_user(payload: LogoutRequest):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE users SET is_online = FALSE WHERE id = %s", (payload.user_id,))
    conn.commit()
    conn.close()
    return {"message": "Logged out successfully"}

@router.get("/auth/users")
def get_all_users():
    conn = get_db_connection()
    cur = conn.cursor()
    
    # ✅ MODIFIED QUERY: Joins email_records to count emails per user
    query = """
        SELECT 
            u.id, 
            u.first_name, 
            u.last_name, 
            u.email, 
            u.role, 
            u.is_active, 
            u.is_online, 
            u.created_at,
            COUNT(e.id) as mails_count
        FROM users u
        LEFT JOIN email_records e ON u.id = e.handled_by
        GROUP BY u.id
        ORDER BY u.id
    """
    
    cur.execute(query)
    rows = cur.fetchall()
    conn.close()
    
    return {
        "users": [
            {
                "id": r[0],
                "first_name": r[1],
                "last_name": r[2],
                "email": r[3],
                "role": r[4],
                "is_active": r[5],
                "is_online": r[6],
                "created_at": r[7].strftime("%Y-%m-%d %H:%M:%S") if r[7] else None,
                "mails_count": r[8] # ✅ Added mapping for the count
            }
            for r in rows
        ]
    }

@router.delete("/auth/users/{user_id}")
def delete_user(user_id: int, x_user_id: int = Header(..., alias="X-User-Id")):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT role FROM users WHERE id = %s", (x_user_id,))
    requester = cur.fetchone()
    if not requester:
        conn.close()
        raise HTTPException(status_code=401, detail="Invalid requester")
    requester_role = requester[0]

    # Check if user exists
    cur.execute("SELECT id, role FROM users WHERE id = %s", (user_id,))
    target = cur.fetchone()
    if not target:
        conn.close()
        raise HTTPException(status_code=404, detail="User not found")

    target_role = target[1]
    if (
        target_role
        and target_role.lower() == "super admin"
        and requester_role.lower() != "super admin"
    ):
        conn.close()
        raise HTTPException(status_code=403, detail="Operation forbidden")
        
    # Proceed with deletion
    cur.execute("DELETE FROM users WHERE id = %s", (user_id,))
    conn.commit()
    conn.close()
    
    return {"message": "User deleted successfully"}

# ------------------- Pending Users -------------------

@router.get("/auth/pending")
def get_pending_users():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, first_name, last_name, email, role, created_at FROM pending_users ORDER BY created_at"
    )
    rows = cur.fetchall()
    conn.close()
    return {
        "pending_users": [
            {
                "id": r[0],
                "first_name": r[1],
                "last_name": r[2],
                "email": r[3],
                "role": r[4],
                "created_at": r[5].strftime("%Y-%m-%d %H:%M:%S") if r[5] else None,
            }
            for r in rows
        ]
    }

@router.post("/auth/approve/{pending_id}")
def approve_pending_user(pending_id: int):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute(
        "SELECT first_name, last_name, email, password_hash, role FROM pending_users WHERE id = %s",
        (pending_id,),
    )
    user = cur.fetchone()
    if not user:
        conn.close()
        raise HTTPException(status_code=404, detail="Pending user not found")

    first_name, last_name, email, password_hash, role = user

    cur.execute(
        """
        INSERT INTO users (first_name, last_name, email, password_hash, role, is_active, is_online)
        VALUES (%s, %s, %s, %s, %s, TRUE, FALSE)
        """,
        (first_name, last_name, email, password_hash, role)
    )

    cur.execute("DELETE FROM pending_users WHERE id = %s", (pending_id,))
    conn.commit()
    conn.close()

    return {"message": f"User {first_name} {last_name} approved successfully"}

# ---------------------------------------------------
# ✅ UPDATE USER (FIXED: Removed Role Checks)
# ---------------------------------------------------
@router.put("/auth/users/{user_id}")
def update_user(user_id: int, payload: UserUpdateRequest, x_user_id: int = Header(..., alias="X-User-Id")):
    # ❌ FIX: Removed restriction so "Viewer", "Editor", etc. are allowed
    # if payload.role not in ("admin", "employee"):
    #    raise HTTPException(status_code=400, detail="Invalid role")

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT role FROM users WHERE id = %s", (x_user_id,))
    requester = cur.fetchone()
    if not requester:
        conn.close()
        raise HTTPException(status_code=401, detail="Invalid requester")
    requester_role = requester[0]

    cur.execute("SELECT id, role FROM users WHERE id = %s", (user_id,))
    target = cur.fetchone()
    if not target:
        conn.close()
        raise HTTPException(status_code=404, detail="User not found")
    target_role = target[1]
    if (
        target_role
        and target_role.lower() == "super admin"
        and requester_role.lower() != "super admin"
    ):
        conn.close()
        raise HTTPException(status_code=403, detail="Operation forbidden")

    cur.execute(
        """
        UPDATE users
        SET role = %s,
            is_active = %s
        WHERE id = %s
        """,
        (payload.role, payload.is_active, user_id)
    )

    conn.commit()
    conn.close()

    return {"message": "User updated successfully"}


@router.put("/roles/{role_id}")
def update_role(role_id: int, payload: RoleUpdateRequest):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute("SELECT id FROM roles WHERE id = %s", (role_id,))
        if not cur.fetchone():
            raise HTTPException(status_code=404, detail="Role not found")

        fields = []
        values = []
        if payload.description is not None:
            fields.append("description = %s")
            values.append(payload.description)
        if payload.status is not None:
            fields.append("status = %s")
            values.append(payload.status)

        if not fields:
            raise HTTPException(status_code=400, detail="No fields to update")

        values.append(role_id)
        cur.execute(f"UPDATE roles SET {', '.join(fields)} WHERE id = %s", values)
        conn.commit()

        cur.execute(
            """
            SELECT id, name, description, level, status,
            TO_CHAR(created_at, 'YYYY-MM-DD') as "createdAt"
            FROM roles
            WHERE id = %s
            """,
            (role_id,),
        )
        return cur.fetchone()
    finally:
        conn.close()


# ------------------- Email Routes -------------------

@router.get("/auth/emails")
def get_email_records():
    conn = get_db_connection()
    cur = conn.cursor()
    
    # ✅ FIX: Join BOTH 'assigned_to' and 'handled_by' to ensure we find a name
    query = """
        SELECT 
            e.id, 
            e.created_at, 
            e.recipient_email, 
            e.subject, 
            e.body, 
            e.status, 
            e.sent_at, 
            e.handled_by, 
            e.draft_reply,
            -- Prioritize Assigned User, fallback to Handled User
            COALESCE(u_assign.first_name, u_handle.first_name) as fname,
            COALESCE(u_assign.last_name, u_handle.last_name) as lname,
            e.assigned_to
        FROM email_records e
        LEFT JOIN users u_assign ON e.assigned_to = u_assign.id  -- Join 1
        LEFT JOIN users u_handle ON e.handled_by = u_handle.id   -- Join 2
        ORDER BY e.created_at DESC
    """
    
    cur.execute(query)
    rows = cur.fetchall()
    conn.close()
    
    return {
        "emails": [
            {
                "id": r[0],
                "created_at": r[1],
                "recipient_email": r[2],
                "subject": r[3],
                "body": r[4],
                "status": r[5] if r[5] else "pending",
                "sent_at": r[6],
                "handled_by": r[7],
                "draft_reply": r[8],
                # ✅ FIX: If name found, use it. If not, return None (so frontend shows '-')
                "employee_name": f"{r[9]} {r[10]}" if r[9] else None, 
                "assigned_to": r[11]
            }
            for r in rows
        ]
    }

# ------------------- ✅ SENT ITEMS ENDPOINT -------------------
@router.get("/auth/sent")
def get_sent_items(x_user_id: Optional[int] = Header(None, alias="X-User-Id")):
    """
    Fetches emails that have been successfully sent.
    """
    conn = get_db_connection()
    cur = conn.cursor()

    # Query Logic:
    # 1. WHERE sent_at IS NOT NULL -> Only get emails that were actually sent.
    # 2. SELECT draft_reply -> This is what the agent wrote (the sent message).
    
    query = """
        SELECT 
            e.id, 
            e.recipient_email,  -- (To Address)
            e.subject, 
            e.draft_reply,      -- (The actual sent content)
            e.sent_at, 
            e.status,
            e.language
        FROM email_records e
        WHERE e.sent_at IS NOT NULL
    """
    
    params = []

    # Optional: Filter by specific employee if needed
    if x_user_id:
        query += " AND e.handled_by = %s"
        params.append(x_user_id)

    query += " ORDER BY e.sent_at DESC"

    cur.execute(query, tuple(params))
    rows = cur.fetchall()
    conn.close()

    return {
        "sent": [
            {
                "id": r[0],
                "to": r[1],          # Recipient
                "subject": r[2],
                "body": r[3] if r[3] else "(No content)", # The reply text
                "sent_at": r[4].timestamp() if r[4] else None,
                "status": r[5],
                "language": r[6]
            }
            for r in rows
        ]
    }

# ------------------- ✅ FIXED: INDIVIDUAL EMPLOYEE STATS -------------------
@router.get("/auth/employee/stats/{user_id}")
def get_employee_dashboard_stats(user_id: int, period: str = "7"):
    conn = get_db_connection()
    cur = conn.cursor()

    # 1. Get Metric Counts
    stats_query = """
        SELECT 
            COUNT(*) FILTER (WHERE assigned_to = %s) as total_assigned,
            COUNT(*) FILTER (WHERE handled_by = %s) as total_handled,
            COUNT(*) FILTER (WHERE assigned_to = %s AND draft_reply IS NOT NULL AND sent_at IS NULL) as pending
        FROM email_records
    """
    cur.execute(stats_query, (user_id, user_id, user_id))
    stats = cur.fetchone()

    # 2. Get Graph Data with Dynamic Filters
    graph_query = ""
    
    # CASE 1: Number of Days (e.g., 7, 20, 30)
    if period.isdigit():
        days = int(period)
        graph_query = """
            SELECT TO_CHAR(sent_at, 'Mon DD') as label, COUNT(*) as count
            FROM email_records
            WHERE handled_by = %s 
              AND sent_at > NOW() - INTERVAL '%s days'
            -- ✅ FIX: Group by the formatted label AND the date (ignoring time)
            GROUP BY 1, DATE(sent_at) 
            ORDER BY DATE(sent_at) ASC
        """
        cur.execute(graph_query, (user_id, days))
    
    # CASE 2: Yearly View (Grouped by Month)
    elif period == "year":
        graph_query = """
            SELECT TO_CHAR(sent_at, 'Mon YY') as label, COUNT(*) as count
            FROM email_records
            WHERE handled_by = %s AND sent_at > NOW() - INTERVAL '1 year'
            GROUP BY 1, TO_CHAR(sent_at, 'YYYY-MM')
            ORDER BY TO_CHAR(sent_at, 'YYYY-MM') ASC
        """
        cur.execute(graph_query, (user_id,))
        
    # CASE 3: Fallback (7 Days)
    else:
        graph_query = """
            SELECT TO_CHAR(sent_at, 'Mon DD') as label, COUNT(*) as count
            FROM email_records
            WHERE handled_by = %s AND sent_at > NOW() - INTERVAL '7 days'
            GROUP BY 1, DATE(sent_at)
            ORDER BY DATE(sent_at) ASC
        """
        cur.execute(graph_query, (user_id,))

    graph_rows = cur.fetchall()
    conn.close()

    return {
        "metrics": {
            "assigned": stats[0] or 0,
            "handled": stats[1] or 0,
            "pending": stats[2] or 0
        },
        "graph": [{"name": row[0], "emails": row[1]} for row in graph_rows]
    }

# ------------------- ✅ FIXED: DASHBOARD STATS (ROBUST) -------------------
@router.get("/auth/dashboard/stats")
def get_dashboard_stats():
    conn = get_db_connection()
    cur = conn.cursor()
    
    # LOGIC FIX:
    # 1. Sent: If status is 'sent', 'replied', OR sent_at has a date.
    # 2. Pending: If NOT sent and NOT failed.
    
    query = """
        SELECT 
            COUNT(*) FILTER (WHERE status IN ('sent', 'replied') OR sent_at IS NOT NULL) as sent_count,
            
            COUNT(*) FILTER (WHERE (status IS NULL OR status = 'pending') AND sent_at IS NULL) as pending_count,
            
            COUNT(*) FILTER (WHERE status = 'failed') as failed_count,
            
            COUNT(*) FILTER (WHERE draft_reply IS NOT NULL AND sent_at IS NULL AND status != 'sent') as draft_count
        FROM email_records
    """
    
    cur.execute(query)
    result = cur.fetchone()
    conn.close()
    
    return {
        "sent": result[0] or 0,
        "pending": result[1] or 0,
        "failed": result[2] or 0,
        "drafts": result[3] or 0
    }

# ------------------- ✅ FIXED: DASHBOARD GRAPH (ROBUST) -------------------
@router.get("/auth/dashboard/graph")
def get_graph_data(period: str = "month"):
    conn = get_db_connection()
    cur = conn.cursor()
    
    # GRAPH LOGIC FIX:
    # We need a date to plot. If 'sent_at' is missing but it was sent, 
    # we fallback to 'created_at' (COALESCE) so the data appears on the chart.
    
    date_col = "COALESCE(sent_at, created_at)"
    
    if period == "day":
        # Last 10 Days
        query = f"""
            SELECT TO_CHAR({date_col}, 'DD') as label, COUNT(*) as count 
            FROM email_records 
            WHERE {date_col} > NOW() - INTERVAL '10 days' 
              AND (status IN ('sent', 'replied') OR sent_at IS NOT NULL)
            GROUP BY 1, DATE({date_col}) 
            ORDER BY DATE({date_col}) ASC
        """
    elif period == "year":
        # All time grouped by Year
        query = f"""
            SELECT TO_CHAR({date_col}, 'YYYY') as label, COUNT(*) as count 
            FROM email_records 
            WHERE (status IN ('sent', 'replied') OR sent_at IS NOT NULL)
            GROUP BY 1 
            ORDER BY 1 ASC
        """
    else:
        # Default: Last 12 Months
        query = f"""
            SELECT TO_CHAR({date_col}, 'Mon') as label, COUNT(*) as count 
            FROM email_records 
            WHERE {date_col} > NOW() - INTERVAL '1 year' 
              AND (status IN ('sent', 'replied') OR sent_at IS NOT NULL)
            GROUP BY 1, DATE_TRUNC('month', {date_col})
            ORDER BY DATE_TRUNC('month', {date_col}) ASC
        """
        
    cur.execute(query)
    rows = cur.fetchall()
    conn.close()
    
    return {"data": [{"label": r[0], "emailsSent": r[1]} for r in rows]}
# Paste this at the END of backend/routers/auth.py

# ------------------- ✅ HEARTBEAT (FIX LAG) -------------------
class HeartbeatRequest(BaseModel):
    user_id: int

@router.post("/users/heartbeat")
def user_heartbeat(payload: HeartbeatRequest):
    """
    Updates the user's 'last_seen' status so they appear Online.
    """
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        # Update the user to set them as online
        cur.execute("UPDATE users SET is_online = TRUE WHERE id = %s", (payload.user_id,))
        conn.commit()
        return {"status": "ok"}
    except Exception as e:
        print(f"Heartbeat error: {e}")
        return {"status": "error", "detail": str(e)}
    finally:
        conn.close()