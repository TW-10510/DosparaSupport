from fastapi import APIRouter, HTTPException, Request
from sqlalchemy.orm import Session
from database import SessionLocal
from models.email_record import EmailRecord

router = APIRouter()

def _get_user_id(request: Request) -> int:
    uid = request.headers.get("X-User-Id")
    if not uid or uid == "null":
        raise HTTPException(status_code=401, detail="Missing X-User-Id")
    return int(uid)

@router.get("/", summary="List sent items")
def list_sent(request: Request):
    user_id = _get_user_id(request)
    db: Session = SessionLocal()

    sent = (
        db.query(EmailRecord)
        .filter(
            EmailRecord.status == "sent",
            EmailRecord.handled_by == user_id
        )
        .order_by(EmailRecord.sent_at.desc())
        .all()
    )

    result = []
    for e in sent:
        result.append({
            "id": e.id,
            "to": e.recipient_email,
            "subject": e.subject,
            "body": e.body,
            "sent_at": int(e.sent_at.timestamp()) if e.sent_at else None,
            "status": "Sent",
            "language": getattr(e, "language", "en"),
        })

    db.close()
    return {"sent": result}