from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from datetime import datetime
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

# Define the router with the correct prefix for the frontend
router = APIRouter(prefix="/api/templates", tags=["templates"])

# Database Connection Helper
def get_db_connection():
    return psycopg2.connect(os.getenv("DATABASE_URL"))

# --- Pydantic Models ---
class TemplateSchema(BaseModel):
    name: str
    category: str
    status: str
    fromName: str  # Frontend sends camelCase
    fromEmail: str
    subject: str
    body: str

# --- Routes ---

@router.get("/")
def get_templates():
    conn = get_db_connection()
    cur = conn.cursor()
    
    # Select mapping DB columns to the shape UI expects
    cur.execute("""
        SELECT id, name, category, status, from_name, from_email, subject, body, last_updated 
        FROM templates 
        ORDER BY last_updated DESC
    """)
    rows = cur.fetchall()
    conn.close()

    return [
        {
            "id": r[0],
            "name": r[1],
            "category": r[2],
            "status": r[3],
            "fromName": r[4],
            "fromEmail": r[5],
            "subject": r[6],
            "body": r[7],
            "lastUpdated": r[8].strftime("%Y-%m-%d") if r[8] else ""
        }
        for r in rows
    ]

@router.post("/")
def create_template(payload: TemplateSchema):
    conn = get_db_connection()
    cur = conn.cursor()
    
    try:
        cur.execute("""
            INSERT INTO templates (name, category, status, from_name, from_email, subject, body, last_updated)
            VALUES (%s, %s, %s, %s, %s, %s, %s, NOW())
            RETURNING id
        """, (
            payload.name, payload.category, payload.status, 
            payload.fromName, payload.fromEmail, payload.subject, payload.body
        ))
        new_id = cur.fetchone()[0]
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

    return {"message": "Template created", "id": new_id}

@router.put("/{template_id}")
def update_template(template_id: int, payload: TemplateSchema):
    conn = get_db_connection()
    cur = conn.cursor()

    # Check if exists
    cur.execute("SELECT id FROM templates WHERE id = %s", (template_id,))
    if not cur.fetchone():
        conn.close()
        raise HTTPException(status_code=404, detail="Template not found")

    try:
        cur.execute("""
            UPDATE templates
            SET name = %s, category = %s, status = %s, from_name = %s, 
                from_email = %s, subject = %s, body = %s, last_updated = NOW()
            WHERE id = %s
        """, (
            payload.name, payload.category, payload.status, 
            payload.fromName, payload.fromEmail, payload.subject, payload.body,
            template_id
        ))
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

    return {"message": "Template updated"}

@router.delete("/{template_id}")
def delete_template(template_id: int):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("DELETE FROM templates WHERE id = %s", (template_id,))
    if cur.rowcount == 0:
        conn.close()
        raise HTTPException(status_code=404, detail="Template not found")
        
    conn.commit()
    conn.close()
    return {"message": "Template deleted"}