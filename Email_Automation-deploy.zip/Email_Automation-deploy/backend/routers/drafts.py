import os
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session
from openai import OpenAI

from database import SessionLocal
from models.email_record import EmailRecord
from services.outlook_graph_client import send_email_via_graph

# ------------------------------
# ENV + OpenAI
# ------------------------------
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=OPENAI_API_KEY)

router = APIRouter()

# ------------------------------
# Auth helper
# ------------------------------
def _get_user_id(request: Request) -> int:
    uid = request.headers.get("X-User-Id")
    if not uid or uid == "null":
        raise HTTPException(status_code=401, detail="Missing X-User-Id")
    return int(uid)

# ------------------------------
# Models
# ------------------------------
class FeedbackReq(BaseModel):
    original_email_id: int
    human_feedback: str

class SendDraftReq(BaseModel):
    original_email_id: int
    final_reply: Optional[str] = None
class TranslateReq(BaseModel):
    text: str
    targetLang: str  # en | ja

# ----------------------------------------------------
# GET /drafts → list drafts (DB)
# ----------------------------------------------------
@router.get("/", summary="List drafts")
def list_drafts(request: Request):
    user_id = _get_user_id(request)
    db: Session = SessionLocal()

    drafts = (
        db.query(EmailRecord)
        .filter(
            EmailRecord.assigned_to == user_id,
            EmailRecord.status.in_(["pending_approval", "approved"])
        )

        .order_by(EmailRecord.created_at.desc())
        .all()
    )

    db.close()

    return {
        "drafts": [
            {
                "id": d.id,
                "subject": d.subject,
                "content": d.body,
                "preview": (d.body or "")[:120],
                "sender_email": d.recipient_email,
                "assigned_to": d.assigned_to,
                "status": d.status,
                "received_at": int(d.created_at.timestamp()),
                "draft_reply": getattr(d, "draft_reply", ""),
                "language": getattr(d, "language", "en"),
            }
            for d in drafts
        ]
    }

# ----------------------------------------------------
# POST /drafts/feedback → Store human feedback
# ----------------------------------------------------
@router.post("/feedback", summary="Store human feedback")
def store_feedback(req: FeedbackReq, request: Request):
    user_id = _get_user_id(request)
    db: Session = SessionLocal()

    email = db.query(EmailRecord).filter(EmailRecord.id == req.original_email_id).first()
    if not email:
        db.close()
        raise HTTPException(status_code=404, detail="Draft not found")

    if email.assigned_to != user_id:
        db.close()
        raise HTTPException(status_code=403, detail="Not your draft")

    email.human_feedback = req.human_feedback
    db.commit()
    db.close()

    return {"status": "ok", "message": "Feedback saved"}

# ----------------------------------------------------
# POST /drafts/feedback/generate → Generate improved reply
# ----------------------------------------------------
@router.post("/feedback/generate", summary="Generate improved AI reply")
def generate_improved_reply(req: FeedbackReq, request: Request):
    user_id = _get_user_id(request)
    db: Session = SessionLocal()

    email = db.query(EmailRecord).filter(EmailRecord.id == req.original_email_id).first()
    if not email:
        db.close()
        raise HTTPException(status_code=404, detail="Draft not found")

    if email.assigned_to != user_id:
        db.close()
        raise HTTPException(status_code=403, detail="Not your draft")

    prompt = f"""
You are an expert email support agent.

Original customer email:
---
{email.body}
---

Previous AI reply:
---
{getattr(email, 'draft_reply', '')}
---

Human feedback:
---
{req.human_feedback}
---

Rewrite the reply following the feedback.
"""

    try:
        completion = client.chat.completions.create(
            model="gpt-5",
            messages=[{"role": "user", "content": prompt}]
        )
        improved_reply = completion.choices[0].message.content.strip()
    except Exception as e:
        db.close()
        raise HTTPException(status_code=500, detail=f"OpenAI error: {e}")

    email.draft_reply = improved_reply
    db.commit()
    db.close()

    return {
        "status": "ok",
        "improved_reply": improved_reply
    }

# ----------------------------------------------------
# POST /drafts/send → Send draft
# ----------------------------------------------------
@router.post("/send")
def send_draft(payload: SendDraftReq, request: Request):
    print("FINAL_REPLY_FROM_FRONTEND:", payload.final_reply)  # ✅ DEBUG
    user_id = _get_user_id(request)
    db = SessionLocal()

    email = db.query(EmailRecord).filter(
        EmailRecord.id == payload.original_email_id
    ).first()

    if not email:
        db.close()
        raise HTTPException(status_code=404, detail="Draft not found")

    # 🔒 OWNERSHIP CHECK
    if email.assigned_to != user_id:
        db.close()
        raise HTTPException(status_code=403, detail="Not your draft")

    if email.status != "pending_approval":
        db.close()
        raise HTTPException(status_code=400, detail="Draft already sent")

    # ✉️ SEND EMAIL
    from services.outlook_graph_client import reply_to_message_strict

    final_body = payload.final_reply or email.draft_reply or email.body

    reply_to_message_strict(
        message_id=email.outlook_id,
        body=final_body
    )
    # ✅ UPDATE RECORD
    email.status = "sent"
    email.sent_at = datetime.now(timezone.utc)
    email.handled_by = user_id

    db.commit()
    db.close()

    return {"message": "Email sent successfully"}



# ----------------------------------------------------
# POST /drafts/translate → Translate text
# ----------------------------------------------------
@router.post("/translate")
def translate_text(req: TranslateReq):
    if req.targetLang not in ("en", "ja"):
        raise HTTPException(status_code=400, detail="Invalid target language")

    if not req.text or req.text.strip() == "":
        raise HTTPException(status_code=400, detail="Text to translate cannot be empty")

    messages = [
        {"role": "system", "content": "You are a translation engine. Return ONLY the translated text."},
        {"role": "user", "content": f"Translate to {'Japanese' if req.targetLang=='ja' else 'English'}:\n{req.text[:1000]}"}
    ]

    try:
        completion = client.chat.completions.create(
            model="gpt-4",  # use gpt-4 instead of gpt-5 for testing
            messages=messages,
            temperature=0,
            max_tokens=500
        )
        translated_text = completion.choices[0].message.content.strip()
        return {"translated": translated_text}
    except Exception as e:
        print("OpenAI translation error:", e)  # log full error
        raise HTTPException(status_code=500, detail="Translation service failed")
