from fastapi import APIRouter, Depends, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date
from database import SessionLocal
from models.email_record import EmailRecord
from models.user import User

from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors

import tempfile
import pandas as pd

router = APIRouter()

# ---------------- DB Dependency ----------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------------- EMAIL ACTIVITY REPORT ----------------
@router.get("/email-activity")
def email_activity_report(db: Session = Depends(get_db)):
    return {
        "total": db.query(func.count(EmailRecord.id)).scalar(),
        "sent": db.query(func.count(EmailRecord.id)).filter(EmailRecord.status == "sent").scalar(),
        "failed": db.query(func.count(EmailRecord.id)).filter(EmailRecord.status == "failed").scalar(),
        "pending": db.query(func.count(EmailRecord.id)).filter(
            EmailRecord.status.in_(["received", "draft"])
        ).scalar(),
    }


# ---------------- SLA REPORT ----------------
@router.get("/sla")
def sla_report(db: Session = Depends(get_db)):
    within_sla = db.query(func.count(EmailRecord.id)).filter(
        EmailRecord.sent_at.isnot(None),
        EmailRecord.sla_deadline.isnot(None),
        EmailRecord.sent_at <= EmailRecord.sla_deadline,
    ).scalar()

    breached = db.query(func.count(EmailRecord.id)).filter(
        EmailRecord.sent_at.isnot(None),
        EmailRecord.sla_deadline.isnot(None),
        EmailRecord.sent_at > EmailRecord.sla_deadline,
    ).scalar()

    avg_response = db.query(
        func.avg(func.extract("epoch", EmailRecord.sent_at - EmailRecord.created_at))
    ).filter(EmailRecord.sent_at.isnot(None)).scalar()

    return {
        "within_sla": within_sla,
        "breached": breached,
        "avg_response_seconds": int(avg_response or 0),
    }


# ---------------- EMPLOYEE WORKLOAD REPORT ----------------
@router.get("/employees")
def employee_report(db: Session = Depends(get_db)):
    rows = db.query(
        EmailRecord.handled_by,
        func.count(EmailRecord.id).label("emails_handled"),
    ).filter(
        EmailRecord.handled_by.isnot(None)
    ).group_by(EmailRecord.handled_by).all()

    result = []
    for row in rows:
        user = db.query(User).filter(User.id == row.handled_by).first()
        result.append({
            "employee_id": row.handled_by,
            "employee_name": f"{user.first_name} {user.last_name}" if user else "",
            "emails_handled": row.emails_handled,
        })

    return result


# ---------------- SYSTEM LOGS ----------------
def get_handled_by_display(r):
    name = f"{r.first_name} {r.last_name}" if r.first_name and r.last_name else None

    if r.EmailRecord.status == "pending_approval" and name:
        return name
    elif r.EmailRecord.status in ["received", "draft"]:
        return "Pending"
    elif name:
        return name
    return ""


@router.get("/logs/system")
def system_logs(
    limit: int = Query(50, ge=1, le=500),
    today_only: bool = Query(False),
    db: Session = Depends(get_db),
):
    query = db.query(
        EmailRecord, User.first_name, User.last_name
    ).outerjoin(User, EmailRecord.handled_by == User.id)

    if today_only:
        today = date.today()
        query = query.filter(
            func.date(func.coalesce(EmailRecord.sent_at, EmailRecord.created_at)) == today
        )

    records = query.order_by(
        EmailRecord.created_at.desc()
    ).limit(limit).all()

    return [
        {
            "received_at": r.EmailRecord.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            "handled_at": r.EmailRecord.sent_at.strftime("%Y-%m-%d %H:%M:%S")
            if r.EmailRecord.sent_at else None,
            "subject": r.EmailRecord.subject,
            "status": r.EmailRecord.status,
            "handled_by": get_handled_by_display(r),
            "source": "Email Engine",
        }
        for r in records
    ]


# ---------------- DOWNLOAD SYSTEM LOGS (FILTERED) ----------------
@router.get("/logs/system/download")
def download_system_logs(
    format: str = Query("pdf", regex="^(pdf|excel)$"),
    limit: int = Query(50, ge=1, le=500),
    today_only: bool = Query(False),
    db: Session = Depends(get_db),
):
    query = db.query(
        EmailRecord, User.first_name, User.last_name
    ).outerjoin(User, EmailRecord.handled_by == User.id)

    if today_only:
        today = date.today()
        query = query.filter(
            func.date(func.coalesce(EmailRecord.sent_at, EmailRecord.created_at)) == today
        )

    records = query.order_by(
        EmailRecord.created_at.desc()
    ).limit(limit).all()

    data = []
    for r in records:
        data.append({
            "Received At": r.EmailRecord.created_at.strftime("%Y-%m-%d %H:%M"),
            "Handled At": r.EmailRecord.sent_at.strftime("%Y-%m-%d %H:%M")
            if r.EmailRecord.sent_at else "-",
            "Subject": r.EmailRecord.subject,
            "Handled By": get_handled_by_display(r),
            "Status": r.EmailRecord.status,
        })

    # -------- EXCEL --------
    if format == "excel":
        df = pd.DataFrame(data)
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx")
        df.to_excel(tmp.name, index=False)

        return FileResponse(
            tmp.name,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename="system_logs.xlsx",
        )

    # -------- PDF --------
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    doc = SimpleDocTemplate(tmp.name, pagesize=A4)
    styles = getSampleStyleSheet()

    elements = [
        Paragraph(
            "System Email Logs" + (" (Today)" if today_only else ""),
            styles["Title"],
        ),
        Paragraph("<br/>", styles["Normal"]),
    ]

    table_data = [["Received At", "Handled At", "Subject", "Handled By", "Status"]]
    for row in data:
        table_data.append([
            row["Received At"],
            row["Handled At"],
            row["Subject"][:50],
            row["Handled By"],
            row["Status"],
        ])

    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))

    elements.append(table)
    doc.build(elements)

    return FileResponse(
        tmp.name,
        media_type="application/pdf",
        filename="system_logs.pdf",
    )
