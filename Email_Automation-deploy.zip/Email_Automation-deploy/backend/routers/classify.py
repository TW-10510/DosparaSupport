# backend/routers/classify.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any
from services.classifier import classify_email

router = APIRouter()

class ClassifyRequest(BaseModel):
    email_text: str
    require_confidence: Optional[bool] = False

class ClassifyResponse(BaseModel):
    label: str
    confidence: Optional[float]
    explanation: Optional[str]
    raw: Optional[Dict[str,Any]]

@router.post("/classify", response_model=ClassifyResponse)
def classify_endpoint(req: ClassifyRequest):
    if not req.email_text or req.email_text.strip() == "":
        raise HTTPException(status_code=400, detail="email_text required")
    try:
        out = classify_email(req.email_text)
        # optionally require confidence threshold (client can check)
        return ClassifyResponse(label=out["label"], confidence=out.get("confidence"), explanation=out.get("explanation"), raw=out.get("raw"))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

