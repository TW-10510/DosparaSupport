#!/usr/bin/env python3
"""
build_faiss_index.py
- Reads rag_kb JSON file (array of {"id","type","category","text"})
- Optionally reads reply_pairs JSONL or raw_emails CSV to include more entries
- Calls OpenAI Embeddings API to get embeddings for each chunk
- Builds and saves a FAISS index (index.faiss) and metadata file (kb_metadata.json)
- Provides a simple `query_index` function to test search results
"""

import os
import json
import csv
import time
from tqdm import tqdm
import numpy as np
import faiss
import openai
from dotenv import load_dotenv

# === CONFIG ===
RAG_KB_PATH = "email_automation_dataset/rag_kb_1000.json"   # update path if needed
REPLY_PAIRS_PATH = "email_automation_dataset/reply_pairs_600.jsonl"  # optional
RAW_EMAILS_PATH = "email_automation_dataset/raw_emails_2000.csv"      # optional
OUTPUT_DIR = "faiss_index"
INDEX_FILENAME = "index.faiss"
METADATA_FILENAME = "kb_metadata.json"
EMBEDDING_MODEL = "text-embedding-3-small"  # cost-effective; change if you prefer larger
BATCH_SIZE = 32
OPENAI_API_KEY_ENV = "OPENAI_API_KEY"
# =================

def load_env():
    # load .env if present
    load_dotenv()
    key = os.getenv(OPENAI_API_KEY_ENV)
    if not key:
        raise RuntimeError(f"OpenAI API key not found in env variable {OPENAI_API_KEY_ENV}. Set it or create a .env file.")
    openai.api_key = key

def read_rag_kb(path):
    with open(path, "r", encoding="utf8") as f:
        data = json.load(f)
    # ensure each entry has id & text
    entries = []
    for e in data:
        _id = e.get("id") or f"kb_{len(entries)+1}"
        entries.append({
            "id": _id,
            "text": e.get("text",""),
            "type": e.get("type",""),
            "category": e.get("category","")
        })
    return entries

def read_reply_pairs(path):
    entries = []
    if not os.path.exists(path):
        return entries
    with open(path, "r", encoding="utf8") as f:
        for line in f:
            if not line.strip(): continue
            obj = json.loads(line)
            # extract prompt/email portion if present
            prompt = obj.get("prompt") or ""
            # try to parse email text
            email_part = prompt.split("Email:\n")[-1].split("\n\nReply:")[0] if "Email:\n" in prompt else prompt
            entries.append({"id": f"rp_{len(entries)+1}", "text": email_part, "type":"reply_pair", "category":""})
    return entries

def read_raw_emails(path, max_rows=None):
    entries = []
    if not os.path.exists(path):
        return entries
    import pandas as pd
    df = pd.read_csv(path)
    if max_rows:
        df = df.head(max_rows)
    for i,row in df.iterrows():
        entries.append({"id": f"raw_{i+1}", "text": str(row.get("clean_text","")), "type":"raw_email", "category": row.get("category","")})
    return entries

def batch(iterable, n=1):
    l = len(iterable)
    for i in range(0, l, n):
        yield iterable[i:i+n]

def get_embeddings(texts):
    """
    Calls OpenAI Embeddings API for a list of texts and returns list of vectors.
    Works across different openai package versions which may return dicts or objects.
    """
    vectors = []

    def _call_embeddings(batch_inputs):
        # try several call styles, return whatever the client provides
        try:
            return openai.Embeddings.create(model=EMBEDDING_MODEL, input=batch_inputs)
        except Exception as e1:
            try:
                return openai.embeddings.create(model=EMBEDDING_MODEL, input=batch_inputs)
            except Exception as e2:
                try:
                    from openai import OpenAI as _OpenAIClient
                    client = _OpenAIClient()
                    return client.embeddings.create(model=EMBEDDING_MODEL, input=batch_inputs)
                except Exception as e3:
                    raise RuntimeError(
                        "Failed to call OpenAI embeddings API. Tried multiple call styles. "
                        f"Errors:\n - {e1}\n - {e2}\n - {e3}"
                    )

    for chunk in batch(texts, BATCH_SIZE):
        inputs = [t.replace("\n", " ")[:2000] for t in chunk]
        try:
            resp = _call_embeddings(inputs)
        except Exception as e:
            print("OpenAI API error when calling embeddings:", e)
            print("Sleeping 5s and retrying...")
            time.sleep(5)
            resp = _call_embeddings(inputs)

        # unify access to resp.data
        resp_data = None
        if isinstance(resp, dict):
            resp_data = resp.get("data", [])
        else:
            # object-like response (CreateEmbeddingResponse)
            resp_data = getattr(resp, "data", [])

        if resp_data is None:
            raise RuntimeError("No 'data' in embeddings response: " + str(resp))

        # extract embedding vectors robustly
        for item in resp_data:
            emb = None
            if isinstance(item, dict):
                emb = item.get("embedding") or item.get("embeddings")  # try common keys
            else:
                emb = getattr(item, "embedding", None) or getattr(item, "embeddings", None)
            if emb is None:
                raise RuntimeError("Could not parse embedding from response item: " + str(item))
            vectors.append(emb)

        time.sleep(0.1)  # gentle rate limit
    return vectors



def build_faiss(vectors, dim):
    """
    Build an IndexFlatIP index (cosine similarity) on normalized vectors.
    We'll store as IndexFlatIP with normalization (dot product on normalized vectors = cosine).
    """
    # convert to numpy array
    mat = np.array(vectors).astype('float32')
    # normalize rows to unit length (so inner product == cosine similarity)
    faiss.normalize_L2(mat)
    index = faiss.IndexFlatIP(dim)   # inner product
    index.add(mat)
    return index

def save_index(index, out_dir, filename):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, filename)
    faiss.write_index(index, path)
    return path

def save_metadata(metadata, out_dir, filename):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, filename)
    with open(path, "w", encoding="utf8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    return path

def load_index(path):
    return faiss.read_index(path)

def query_index(index, vectors, metadata, query_vec, top_k=5):
    # normalize query vector
    q = np.array([query_vec]).astype('float32')
    faiss.normalize_L2(q)
    D, I = index.search(q, top_k)  # returns distances (inner products) and indices
    results = []
    for score, idx in zip(D[0], I[0]):
        if idx < 0 or idx >= len(metadata):
            continue
        m = metadata[idx]
        results.append({"score": float(score), "id": m["id"], "text": m["text"], "type": m.get("type"), "category": m.get("category")})
    return results

def main():
    load_env()
    print("Loading RAG KB...")
    rag = read_rag_kb(RAG_KB_PATH)
    print(f"RAG KB entries: {len(rag)}")
    # optionally add reply pairs and raw emails (comment out if not desired)
    replies = read_reply_pairs(REPLY_PAIRS_PATH)
    raws = read_raw_emails(RAW_EMAILS_PATH, max_rows=0)  # set max_rows>0 to include some
    print(f"Reply pairs: {len(replies)}, raw emails included: {len(raws)}")
    entries = rag + replies + raws
    texts = [e["text"] for e in entries]
    # get embeddings
    print("Generating embeddings (this will call OpenAI API)...")
    vectors = get_embeddings(texts)
    dim = len(vectors[0])
    print("Embedding dim:", dim, "total vectors:", len(vectors))
    # build FAISS index
    print("Building FAISS index...")
    index = build_faiss(vectors, dim)
    idx_path = save_index(index, OUTPUT_DIR, INDEX_FILENAME)
    print("Index saved to", idx_path)
    # prepare metadata (in the same order as vectors / index)
    metadata = []
    for e in entries:
        metadata.append({"id": e["id"], "text": e["text"], "type": e.get("type",""), "category": e.get("category","")})
    meta_path = save_metadata(metadata, OUTPUT_DIR, METADATA_FILENAME)
    print("Metadata saved to", meta_path)
    print("Done. You can run queries now using the saved index and metadata.")

if __name__ == "__main__":
    main()
