# backend/services/prefilter.py
"""
Smarter prefilter for incoming emails.

- Run rule-based checks (blacklist, whitelist, noreply, keywords, headers)
- Optional LLM-based check (chat or embeddings) if ENABLE_SMART_FILTER=true
- Exposes two functions:
    should_ignore_email(subject, sender, body, headers=None)
    post_classification_skip(classifier_result, subject, sender, body)
"""

import os
import json
import math
from typing import Tuple, Optional, Dict
from dotenv import load_dotenv

load_dotenv()

# Environment flags
ENABLE_SMART_FILTER = os.getenv("ENABLE_SMART_FILTER", "false").lower() == "true"
SMART_FILTER_MODE = os.getenv("SMART_FILTER_MODE", "chat")  # chat | emb | rules | hybrid
SMART_FILTER_CONFIDENCE = float(os.getenv("SMART_FILTER_CONFIDENCE", "0.70"))

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
SMART_CLASSIFY_MODEL = os.getenv("SMART_CLASSIFY_MODEL", "gpt-5)
SMART_EMBED_MODEL = os.getenv("SMART_EMBED_MODEL", "text-embedding-3-small")

WHITELIST_DOMAINS = {d.strip().lower() for d in (os.getenv("WHITELIST_DOMAINS", "") or "").split(",") if d.strip()}
WHITELIST_SENDERS = {s.strip().lower() for s in (os.getenv("WHITELIST_SENDERS", "") or "").split(",") if s.strip()}

BLACKLIST_DOMAINS = {d.strip().lower() for d in (os.getenv("BLACKLIST_DOMAINS", "") or "").split(",") if d.strip()}
BLACKLIST_SENDERS = {s.strip().lower() for s in (os.getenv("BLACKLIST_SENDERS", "") or "").split(",") if s.strip()}

# Simple toggles
SKIP_CLASSIFICATION_OTHER = os.getenv("SKIP_CLASSIFICATION_OTHER", "false").lower() == "true"
SKIP_NOREPLY = os.getenv("SKIP_NOREPLY", "true").lower() == "true"

# Heuristics
PROMO_KEYWORDS = [
    "unsubscribe", "newsletter", "promo", "promotion", "sale", "discount", "deal",
    "special offer", "offers", "subscribe", "limited time", "save up to",
    "discount code", "coupon", "flash sale"
]
OTP_KEYWORDS = ["otp", "verification code", "one-time code", "two-factor", "2fa"]

NOREPLY_PATTERNS = ["noreply", "no-reply", "donotreply", "do-not-reply", "no_reply"]

# Optional OpenAI client — created lazily only when needed
def _get_openai_client():
    try:
        import openai
    except Exception as e:
        raise RuntimeError("openai package required for smart filter. pip install openai") from e
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY required for smart filter. Set it in .env")
    openai.api_key = OPENAI_API_KEY
    return openai

# --------------------
# Rule-based filter
# --------------------
def basic_rule_filter(subject: str, sender: str, body: str, headers: Optional[Dict[str,str]] = None) -> Tuple[bool,str]:
    s = (subject or "").lower()
    b = (body or "").lower()
    sender_l = (sender or "").lower()
    domain = sender_l.split("@")[-1] if "@" in sender_l else ""

    # whitelist overrides
    if sender_l in WHITELIST_SENDERS or domain in WHITELIST_DOMAINS:
        return False, "whitelisted"

    # blacklist immediate
    for pat in BLACKLIST_SENDERS:
        if pat and pat in sender_l:
            return True, f"blacklisted_sender:{pat}"
    for dom in BLACKLIST_DOMAINS:
        if dom and dom in domain:
            return True, f"blacklisted_domain:{dom}"

    # noreply skip toggle
    if SKIP_NOREPLY:
        for p in NOREPLY_PATTERNS:
            if p in sender_l:
                return True, "noreply_sender"

    # header heuristics
    if headers:
        # common bulk headers
        for hk in headers.keys():
            hk_l = hk.lower()
            if "list-unsubscribe" in hk_l or "precedence" in hk_l or "x-mailing-list" in hk_l:
                return True, "bulk_header"

        # Auto-Submitted
        auto_sub = headers.get("Auto-Submitted") or headers.get("auto-submitted") or ""
        if auto_sub and auto_sub.lower() != "no":
            return True, "auto_submitted"

    # promo keywords in subject/body
    for kw in PROMO_KEYWORDS:
        if kw in s or kw in b:
            return True, f"promo_kw:{kw}"

    # OTP or verification emails
    for kw in OTP_KEYWORDS:
        if kw in s or kw in b:
            return True, "otp"

    # very short/empty content
    if len(b.strip()) < 5:
        return True, "empty_body"

    return False, ""

# --------------------
# LLM-based filter (few-shot chat)
# --------------------
def llm_chat_intent_check(subject: str, body: str) -> Tuple[str, float]:
    """
    Returns ('support'|'non_support', confidence)
    """
    try:
        openai = _get_openai_client()
    except Exception as e:
        # missing client => default non-support
        return "non_support", 0.0

    prompt = (
        "Classify whether the following email is a CUSTOMER SUPPORT inquiry that requires a support agent reply.\n\n"
        "Return JSON ONLY with keys: intent (support|non_support), confidence (0.0-1.0), reason.\n\n"
        "Example 1:\nEmail: \"My order [ORDER_ID] hasn't arrived and tracking shows no updates. Please help.\"\nOutput: {\"intent\":\"support\",\"confidence\":0.95,\"reason\":\"order not delivered\"}\n\n"
        "Example 2:\nEmail: \"Unsubscribe me from this newsletter\" \nOutput: {\"intent\":\"non_support\",\"confidence\":0.99,\"reason\":\"newsletter unsubscribe\"}\n\n"
        f"Email Subject: {subject}\nEmail Body: {body[:4000]}\n\nOutput:"
    )

    try:
        # try older chat API style first, fallback to client object if needed
        resp_text = None
        try:
            resp = openai.ChatCompletion.create(
                model=SMART_CLASSIFY_MODEL,
                messages=[{"role":"user", "content": prompt}],
                temperature=0.0,
                max_tokens=128
            )
            if isinstance(resp, dict):
                resp_text = resp["choices"][0]["message"]["content"]
            else:
                resp_text = resp.choices[0].message.content
        except Exception:
            # fallback new client style
            from openai import OpenAI as _OpenAIClient
            client = _OpenAIClient(api_key=OPENAI_API_KEY)
            resp = client.chat.completions.create(
                model=SMART_CLASSIFY_MODEL,
                messages=[{"role":"user", "content": prompt}],
                temperature=0.0,
                max_tokens=128
            )
            if isinstance(resp, dict):
                resp_text = resp["choices"][0]["message"]["content"]
            else:
                resp_text = resp.choices[0].message.content

        # parse JSON object from model output
        import re, json
        m = re.search(r"(\{.*\})", resp_text, flags=re.S)
        if m:
            obj = json.loads(m.group(1))
            intent = obj.get("intent","non_support")
            conf = float(obj.get("confidence", 0.0))
            return intent, conf
    except Exception:
        pass

    return "non_support", 0.0

# --------------------
# Public API: pre-check before doing heavy steps
# --------------------
def should_ignore_email(subject: str, sender: str, body: str, headers: Optional[Dict[str,str]] = None) -> Tuple[bool,str]:
    """
    Rule-based + optional LLM prefilter.
    Returns (ignore_flag, reason)
    """
    # Step 1: basic rules
    rule_ignore, reason = basic_rule_filter(subject, sender, body, headers=headers)
    if rule_ignore:
        # if we're in hybrid/rules mode, optionally re-check with LLM (not implemented here)
        if SMART_FILTER_MODE == "rules":
            return True, reason
        if SMART_FILTER_MODE == "hybrid" and ENABLE_SMART_FILTER:
            # if LLM says it's support, keep it; otherwise skip
            intent, conf = llm_chat_intent_check(subject, body)
            if intent == "support" and conf >= SMART_FILTER_CONFIDENCE:
                return False, "llm_overruled_rules"
            return True, f"{reason}+hybrid"
        return True, reason

    # Step 2: optional LLM-only check
    if ENABLE_SMART_FILTER and SMART_FILTER_MODE in ("chat", "hybrid"):
        intent, conf = llm_chat_intent_check(subject, body)
        if intent == "non_support" and conf >= SMART_FILTER_CONFIDENCE:
            return True, f"llm_non_support_conf_{conf:.2f}"
        # otherwise, treat as not ignored

    # Default: do not ignore
    return False, ""

# --------------------
# Post-classification check
# --------------------
def post_classification_skip(classifier_result: Optional[Dict], subject: str, sender: str, body: str) -> Tuple[bool,str]:
    """
    After you run your classifier, call this to decide if the classifier labeled it 'Other' (or similar)
    and you want to skip the RAG step.

    classifier_result should be the dict returned by your /api/classify endpoint, e.g.:
      {"label":"Other", "confidence": 0.8, "explanation":"..."}
    """
    if not classifier_result:
        return False, ""

    label = (classifier_result.get("label") or "").lower()
    explanation = (classifier_result.get("explanation") or "").lower()

    # Skip when label is Other and SKIP_CLASSIFICATION_OTHER is enabled and explanation suggests promo/newsletter
    if SKIP_CLASSIFICATION_OTHER and label in ("other", "misc", "unknown"):
        if any(k in explanation for k in ("promo", "promotional", "newsletter", "discount", "sale", "offer", "unsubscribe", "welcome")):
            return True, "post_classification_promo"

        # also check subject/body heuristics for a second safety net
        s = (subject or "").lower()
        b = (body or "").lower()
        if any(k in s or k in b for k in PROMO_KEYWORDS):
            return True, "post_classification_promo_kw"

    # Additional safety: skip noreply if SKIP_NOREPLY true
    if SKIP_NOREPLY:
        sender_l = (sender or "").lower()
        for p in NOREPLY_PATTERNS:
            if p in sender_l:
                return True, "post_classification_noreply"

    return False, ""
