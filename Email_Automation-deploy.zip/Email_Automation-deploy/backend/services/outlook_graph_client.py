# backend/services/outlook_graph_client.py

import requests
import markdown
from services.ms_auth import get_access_token

BASE = "https://graph.microsoft.com/v1.0"


def _headers():
    return {
        "Authorization": f"Bearer {get_access_token()}",
        "Content-Type": "application/json",
    }


# -------------------------------------------------
# Helper: Convert Markdown → Outlook-safe HTML
# -------------------------------------------------
def markdown_to_outlook_html(md_text: str) -> str:
    """
    Convert Markdown into Outlook-safe HTML
    - Renders **bold**, lists, links, paragraphs
    - Outlook-compatible styling
    """

    html_body = markdown.markdown(
        md_text or "",
        extensions=["extra", "nl2br"]
    )

    return f"""
    <html>
      <body style="
        font-family: Segoe UI, Arial, sans-serif;
        font-size: 14px;
        color: #000;
        line-height: 1.6;
      ">
        {html_body}
      </body>
    </html>
    """


# -------------------------------------------------
# Fetch unread messages
# -------------------------------------------------
def fetch_unread(limit=10):
    url = f"{BASE}/me/mailFolders/Inbox/messages"
    params = {
        "$filter": "isRead eq false",
        "$top": limit,
    }
    r = requests.get(url, headers=_headers(), params=params)
    r.raise_for_status()
    return r.json()["value"]


# -------------------------------------------------
# Mark message as read
# -------------------------------------------------
def mark_read(msg_id: str):
    r = requests.patch(
        f"{BASE}/me/messages/{msg_id}",
        headers=_headers(),
        json={"isRead": True},
    )
    r.raise_for_status()


# -------------------------------------------------
# Reply to an existing message (HTML, threaded)
# -------------------------------------------------
def reply_to_message_strict(message_id: str, body: str) -> str:
    """
    Reply to an existing Outlook message (keeps thread)
    Converts Markdown → HTML so Outlook renders formatting
    """

    html_body = markdown_to_outlook_html(body)

    payload = {
        "message": {
            "body": {
                "contentType": "HTML",
                "content": html_body
            }
        }
    }

    r = requests.post(
        f"{BASE}/me/messages/{message_id}/reply",
        headers=_headers(),
        json=payload,
    )
    r.raise_for_status()

    # Microsoft Graph does not return reply ID
    return message_id


# -------------------------------------------------
# Fetch metadata (sender email + subject)
# -------------------------------------------------
def get_message_metadata(message_id: str):
    r = requests.get(
        f"{BASE}/me/messages/{message_id}",
        headers=_headers(),
        params={"$select": "from,subject"}
    )
    r.raise_for_status()
    data = r.json()

    to_email = (
        data.get("from", {})
            .get("emailAddress", {})
            .get("address")
    )

    subject = data.get("subject")
    return to_email, subject


# -------------------------------------------------
# Send reply using EmailRecord (wrapper for drafts)
# -------------------------------------------------
def send_email_via_graph(email_record):
    if not email_record.outlook_id:
        raise ValueError("Missing outlook_id on email record")

    if not email_record.draft_reply:
        raise ValueError("Draft reply is empty")

    reply_to_message_strict(
        message_id=email_record.outlook_id,
        body=email_record.draft_reply
    )
