# services/assignment_engine.py
 
import psycopg2
import os
from datetime import datetime
from collections import defaultdict
 
DATABASE_URL = os.getenv("DATABASE_URL")
 
def get_db_conn():
    return psycopg2.connect(DATABASE_URL)
 
 
def get_next_employee_id(exclude_user_id=None):
    """
    Round-robin++:
    1. Only active employees
    2. Least load first
    3. Oldest last_assigned_at wins
    """
 
    conn = get_db_conn()
    cur = conn.cursor()
 
    cur.execute("""
        SELECT id, last_assigned_at
        FROM users
        WHERE role = 'employee'
        AND is_active = true
    """)
    employees = cur.fetchall()
 
    if exclude_user_id:
        employees = [e for e in employees if e[0] != exclude_user_id]
 
    if not employees:
        cur.close()
        conn.close()
        raise RuntimeError("No active employees")
 
    cur.execute("""
        SELECT assigned_to, COUNT(*)
        FROM email_records
        WHERE status NOT IN ('replied', 'closed')
        GROUP BY assigned_to
    """)
 
    load = defaultdict(int)
    for uid, cnt in cur.fetchall():
        load[uid] = cnt
 
    employees.sort(
        key=lambda e: (
            load.get(e[0], 0),
            e[1] or datetime.min
        )
    )
 
    chosen = employees[0][0]
 
    cur.execute(
        "UPDATE users SET last_assigned_at = NOW() WHERE id = %s",
        (chosen,)
    )
 
    conn.commit()
    cur.close()
    conn.close()
 
    return chosen
 