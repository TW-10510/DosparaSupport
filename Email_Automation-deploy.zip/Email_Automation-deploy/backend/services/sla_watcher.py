 
import time
import psycopg2
import os
import json
 
from services.assignment_engine import get_next_employee_id
 
DATABASE_URL = os.getenv("DATABASE_URL")
DATA_DIR = os.getenv("DATA_DIR", "email_automation_dataset")
INBOX_PATH = os.path.join(DATA_DIR, "inbox.jsonl")
 
 
def _get_db():
    return psycopg2.connect(DATABASE_URL)
 
 
def _read_jsonl(path):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf8") as f:
        return [json.loads(l) for l in f if l.strip()]
 
 
def _write_jsonl(path, items):
    with open(path, "w", encoding="utf8") as f:
        for it in items:
            f.write(json.dumps(it) + "\n")
 
 
def run_sla_watcher():
    print("⏱️ SLA Watcher started")
 
    while True:
        try:
            conn = _get_db()
            cur = conn.cursor()
 
            cur.execute("""
                SELECT id, assigned_to
                FROM email_records
                WHERE sla_deadline < NOW()
                  AND handled_by IS NULL
                  AND status NOT IN ('replied', 'closed')
                  AND COALESCE(reassigned_count, 0) < 3
                FOR UPDATE SKIP LOCKED
            """)
 
            rows = cur.fetchall()
            inbox = _read_jsonl(INBOX_PATH)
            now = int(time.time())
 
            for email_id, old_user in rows:
                try:
                    new_user = get_next_employee_id(exclude_user_id=old_user)
                except Exception:
                    continue
 
                cur.execute("""
                    UPDATE email_records
                    SET assigned_to = %s,
                        reassigned_count = reassigned_count + 1
                    WHERE id = %s
                """, (new_user, email_id))
 
                for it in inbox:
                    if str(it.get("id")) == str(email_id):
                        it["assigned_to"] = new_user
                        it.setdefault("metadata", {})
                        it["metadata"]["sla_reassigned"] = True
                        it["metadata"]["previous_owner"] = old_user
                        it["metadata"]["reassigned_at"] = now
                        break
 
            conn.commit()
            cur.close()
            conn.close()
            _write_jsonl(INBOX_PATH, inbox)
 
        except Exception as e:
            print("[SLA WATCHER ERROR]", e)
 
        time.sleep(60)
 