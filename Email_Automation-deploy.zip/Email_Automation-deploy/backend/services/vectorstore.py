# backend/services/vectorstore.py
import os
import json
import time
from typing import List, Dict, Any
from dotenv import load_dotenv
import numpy as np
import faiss
import openai

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# set openai key lazily when embedding function is called (so module import won't crash)
def _ensure_openai_key():
    global OPENAI_API_KEY
    try:
        import openai as _openai
    except Exception:
        raise RuntimeError("openai package required. pip install openai")
    if not OPENAI_API_KEY:
        OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY not found in environment (.env).")
    _openai.api_key = OPENAI_API_KEY

# Paths (adjust if your project places files elsewhere)
INDEX_PATH = os.getenv("FAISS_INDEX_PATH", "faiss_index/index.faiss")
META_PATH = os.getenv("FAISS_META_PATH", "faiss_index/kb_metadata.json")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")

# Helpers for embedding calls (robust across client versions)
def _call_embeddings_single(input_text: str):
    try:
        return openai.Embeddings.create(model=EMBEDDING_MODEL, input=input_text)
    except Exception:
        try:
            return openai.embeddings.create(model=EMBEDDING_MODEL, input=input_text)
        except Exception:
            from openai import OpenAI as _OpenAIClient
            client = _OpenAIClient(api_key=OPENAI_API_KEY)
            return client.embeddings.create(model=EMBEDDING_MODEL, input=input_text)

def get_embedding(text: str) -> np.ndarray:
    inp = text.replace("\n", " ")[:2000]
    resp = _call_embeddings_single(inp)
    # normalize response shapes: dict-like or object-like
    if isinstance(resp, dict):
        data = resp.get("data", [])
    else:
        data = getattr(resp, "data", [])
    if not data:
        raise RuntimeError("No embedding data returned.")
    item = data[0]
    if isinstance(item, dict):
        emb = item.get("embedding") or item.get("embeddings")
    else:
        emb = getattr(item, "embedding", None) or getattr(item, "embeddings", None)
    if emb is None:
        raise RuntimeError("Could not parse embedding from OpenAI response.")
    return np.array(emb).astype("float32")

class VectorStore:
    """
    Simple FAISS + metadata wrapper.
    Loads index & metadata on init. Provides search_text(query, k).
    """
    def __init__(self, index_path: str = INDEX_PATH, meta_path: str = META_PATH):
        if not os.path.exists(index_path):
            raise RuntimeError(f"FAISS index not found at {index_path}")
        if not os.path.exists(meta_path):
            raise RuntimeError(f"Metadata not found at {meta_path}")
        self.index = faiss.read_index(index_path)
        with open(meta_path, "r", encoding="utf8") as f:
            self.metadata = json.load(f)  # list of dicts
        # dimension check (optional)
        # self.dim = self.index.d
        # print("Loaded FAISS index:", index_path, "entries:", len(self.metadata))

    def search_by_vector(self, query_vec: np.ndarray, top_k: int = 6) -> List[Dict[str, Any]]:
        q = np.array([query_vec]).astype("float32")
        faiss.normalize_L2(q)
        D, I = self.index.search(q, top_k)
        results = []
        for score, idx in zip(D[0], I[0]):
            if idx < 0 or idx >= len(self.metadata):
                continue
            m = self.metadata[idx]
            results.append({
                "id": m.get("id"),
                "text": m.get("text"),
                "type": m.get("type"),
                "category": m.get("category"),
                "score": float(score)
            })
        return results

    def search_text(self, query_text: str, top_k: int = 6) -> List[Dict[str, Any]]:
        vec = get_embedding(query_text)
        return self.search_by_vector(vec, top_k=top_k)
