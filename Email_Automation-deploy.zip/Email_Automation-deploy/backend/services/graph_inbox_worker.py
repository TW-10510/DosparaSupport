# backend/services/graph_inbox_worker.py
 
import time
import os
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
 
from services.outlook_graph_client import fetch_unread, mark_read
from services.prefilter import should_ignore_email
from services.rag_pipeline import generate_reply_for_email, detect_language
from services.assignment_engine import get_next_employee_id
 
from database import SessionLocal
from models import EmailRecord
 
DATA_DIR = os.getenv("DATA_DIR", "email_automation_dataset")
SLA_MINUTES = int(os.getenv("EMAIL_SLA_MINUTES", "60"))
 
 
def html_to_text(html: str) -> str:
    if not html:
        return ""
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "meta", "link", "head"]):
        tag.decompose()
    return soup.get_text(separator="\n").strip()
 
 
def get_thread_root(db, thread_id):
    return (
        db.query(EmailRecord)
        .filter(EmailRecord.thread_id == thread_id)
        .order_by(EmailRecord.created_at.asc())
        .first()
    )
 
 
def poll():
    print("🚀 [Graph Worker] Started")
 
    while True:
        try:
            messages = fetch_unread()
            if not messages:
                time.sleep(10)
                continue
 
            for m in messages:
                msg_id = m.get("id")
                if not msg_id:
                    continue
 
                thread_id = m.get("conversationId")
                sender = m.get("from", {}).get("emailAddress", {})
                sender_email = sender.get("address")
                sender_name = sender.get("name") or "Customer"
 
                subject = m.get("subject", "")
                body_html = m.get("body", {}).get("content", "")
                body = html_to_text(body_html)
 
                ignore, _ = should_ignore_email(subject, sender_email, body)
                if ignore:
                    mark_read(msg_id)
                    continue
 
                db = SessionLocal()
                try:
                    if db.query(EmailRecord).filter_by(outlook_id=msg_id).first():
                        mark_read(msg_id)
                        continue
 
                    language = detect_language(body)
                    rag = generate_reply_for_email(body, sender_name, language)
                    reply = rag.get("reply", "")
 
                    parent = None
                    assigned_to = None
                    sla_deadline = None
 
                    root = get_thread_root(db, thread_id)
 
                    if root:
                        # 🔐 THREAD OWNERSHIP CONTINUITY
                        parent = root.id
                        sla_deadline = root.sla_deadline
                        assigned_to = root.handled_by or root.assigned_to
                    else:
                        assigned_to = get_next_employee_id()
                        sla_deadline = datetime.utcnow() + timedelta(minutes=SLA_MINUTES)
 
                    email = EmailRecord(
                        outlook_id=msg_id,
                        thread_id=thread_id,
                        parent_id=parent,
                        recipient_email=sender_email,
                        subject=subject,
                        body=body,
                        draft_reply=reply,
                        language=language,
                        status="pending_approval",
                        assigned_to=assigned_to,
                        assigned_at=datetime.utcnow(),
                        sla_deadline=sla_deadline,
                    )
 
                    db.add(email)
                    db.commit()
                    mark_read(msg_id)
 
                finally:
                    db.close()
 
        except Exception as e:
            print("[Graph Worker Error]", e)
 
        time.sleep(15)