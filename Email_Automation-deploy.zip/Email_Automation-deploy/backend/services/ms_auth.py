import os, json, requests
from datetime import datetime, timedelta
from urllib.parse import quote
 
TENANT = os.getenv("MS_TENANT_ID")
CLIENT_ID = os.getenv("MS_CLIENT_ID")
CLIENT_SECRET = os.getenv("MS_CLIENT_SECRET")
REDIRECT_URI = os.getenv("MS_REDIRECT_URI")
 
SCOPES = "offline_access Mail.Read Mail.Send User.Read"
 
AUTH_URL = f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/authorize"
TOKEN_URL = f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/token"
TOKEN_FILE = "ms_token.json"
 
def get_auth_url():
    return (
        f"{AUTH_URL}"
        f"?client_id={CLIENT_ID}"
        f"&response_type=code"
        f"&redirect_uri={quote(REDIRECT_URI)}"
        f"&scope={quote(SCOPES)}"
    )
 
def _save(token):
    token["expires_at"] = (
        datetime.utcnow() + timedelta(seconds=token["expires_in"] - 60)
    ).isoformat()
    with open(TOKEN_FILE, "w") as f:
        json.dump(token, f, indent=2)
 
def _load():
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE) as f:
        return json.load(f)
 
def exchange_code(code):
    data = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": REDIRECT_URI,
        "scope": SCOPES,
    }
 
    r = requests.post(TOKEN_URL, data=data)
    print("MS TOKEN RESPONSE:", r.text)  # 🔍 debug visibility
    r.raise_for_status()
    _save(r.json())
 
def refresh():
    token = _load()
    if not token:
        raise RuntimeError("No Microsoft token stored")
 
    data = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "grant_type": "refresh_token",
        "refresh_token": token["refresh_token"],
        "scope": SCOPES,
    }
 
    r = requests.post(TOKEN_URL, data=data)
    print("MS REFRESH RESPONSE:", r.text)
    r.raise_for_status()
    _save(r.json())
 
def get_access_token():
    token = _load()
    if not token:
        raise RuntimeError("Microsoft Graph not connected")
 
    if datetime.utcnow() >= datetime.fromisoformat(token["expires_at"]):
        refresh()
        token = _load()
 
    return token["access_token"]