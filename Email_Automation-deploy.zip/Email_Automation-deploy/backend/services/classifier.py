# backend/services/classifier.py
import os, json, time
from typing import Dict, Any, List
from dotenv import load_dotenv
load_dotenv()
import openai

OPENAI_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_KEY:
    raise RuntimeError("OPENAI_API_KEY not found in env")
openai.api_key = OPENAI_KEY

# Model to use for classification (chat completion)
CHAT_MODEL = os.getenv("CLASSIFIER_MODEL", "gpt-5")  # change as needed
TEMPERATURE = float(os.getenv("CLASSIFIER_TEMP", "0.0"))

# Labels
LABELS = ["Support", "Sales", "Billing", "Returns", "Technical", "Other"]

# Few-shot examples (small, high-quality samples).
# You can replace these with a selection from your class_train_1000.jsonl if you prefer.
FEW_SHOT_EXAMPLES = [
    # Support
    {"email":"Hi, my device arrived but won't power on. What can I do?","label":"Support"},
    {"email":"I need help assembling the unit included screws were missing.","label":"Support"},
    # Sales
    {"email":"Can I get a price for ordering 200 units?","label":"Sales"},
    {"email":"Do you offer reseller discounts for bulk purchase of product X?","label":"Sales"},
    # Billing
    {"email":"I was charged twice for my order. Please refund the duplicate.","label":"Billing"},
    {"email":"Can I get a copy of my invoice for order [ORDER_ID]?","label":"Billing"},
    # Returns
    {"email":"I received the wrong item, want to return and get a refund.","label":"Returns"},
    {"email":"How do I get a prepaid return label for damaged product?","label":"Returns"},
    # Technical
    {"email":"Firmware update failed and device doesn't boot anymore.","label":"Technical"},
    {"email":"Bluetooth pairing fails with Android 12 devices consistently.","label":"Technical"},
    # Other
    {"email":"Hello, I want to suggest a new feature for your product line.","label":"Other"},
    {"email":"Where are you located and do you have a showroom?","label":"Other"},
]

# Build system + few-shot prompt
SYSTEM_PROMPT = (
    "You are a concise email triage assistant. Given a customer email body, choose the single "
    "best label from the fixed set: " + ", ".join(LABELS) + ".\n"
    "Return only the label name (one of the provided labels) and nothing else in the main answer.\n"
    "Also, provide a short JSON object (in the assistant reason) with these keys: "
    "'label' (string), 'confidence' (0.0-1.0, optional), 'explanation' (one-sentence)."
)

def _call_chat_completion(messages: List[Dict[str, str]], model=CHAT_MODEL, temperature=TEMPERATURE, max_tokens=150):
    """
    Robust wrapper to call different openai client styles for chat completion.
    Returns string content and raw response object.
    """
    try:
        resp = openai.ChatCompletion.create(model=model, messages=messages, temperature=temperature, max_tokens=max_tokens)
        # dict-like or object-like
        if isinstance(resp, dict):
            content = resp["choices"][0]["message"]["content"]
        else:
            content = resp.choices[0].message.content
        return content, resp
    except Exception as e1:
        try:
            resp = openai.chat.completions.create(model=model, messages=messages, temperature=temperature, max_tokens=max_tokens)
            return resp["choices"][0]["message"]["content"], resp
        except Exception as e2:
            try:
                from openai import OpenAI as _OpenAIClient
                client = _OpenAIClient(api_key=OPENAI_KEY)
                resp = client.chat.completions.create(model=model, messages=messages, temperature=temperature, max_tokens=max_tokens)
                # handle object-like
                if isinstance(resp, dict):
                    return resp["choices"][0]["message"]["content"], resp
                else:
                    return resp.choices[0].message.content, resp
            except Exception as e3:
                raise RuntimeError(f"All chat completion calls failed: {e1} | {e2} | {e3}")

def build_classify_prompt(email_text: str) -> List[Dict[str,str]]:
    """
    Build chat messages with few-shot examples and the user email.
    We supply examples in the user role as 'Example email -> Label' to guide the model.
    """
    messages = [{"role":"system","content":SYSTEM_PROMPT}]
    # add few-shot examples as user+assistant pairs
    for ex in FEW_SHOT_EXAMPLES:
        messages.append({"role":"user", "content": f"Email:\n{ex['email']}"})
        messages.append({"role":"assistant", "content": ex["label"]})
    # final query
    messages.append({"role":"user", "content": f"Email:\n{email_text}\n\nAnswer with the single label (one of: {', '.join(LABELS)}) and then a short explanation in JSON on a new line."})
    return messages

def classify_email(email_text: str) -> Dict[str,Any]:
    """
    Returns: {"label": str, "confidence": float (0-1), "explanation": str, "raw": raw_response}
    """
    messages = build_classify_prompt(email_text)
    content, raw = _call_chat_completion(messages)
    # The model is instructed to output label then JSON explanation.
    # We'll parse heuristically.
    label = None
    confidence = None
    explanation = None

    # attempt: split lines, first non-empty token likely the label
    lines = [l.strip() for l in content.splitlines() if l.strip()]
    if len(lines) > 0:
        # first token may be the label
        first = lines[0]
        # If first line is exactly one of labels, take it
        if first in LABELS:
            label = first
            # try parse JSON in the rest
            rest = "\n".join(lines[1:]).strip()
        else:
            # sometimes model writes "Label: Support" or "Support - reason"
            for lab in LABELS:
                if first.startswith(lab):
                    label = lab
                    rest = "\n".join(lines[1:]).strip()
                    break
            else:
                # fallback: choose closest label by substring match
                for lab in LABELS:
                    if lab.lower() in content.lower():
                        label = lab
                        break
                rest = "\n".join(lines[1:]).strip()
    else:
        content_str = content.strip()
        if content_str in LABELS:
            label = content_str

    # try to find JSON in content
    json_obj = None
    import re
    m = re.search(r"(\{.*\})", content, flags=re.S)
    if m:
        try:
            json_obj = json.loads(m.group(1))
        except Exception:
            json_obj = None

    if json_obj:
        label = label or json_obj.get("label")
        confidence = json_obj.get("confidence")
        explanation = json_obj.get("explanation")
    else:
        # try to extract explanation from remainder
        explanation = rest if 'rest' in locals() else content

    # final fallbacks
    if not label:
        # choose Other as default safety fallback
        label = "Other"

    # map/normalize confidence if present else None (we don't force a value)
    if confidence is not None:
        try:
            confidence = float(confidence)
            if confidence < 0 or confidence > 1:
                confidence = None
        except Exception:
            confidence = None

    return {
        "label": label,
        "confidence": confidence,
        "explanation": explanation,
        "raw": {"content": content, "raw_resp": str(raw)}
    }
